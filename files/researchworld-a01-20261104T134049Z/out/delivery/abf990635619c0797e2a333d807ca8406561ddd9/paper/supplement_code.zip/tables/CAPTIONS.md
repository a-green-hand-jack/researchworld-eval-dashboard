# Table caption stubs (numbers come from `tables/*.tex` and `results/core_*.csv`)

**T2 `T2_theory_check.tex`.** Closed forms of Propositions 1-3 (mean, min, median for odd n) against the exact solvers on every target ("exact solver") and against a
generic LP/MILP on a random sample of 60 targets ("generic LP/MILP"); maximum absolute deviation of L1 and K over all targets, cap scenarios aggregated (column "caps"), and
number of targets on which closed form and solver disagree on feasibility. The OLLB median (n = 6, even) has no closed form and is compared with brute force in the test suite only.

**T3 `T3_rules_<dataset>_<cap>.tex`.** Per rule and stratum of the target's rank under the mean: *feas.* = targets for which first place is reachable / targets in the stratum;
K and L1 = median among the feasible targets of that rule [95% bootstrap CI over targets, B = 2000]; last column = median of the per-target ratio L1(rule)/L1(mean) over targets feasible
under both the rule and the mean (their number in parentheses), with CI. Costs and ratios are conditional on feasibility, and the feasible sets differ by rule, so a rule with a small feas. count
is summarised on a selected, easier subset; do not read the K and L1 columns as a ranking of rules without the feas. column. Borda and Condorcet on OLLB are exact only for ranks 2-50.

**T4 `T4_frontier_<dataset>.tex`.** Feasibility frontier. *targets* = models other than the leader (OLLB Borda/Condorcet: the 50 best under the mean only, $^\dagger$, not comparable with
the score rules' fractions); *feasible* and *share* [Wilson 95% CI]; $r^*$ = largest rank under the mean among feasible targets (may be an isolated case); *all feas. up to* = largest r such that every
target with rank <= r is feasible; *r\* and all feas. up to* carry 95% bootstrap CIs over targets from `summary/frontier_*.csv` (our recomputation from `core_*.csv` agrees exactly; the CI of a maximum is one-sided, so a CI whose upper end equals the estimate is expected); *first bin < 1/2* = the first rank bin (bins double from rank 2; at least 3 targets) in which fewer than half of the targets are feasible.

**T5 `T5_variants_<dataset>.tex`** (appendix). Sensitivity of the primary result to analysis choices, primary cap (`emp99` OLLB, `emp99T` HELM) unless the cap column says otherwise. Rows: margin
by which the target must lead (1 or 2 points instead of 1e-3); OLLB without merged models; raw (un-normalised) scores, which the analysis ran only for `ceil` and `gain10`; the top-500 slice of OLLB
(rules incl. the ordinal ones are exact on this slice); random task weights (Dirichlet(1), Dirichlet(5), one-hot; `n` counts weight draws on the stratified targets ranks 2-100, not distinct targets); cost in units of the per-task evaluation-noise SE
($L_1$ column in sigma units, no baseline). *n* = targets (draws), *censored* = targets the solver could not decide, *feas. share* = share with a finite cost, in parentheses the baseline share on the same targets in the main run
(omitted for the top-500 ordinal rules, whose baseline covers only the 50 best targets); median K and L1 are among feasible targets; last column = median per-target ratio variant/baseline over targets feasible in both
(their number in parentheses). Read costs together with the feasible share: a variant that changes the share changes the selected set.

**T6 `T6_paired_<dataset>_<cap>.tex`** (main or appendix). Paired comparison of each rule with the mean rule. Cell: median over targets of the ratio L1(rule)/L1(mean), restricted to targets feasible
under both rules with positive cost in both; second line the 95% bootstrap CI over those targets; third line n_both / n_either (targets feasible under both / under at least one). A ratio below 1 means the rule
is cheaper *for the targets for which both rules are feasible*; the selection is not random (e.g. the min rule is feasible for few targets), so always read it with n_both/n_either; "--" = fewer than 2 paired targets, no ratio.
The columns are rank strata under the mean. OLLB Borda/Condorcet exist only for the 50 best targets$^\dagger$, so the "all" column pairs 42-48 targets out of 546.
