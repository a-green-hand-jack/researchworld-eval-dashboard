"""F4: scaling of the investment with the number of tasks n (HELM MMLU, random n-subsets of the 57 subjects).
Usage: python3 figures/src/fig_scaling.py RESULTS_DIR OUT_STEM
Input: RESULTS_DIR/summary/summary_rob_helm_tasksub_emp99T.csv (analysis summary: per rule x n x target rank, 2.5/50/97.5 percentiles over
60 random subsets of feasible draws). Bands are the percentile range of the subset draws (spread across subsets), not a CI of the median.
The target is the model ranked 2 (left) / 5 (right) under the subset's own rule (as defined by the analysis)."""
import sys, pathlib, json, hashlib
import numpy as np, pandas as pd, matplotlib.pyplot as plt
sys.path.insert(0, str(pathlib.Path(__file__).parent)); import style
res, out = pathlib.Path(sys.argv[1]), sys.argv[2]; style.setup()
p = res / "summary" / "summary_rob_helm_tasksub_emp99T.csv"; s = pd.read_csv(p)
rules = [r for r in style.MAIN_RULES + ["plurality"] if r in set(s.rule)]
fig, axes = plt.subplots(2, 2, figsize=(style.TEXTWIDTH_IN, 3.6), sharex=True, squeeze=False)
for j, tr in enumerate((2, 5)):
    for rule in rules:
        g = s[(s.rule == rule) & (s.target_rank == tr)].sort_values("n")
        kw = dict(color=style.RULE_COLOR[rule], marker=style.RULE_MARK[rule], ms=3, label=style.RULE_LABEL[rule])
        for i, (c, div) in enumerate((("K", g.n), ("L1", g.n))):
            ax = axes[i, j]
            ax.plot(g.n, g[f"{c}_p50"] / div, **kw); ax.fill_between(g.n, g[f"{c}_p2.5"] / div, g[f"{c}_p97.5"] / div, color=kw["color"], alpha=0.08, lw=0)
    axes[0, j].set_title(f"target ranked {tr} within the subset", fontsize=7.5, loc="left")
for ax in axes.ravel(): style.log_axis(ax); ax.set_xticks([3, 6, 12, 24, 48]); ax.set_xticklabels(["3", "6", "12", "24", "48"])
for j in range(2):
    axes[1, j].set_xlabel("number of tasks $n$ in the subset"); axes[0, j].set_ylim(0, 1.02)
    axes[1, j].set_yscale("symlog", linthresh=0.01); axes[1, j].set_ylim(bottom=0)
    axes[1, j].set_yticks([0, 0.01, 0.1, 1]); axes[1, j].set_yticklabels(["0", "0.01", "0.1", "1"])
axes[0, 0].set_ylabel("tasks touched, $K/n$"); axes[1, 0].set_ylabel("points per task, $L_1/n$")
h, l = axes[0, 0].get_legend_handles_labels(); fig.legend(h, l, loc="upper center", ncol=len(l), frameon=False, fontsize=6.8, bbox_to_anchor=(0.5, 1.02))
fig.tight_layout(rect=(0, 0, 1, 0.94))
for ext in ("pdf", "png"): fig.savefig(f"{out}.{ext}", dpi=200)
inf = s.groupby("rule").L1_infeasible.max().to_dict()
json.dump(dict(script="figures/src/fig_scaling.py", inputs=[dict(file="summary/" + p.name, sha256=hashlib.sha256(p.read_bytes()).hexdigest())],
               max_infeasible_share_by_rule=inf, draws_per_cell=int(s.draws.iloc[0])), open(f"{out}.json", "w"), indent=1)
