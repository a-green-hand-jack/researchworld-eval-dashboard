"""F5: stability of the minimum investment under evaluation noise and task resampling, for a handful of targets.
Usage: python3 figures/src/fig_robust.py RESULTS_DIR OUT_STEM [--set score|rank]
score (F5, default): mean/median/min/Borda; panels OLLB evaluation noise, OLLB task bootstrap, HELM evaluation noise, HELM task bootstrap.
rank (F5b): Borda/Condorcet/plurality; panels OLLB evaluation noise, OLLB task bootstrap (ordinal summaries, 60 draws), HELM evaluation noise.
Inputs: RESULTS_DIR/summary/summary_rob_<name>.csv (names in PANELS) and the matching core tables (value on the observed data).
Bars = 2.5-97.5 percentile of L1 over feasible Monte Carlo draws (not a CI of the median); dot = median of the draws; open diamond = value on
the observed data (core table); the strip below each panel is the share of draws in which first place is unreachable within the cap.
Bars are absent where every draw is infeasible."""
import sys, argparse, pathlib, json, hashlib
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
sys.path.insert(0, str(pathlib.Path(__file__).parent)); import style
ap = argparse.ArgumentParser(); ap.add_argument("resdir"); ap.add_argument("out"); ap.add_argument("--set", default="score", choices=["score", "rank"]); a = ap.parse_args()
res, out = pathlib.Path(a.resdir), a.out; style.setup()
SETS = {"score": (("mean", "median", "min", "borda"), 2, [
            ("ollb", "ollb_noise_closed_emp99", "OLLB, evaluation noise (300 draws)"), ("ollb", "ollb_taskboot_closed_emp99", "OLLB, task bootstrap (300 draws)"),
            ("helm", "helm_noise_emp99T", "HELM, evaluation noise (200 draws)"), ("helm", "helm_taskboot_emp99T", "HELM, task bootstrap (200 draws)")]),
        "rank": (("borda", "condorcet", "plurality"), 3, [
            ("ollb", "ollb_noise_ord_emp99", "OLLB, evaluation noise (60 draws)"), ("ollb", "ollb_taskboot_ord_emp99", "OLLB, task bootstrap (60 draws)"),
            ("helm", "helm_noise_emp99T", "HELM, evaluation noise (200 draws)")])}
RULES, NC, PANELS = SETS[a.set]; NR = -(-len(PANELS) // NC)
fig = plt.figure(figsize=(style.TEXTWIDTH_IN, 1.0 + 2.1 * NR)); gs = fig.add_gridspec(2 * NR, NC, height_ratios=[3, 1.1] * NR, hspace=0.55)
prov = []; seen = set()
for pi, (ds, name, title) in enumerate(PANELS):
    r0, c = 2 * (pi // NC), pi % NC; ax = fig.add_subplot(gs[r0, c]); bx = fig.add_subplot(gs[r0 + 1, c], sharex=ax); plt.setp(ax.get_xticklabels(), visible=False)
    p = res / "summary" / f"summary_rob_{name}.csv"; s = pd.read_csv(p)
    if p.name not in seen: seen.add(p.name); prov.append(dict(file="summary/" + p.name, sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    core, pc = style.load_core(res, ds); core = core[core.cap == style.PRIMARY_CAP[ds]]
    if pc[0][0] not in seen: seen.add(pc[0][0]); prov.append(dict(file=pc[0][0], sha256=pc[0][1]))
    rules = [r for r in RULES if r in set(s.rule)]
    tg = s.drop_duplicates("target").sort_values("rank_mean_obs"); order = list(tg.target); ranks = list(tg.rank_mean_obs)
    for ri, rule in enumerate(rules):
        for ti, t in enumerate(order):
            x = ti + (ri - (len(rules) - 1) / 2) * 0.18; r = s[(s.rule == rule) & (s.target == t)]
            if r.empty: continue
            r = r.iloc[0]; col = style.RULE_COLOR[rule]
            if np.isfinite(r["L1_p50"]):
                ax.vlines(x, r["L1_p2.5"], r["L1_p97.5"], color=col, lw=1.4); ax.plot(x, r["L1_p50"], "o", color=col, ms=2.5)
            o = core[(core.rule == rule) & (core.target == t)]
            if len(o) and np.isfinite(o.L1.iloc[0]): ax.plot(x, o.L1.iloc[0], "D", mfc="none", mec=col, ms=3.5, mew=0.8)
            bx.plot(x, 100 * r["L1_infeasible"], "s", color=col, ms=2.5)
    bx.set_xticks(range(len(order))); bx.set_xticklabels([str(int(k)) for k in ranks], fontsize=6); bx.set_ylim(-5, 105); bx.set_yticks([0, 50, 100])
    ax.set_yscale("symlog", linthresh=0.5); ax.set_ylim(bottom=0); ax.set_yticks([0, 1, 10, 100]); ax.set_yticklabels(["0", "1", "10", "100"])
    ax.set_ylim(top=ax.get_ylim()[1] * 1.6); ax.set_title(title, fontsize=6.5, loc="left")
    if r0 == 2 * (NR - 1) or pi + NC >= len(PANELS): bx.set_xlabel("target's rank under the mean", fontsize=7)
    if c == 0: ax.set_ylabel("minimum total gain $L_1$ (points)", fontsize=7); bx.set_ylabel("% draws\ninfeasible", fontsize=7)
hs = [Line2D([], [], color=style.RULE_COLOR[r], marker=style.RULE_MARK[r], ms=3, label=style.RULE_LABEL[r]) for r in RULES]
hs += [Line2D([], [], ls="none", marker="D", mfc="none", mec="k", ms=3.5, label="observed data")]
fig.legend(handles=hs, loc="upper center", ncol=len(hs), frameon=False, fontsize=6.8, bbox_to_anchor=(0.5, 1.0))
fig.subplots_adjust(top=1 - 0.5 / (1.0 + 2.1 * NR), left=0.1, right=0.99, bottom=0.1, wspace=0.28)
for ext in ("pdf", "png"): fig.savefig(f"{out}.{ext}", dpi=200)
json.dump(dict(script="figures/src/fig_robust.py", args=dict(out=out, set=a.set), inputs=prov), open(f"{out}.json", "w"), indent=1)
