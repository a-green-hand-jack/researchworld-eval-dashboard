"""Populate the unchanged official question/guideline structure honestly."""
import re
from common import ROOT

answers=[
('Yes','Sections 1 and 5 distinguish the finite-population guarantee from measured MAE and ranking results; no universal or state-of-the-art gain is claimed.'),
('Yes','Section 6 discusses dependence, oracle splits, duplicate groups, finite seeds, flat-score scope, omitted full pipeline reproductions, and misuse risks.'),
('Yes','Proposition 1 states the sampling and integrability assumptions; Appendix A supplies the full proof, conditional variance, and boundary cases.'),
('Yes','Section 4 and Appendices~\\ref{app:settings} and~\\ref{app:repro} specify data version, masking, objectives, seeds, all hyperparameters, commands, and recorded unsuccessful attempts.'),
('Yes','The accompanying artifact contains all new source code, predictions, requirements, fixed-snapshot acquisition and hash checks, and build instructions; no account is required.'),
('Yes','Section 4 and Appendices C and D specify source/target grouping, query construction, optimization, calibration, and the post-primary comparator amendment.'),
('Yes','The tables define descriptive bank-bootstrap intervals and five-seed variability; the repeated-mask figure uses mask-level Monte Carlo errors. Dependence precludes population-significance claims, and no such claim is made.'),
('Yes','Appendix~\\ref{app:repro} and README report CPU workers, thread counts, host resources, per-cell timings, measured stage durations, and preliminary invalidated computation.'),
('NA','No independent human review or complete standalone review of the linked NeurIPS Code of Ethics was performed in this unattended artifact. Data access, attribution, transparency, and broader impacts are addressed explicitly, but conformity in every respect is not certified.'),
('Yes','Section 6 discusses reduced evaluation cost and access, as well as rare-failure omission, public-subset gaming, misleading ranks, and mitigations.'),
('NA','No pretrained generative model, private records, or newly scraped dataset is released. The artifact contains numerical response-derived outputs and evaluation code; ordinary downstream misuse is discussed in Section 6.'),
('No','The permitted fixed repository and MIT notice are preserved and credited, but every upstream benchmark license was not independently revalidated; Appendix B discloses this residual provenance limitation.'),
('Yes','The accompanying README documents code, schema, exact seeds, data acquisition, licensing, limitations, and the script producing every figure and table. No newly collected human dataset is introduced.'),
('NA','This study performs numerical analysis of public correctness matrices, with no recruited participants or crowdsourcing.'),
('NA','No human-subject experiment or participant recruitment was conducted; no IRB approval is claimed.'),
('Yes','Appendix~\\ref{app:repro} discloses autonomous LLM assistance in study design, coding, literature reading, analysis, and writing, not merely editing. Numerical outcomes come only from executed code on the fixed matrices.')]
text=(ROOT/'paper/checklist.tex').read_text()
text=re.sub(r'%%% BEGIN INSTRUCTIONS %%%.*?%%% END INSTRUCTIONS %%%','',text,flags=re.S)
for answer,why in answers:
    text=text.replace(r'\answerTODO{}',r'\answer'+answer+'{}',1)
    text=text.replace(r'\justificationTODO{}',why,1)
assert 'TODO' not in text
(ROOT/'paper/checklist_filled.tex').write_text(text)
