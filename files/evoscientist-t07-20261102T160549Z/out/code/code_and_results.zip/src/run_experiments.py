"""Resumable complete experiment grid, all scores from real binary matrices."""
import os
for _v in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[_v] = '1'
import argparse, json, time, traceback
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, kendalltau
from joblib import Parallel, delayed
from threadpoolctl import threadpool_limits
from common import ROOT,NAMES,BUDGETS,load,split_rows,sha256
from methods import (source_strata,designs,row_ridge,full_query_ridge,fixed_difference,
                     stratified_mean,crossfit,rasch_fit,rasch_predict,binary_anchors)


def metrics(true,pred):
    err = pred-true
    # Numerical tie policy fixed after an invariant audit, not tuned to outcomes.
    # 1e-10 fraction precision is far below any bank's single-item score quantum.
    # Error metrics use ORIGINAL predictions; only ordering uses quantized values.
    rt, rp = np.round(true, 10), np.round(pred, 10)
    nonconstant = np.ptp(rp) > 0 and np.ptp(rt) > 0
    rho = float(spearmanr(rt,rp).statistic) if nonconstant else None
    tau = float(kendalltau(rt,rp).statistic) if nonconstant else None
    i,j = np.triu_indices(len(true),1)
    keep = rt[i] != rt[j]
    signs = np.sign((rt[i]-rt[j])*(rp[i]-rp[j]))[keep]
    agreement = float(np.mean((signs+1)/2)) if len(signs) else None
    return dict(mae=float(abs(err).mean()),mse=float((err**2).mean()),
                rmse=float(np.sqrt((err**2).mean())),bias=float(err.mean()),
                p95=float(np.quantile(abs(err),.95)),rho=rho,tau=tau,
                pair_agreement=agreement,out_of_range=float(np.mean((pred<0)|(pred>1))))


def timed(fn,times,key):
    t=time.perf_counter(); value=fn();times[key]=time.perf_counter()-t;return value


def run_cell(name,regime,seed,budgets,force=False):
    out = ROOT/'artifacts/runs'; out.mkdir(parents=True,exist_ok=True)
    stem = f'{name}__{regime}__s{seed}'
    path = out/(stem+'.json')
    if path.exists() and not force:
        return dict(cell=stem,status='cached')
    start=time.perf_counter()
    try:
        with threadpool_limits(limits=1):
            x=load(name);src,tgt,group=split_rows(x,regime,seed)
            source=x[src]
            # Evaluator owns full target; every estimator below receives only
            # target[:, queried] and source. No estimator accepts full target.
            target=x[tgt]
            true=target.mean(1)
            _,rep=np.unique(group[tgt],return_index=True)
            strata=source_strata(source)
            fit_time={}
            beta,it,conv=timed(lambda:rasch_fit(source),fit_time,'rasch_source_fit')
            records=[]
            arrays=dict(target_rows=tgt,source_rows=src,group_ids=group[tgt],true=true,rep=rep)
            queries={}
            for budget in budgets:
                times={}; aux={}
                u,up,s,sp=designs(x.shape[1],budget,seed,strata)
                yu,ys=target[:,u],target[:,s]
                pred={}
                pred['uniform']=timed(lambda:yu.mean(1),times,'uniform')
                # higher-cost reference, explicitly not budget matched
                rng=np.random.default_rng(20000+seed)
                u2=rng.permutation(x.shape[1])[:2*budget]
                pred['uniform_2b']=target[:,u2].mean(1)
                pred['item_difference']=timed(lambda:fixed_difference(source,u,yu),times,'item_difference')
                pred['ridge_score'],aux['ridge_alpha']=timed(lambda:row_ridge(source,u,yu),times,'ridge_score')
                (pred['aipw_pinned'],pred['aipw_population'],resid)=timed(lambda:full_query_ridge(source,u,yu),times,'aipw')
                aux['max_abs_train_residual_mean']=float(abs(resid).max())
                pred['rasch_1pl']=timed(lambda:rasch_predict(beta,u,yu),times,'rasch_predict')
                pred['cfd_uniform']=timed(lambda:crossfit(source,up,[target[:,p] for p in up],[np.arange(x.shape[1])])[0],times,'cfd_uniform')
                pred['stratified_mean']=timed(lambda:stratified_mean(x.shape[1],s,ys,strata),times,'stratified_mean')
                pred['stratified_difference']=timed(lambda:fixed_difference(source,s,ys,strata),times,'stratified_difference')
                pred['stratified_ridge'],aux['stratified_ridge_alpha']=timed(lambda:row_ridge(source,s,ys),times,'stratified_ridge')
                cf,one,impute,contaminated=timed(lambda:crossfit(source,sp,[target[:,p] for p in sp],strata),times,'scfd')
                pred.update(scfd=cf,scfd_one=one,scfd_no_audit=impute,scfd_contaminated=contaminated)
                anchors,weights,warns=timed(lambda:binary_anchors(source,budget,seed),times,'anchors_fit')
                pred['binary_anchors']=target[:,anchors]@weights
                pred['anchor_rasch']=rasch_predict(beta,anchors,target[:,anchors])
                aux['anchor_warnings']=warns
                queries[f'u_{budget}']=u;queries[f's_{budget}']=s
                queries[f'sp_{budget}']=sp[0];queries[f'sa_{budget}']=sp[1]
                queries[f'anchors_{budget}']=anchors
                for method,p in pred.items():
                    assert np.isfinite(p).all(), (method,p)
                    arrays[f'{method}__b{budget}']=p
                    for weighting,idx in [('group',rep),('row',np.arange(len(target)))]:
                        records.append(dict(benchmark=name,regime=regime,seed=seed,budget=budget,
                                            method=method,weighting=weighting,
                                            **metrics(true[idx],p[idx])))
                aux['times_seconds']=times
                arrays[f'aux__b{budget}']=np.array(json.dumps(aux))
            result=dict(cell=stem,status='ok',benchmark=name,regime=regime,seed=seed,
                source_rows=src.tolist(),target_rows=tgt.tolist(),source_groups=len(np.unique(group[src])),
                target_groups=len(rep),source_score_range=[float(source.mean(1).min()),float(source.mean(1).max())],
                target_score_range=[float(true.min()),float(true.max())],
                fit_times=fit_time,rasch_iterations=it,rasch_final_step=float(conv),
                total_seconds=time.perf_counter()-start,records=records,
                code_hashes={f:sha256(ROOT/'src'/f) for f in ['methods.py','common.py','run_experiments.py']})
            np.savez_compressed(out/(stem+'.npz'),**arrays,**queries)
            tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(result,indent=2,allow_nan=False));tmp.replace(path)
            print(stem,'OK',round(result['total_seconds'],2),'seconds',flush=True)
            return dict(cell=stem,status='ok',seconds=result['total_seconds'])
    except Exception:
        msg=traceback.format_exc()
        (out/(stem+'.failure.txt')).write_text(msg)
        print(stem,'FAILED',msg,flush=True)
        return dict(cell=stem,status='failed',error=msg)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--names',nargs='+',default=NAMES)
    parser.add_argument('--regimes',nargs='+',default=['iid','frontier'])
    parser.add_argument('--seeds',nargs='+',type=int,default=list(range(5)))
    parser.add_argument('--budgets',nargs='+',type=int,default=BUDGETS)
    parser.add_argument('--jobs',type=int,default=8)
    parser.add_argument('--force',action='store_true')
    args=parser.parse_args()
    jobs=[(n,r,s) for n in args.names for r in args.regimes for s in args.seeds]
    t=time.perf_counter()
    results=Parallel(n_jobs=args.jobs)(delayed(run_cell)(n,r,s,args.budgets,args.force) for n,r,s in jobs)
    summary=dict(wall_seconds=time.perf_counter()-t,cells=results,args=vars(args))
    suffix='gap' if args.regimes==['gap'] else 'main'
    (ROOT/'artifacts'/f'run_summary_{suffix}.json').write_text(json.dumps(summary,indent=2))
    assert all(r['status']!='failed' for r in results),'See failure files'

if __name__=='__main__':main()
