# Venue and format requirements

Source of every requirement: `/initial-state/inputs/0/deliverable.md` (objective, frozen) unless a row says otherwise.
Verified against the live official pages on 2026-11-04. "Not established" marks what I could not confirm.

## 1. Venue decision

**NeurIPS 2026 Main Track** (double-blind). Reasons: the objective requires one of ICML/ICLR/NeurIPS, the latest
edition's official template, and a conference-mandated checklist; NeurIPS 2026's template ships the checklist
(`checklist.tex`) and its handbook states the checklist is part of the single PDF. ICML 2026 (8 pages, no checklist
in its call) was the alternative and is not used. ICLR 2027 was not checked; NeurIPS 2026 is the latest NeurIPS edition.

Sources (fetched 2026-11-04):
- https://neurips.cc/Conferences/2026/CallForPapers (template zip link, deadlines)
- https://neurips.cc/Conferences/2026/MainTrackHandbook (page limit, checklist, anonymity, LLM policy, code)
- https://media.neurips.cc/Conferences/NeurIPS2026/Formatting_Instructions_For_NeurIPS_2026.zip
  (sha256 `82473931e3ef710fcd3f4a8cd4119b9de32e56825f90f9e5a6d55f2d01b817d9`; contents in `template/neurips_2026/`,
  unmodified, per-file sha256 in `template/neurips_2026/SHA256SUMS`; style file header `neurips_2026.sty` dated 2026-01-29)

## 2. Requirements (each checkable in the built PDF / repository)

| # | Requirement | Check |
|---|---|---|
| V1 | Official `neurips_2026.sty` unmodified; default (anonymous submission) option `\usepackage{neurips_2026}`; no changes of margins, fonts, spacing | `diff` against `template/neurips_2026/neurips_2026.sty`; `pdffonts` |
| V2 | Main text **at most 9 content pages, figures and tables included**. References, technical appendices and the checklist do not count (handbook). PDF ≤ 50 MB | page of last main-text line, `pdfinfo` |
| V3 | PDF order: main paper, references, appendices, checklist (template `\input{checklist.tex}` at the end) | `pdftotext` |
| V4 | Mandatory NeurIPS Paper Checklist, all 16 questions answered with `\answerYes/\answerNo/\answerNA` and a 1-2 sentence justification pointing to sections; no `\answerTODO`/`\justificationTODO` left; instruction block deleted, heading kept, questions unmodified (see `CHECKLIST_EVIDENCE.md`) | grep for `TODO` in built text |
| V5 | Required sections (objective): abstract, introduction, related work, method, experiments, discussion and limitations, references | section headings |
| V6 | Both PDF and LaTeX source delivered; source compiles from a clean checkout to the delivered PDF | `latexmk` |
| V7 | Anonymity: no author names/affiliations, no acknowledgments, self-citations in third person, no non-anonymous links (code referenced as "supplementary code" / anonymous placeholder); also holds for code ZIP and README content | grep |
| V8 | Every number, table and figure comes from a run of the shipped code; no placeholder or illustrative synthetic numbers; failed/abandoned/unfinished work reported as such (objective) | table/figure -> script map (V10) |
| V9 | Only real, consulted references; hallucinated citations violate the NeurIPS Code of Conduct. Starter-literature entries may be cited; every bib entry must be checkable (arXiv/DOI) | bib audit by review |
| V10 | Reproduction instructions (objective item 2): environment and pinned dependency versions; data acquisition steps and the exact data versions used with checksums (HELM v1.13.0 `summary.json` date; OLLB `contents` commit `9c09a7ca…`, `results` commit `aa81ecc3…`, as stated in `data.md`; any other version needs a written reason); license judgement for each data source (data.md: none declared, must be judged and noted); random seeds; run commands and expected runtime; **a table mapping each paper table/figure to the generating script** | file present and complete |
| V11 | Uncertainty reporting (objective review criterion): repeated runs / bootstrap CIs / significance tests for stated results; baselines, controls, ablations | in paper |
| V12 | Scope statement: conditions under which conclusions hold and fail (objective: "说明结论在什么条件下成立、在什么条件下不成立"), limitations section | in paper |
| V13 | Forbidden-material rule: nobody retrieves the already-published paper on this question or anything citing/discussing it (details in `deliverable.md`). If any such content is encountered, stop reading and record what, where and how much in the reproduction notes (a section titled for that purpose, even if the statement is "none encountered") | present in repro notes |
| V14 | LLM disclosure: required only if LLM/agent use is an important, original or non-standard part of the *method*; spelling/grammar/editing/code assistance not. This study has no LLM in its method, so the checklist item 16 (LLM usage) answer is NA unless that changes | checklist |
| V15 | Code ZIP for supplement (NeurIPS: separate anonymized ZIP, <= 100 MB; code should be executable, otherwise say why). Data used are public score tables; if raw data are not re-shipped, the download scripts must be | size, run |
| V16 | Impact: the checklist has Broader impacts and Safeguards items. The topic (strategic gaming of leaderboards) is dual-use-ish; the paper should address both honestly | checklist items 10, 11 |

## 3. Not established / caveats

- Submission deadlines of NeurIPS 2026 (May 2026) have passed; this is a format-conformance exercise, not a real submission.
  "Latest edition" is read as NeurIPS 2026.
- Exact line of "9 content pages" for this template: the `neurips_2026.tex` sample states nine pages including figures; the
  handbook says the same. The sample builds to 12 pages with its own instructions text, which is not a measure of the limit.
- The `final` camera-ready option (10 pages) is not used: the paper is a submission-format paper (anonymous).
- The licence of the OLLB / HELM score data is not declared by sources (data.md): the paper may only say what was checked
  and decided, never declare a licence.
- Whether the venue would accept appendix material for results the main claims rest on is a reviewer's decision; the
  safe approach is that main-text claims are supported by main-text evidence with the appendix for detail.

## 4. What I hand over

- `template/neurips_2026/` for `paper-repo` to copy into its layout (it owns where the files sit).
- `CHECKLIST_EVIDENCE.md`: for each of the 16 checklist questions what evidence has to exist and which position holds it.
- `venue-artifacts.json` (when the paper's file names are settled, see issue in `story-repo`).

## 5. Figure/table constraints that follow (for `figtab-repo`)

- Text width of the NeurIPS template is 5.5 in (single column, 13.97 cm); figures count against the 9 content pages, so design at
  full width 5.5 in or half width ~2.7 in; vector PDF output preferred; body-text-size fonts (>= 7 pt at final size).
- Do not rely on colour alone (reviewers may print); no author/institution marks in figures; every figure/table must
  carry uncertainty where the claim is numeric (V11) and have a generating script listed in the repro map (V10).
- Page budget is the venue's hard constraint: tell `paper-repo` early which figures go to the appendix.

## 6. Delivered paths (from `paper-repo` `.forgejo/CODEOWNERS`, story-repo#5)

`paper/main.pdf`, `paper/main.tex` (checklist included in it, V3/V4), `paper/neurips_2026.sty`, `REPRODUCE.md` (table/figure-to-script map and
forbidden-material record, V10/V13), `code/`, `data/`, `results/`, `figures/`, `tables/`. My own delivered path is `venue/`
(this document, the checklist evidence map, the template provenance copy). `venue-artifacts.json` requires
`paper/main.pdf`, `paper/main.tex`, `paper/neurips_2026.sty`, `REPRODUCE.md`, `code/`, `results/`, `figures/`, `venue/VENUE.md`.
`tables/` and `data/` are deliberately not required: the plan may place tables inline in the paper, and the data manifests
may live in `REPRODUCE.md`; V10 still requires the data versions and checksums wherever they sit.
