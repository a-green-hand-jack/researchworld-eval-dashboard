"""Explicit oracle circuits: expressivity witnesses, never trained baselines."""
import json,math
from pathlib import Path
import torch
from torch import nn
from train import Square

def construct(p,activation):
 residues=torch.arange(p).float()
 if activation=='relu':
  thresholds=torch.arange(-1,2*p-2).float() # -1 through 2p-3 inclusive, 2p-1 hidden units
  w=len(thresholds);first=torch.cat([residues[None,:]-thresholds[:,None]/2,residues[None,:]-thresholds[:,None]/2],1)
  last=torch.zeros(p,w)
  for c in range(p):
   for center in [c,c+p]:
    for k,coef in [(center-1,1),(center,-2),(center+1,1)]:
     if -1<=k<=2*p-3:last[c,k+1]+=coef
  phi=nn.ReLU()
 else:
  angle=2*math.pi*residues/p;co=angle.cos();si=angle.sin();w=8
  first=torch.stack([torch.cat([co,co]),torch.cat([co,-co]),torch.cat([si,si]),torch.cat([si,-si]),torch.cat([si,co]),torch.cat([si,-co]),torch.cat([co,si]),torch.cat([co,-si])])
  last=torch.stack([co,-co,-co,co,si,-si,si,-si],1)/4;phi=Square()
 model=nn.Sequential(nn.Linear(2*p,w,bias=False),phi,nn.Linear(w,p,bias=False))
 with torch.no_grad():model[0].weight.copy_(first);model[2].weight.copy_(last)
 a=torch.arange(p).repeat_interleave(p);b=torch.arange(p).repeat(p);labels=(a+b)%p
 x=torch.cat([nn.functional.one_hot(a,p),nn.functional.one_hot(b,p)],1).float()
 with torch.no_grad():
  logits=model(x);accuracy=(logits.argmax(1)==labels).float().mean().item()
  sorted_logits=logits.sort(1,descending=True).values;margin=(sorted_logits[:,0]-sorted_logits[:,1]).min().item()
  expected=nn.functional.one_hot(labels,p).float() if activation=='relu' else (2*math.pi*(a[:,None]+b[:,None]-torch.arange(p)[None,:])/p).cos()
  error=(logits-expected).abs().max().item()
 assert accuracy==1.0
 return dict(p=p,activation=activation,width=w,parameters=3*p*w,exhaustive_pairs=p*p,exhaustive_accuracy=accuracy,minimum_logit_margin=margin,max_logit_identity_error=error,oracle_uses_known_formula=True,trained=False)
if __name__=='__main__':
 torch.set_num_threads(1)
 rows=[construct(p,act) for p in [31,47] for act in ['relu','square']]
 Path('paper/generated/expressivity.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
