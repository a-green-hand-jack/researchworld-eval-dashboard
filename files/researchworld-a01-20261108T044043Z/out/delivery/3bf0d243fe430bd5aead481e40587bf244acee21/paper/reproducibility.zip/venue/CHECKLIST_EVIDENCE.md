# NeurIPS 2026 checklist: evidence each answer needs

Answers are the report position's; this table says what must exist for an honest `Yes`, and what the likely answer
is for this study (from the objective: public score tables, CPU only, no human subjects, no model training).
"Expected" is a planning expectation, not an answer; a `Yes` without the evidence is a mismatch to fix, `No`/`NA` with a
justification is acceptable to the venue.

| # | Item | What must exist | Holder | Expected |
|---|---|---|---|---|
| 1 | Claims | abstract/intro claims each traceable to a result and a stated scope (conditions where it holds / fails) | paper, analysis | Yes |
| 2 | Limitations | a Limitations section: cap/modelling assumptions, snapshot data, rule set, what was not tested | paper | Yes |
| 3 | Theory assumptions and proofs | if the paper states any proposition/solver-optimality claim: assumptions and a full proof (appendix ok); otherwise NA | analysis, paper | Yes if exact-solver propositions are stated, else NA |
| 4 | Experimental reproducibility | data versions, rule definitions, cap scenarios, eps margin, seeds, solver details in paper/appendix | analysis, paper | Yes |
| 5 | Open access to data and code | anonymized code ZIP, commands, data download steps with versions/checksums (V10, V15) | analysis, paper | Yes |
| 6 | Experimental setting/details | all choices (task subsets, normalisation, dedupe, bootstrap/MC settings) stated | analysis, paper | Yes |
| 7 | Statistical significance | CIs/bootstrap/MC over tasks and models for the headline numbers | analysis | Yes (must be backed by actual intervals in the figures/tables) |
| 8 | Compute resources | CPU type, runtime, memory (objective: CPU only, budget 4 CPU-hours estimated, not measured; report measured) | analysis | Yes |
| 9 | Code of ethics | statement conforming; data are public scores | paper | Yes |
| 10 | Broader impacts | gaming incentives; benefits for leaderboard designers vs. risks of a how-to for manipulation | paper | Yes |
| 11 | Safeguards | no high-risk model/data released: NA with justification | paper | NA |
| 12 | Licenses for existing assets | each source (HELM bucket/code Apache-2.0, OLLB datasets, cais/mmlu MIT, lm-eval-harness) with licence status as checked; "not declared" stated as such | idea/paper | Yes/No with justification |
| 13 | New assets | released code and derived tables: documented; if nothing beyond code, say so | paper | Yes |
| 14 | Crowdsourcing / human subjects | none | paper | NA |
| 15 | IRB | none | paper | NA |
| 16 | LLM usage | LLM not part of the method (V14) | paper | NA |

Rules for filling it: keep the section heading `NeurIPS Paper Checklist`, delete the instruction block between
`%%% BEGIN/END INSTRUCTIONS %%%`, keep questions and guidelines verbatim, use only the macros.
