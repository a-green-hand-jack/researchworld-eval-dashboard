# Restricted primary-source reading notes: binary model–item prediction

**Read/verified:** 2026-11-02 UTC. **Scope:** exactly the seven user-allowlisted arXiv papers, plus explicitly allowed official NeurIPS 2026 template/rule material. This is a restricted reading report, not an exhaustive related-work or novelty search. No identity is assigned to the user's unidentified excluded paper.

## 0. Access, reading depth, and restriction audit

- Followed `/skills/paper-navigator/SKILL.md` **POINT/known-paper** routing: direct primary retrieval, no discovery, no citation expansion. Used direct `requests.get` downloads of the seven `https://arxiv.org/pdf/<allowlisted-ID>` URLs and their same-ID `/abs/` pages for metadata. All fourteen primary requests returned HTTP 200. No account/API/token was used.
- PDFs are saved as `/work/literature/<ID>.pdf`; reference-truncated readable bodies as `/work/literature/<ID>.body.txt`. Read all seven main texts at analytical/technical depth, focusing on equations, methods, protocols, tables, and limitations. **Appendices were not read**, because they follow references; no claim of complete implementation-level reproduction is made.
- `pdftotext` was not installed. Attempting to install `poppler-utils` failed because apt lacked permission for `/var/lib/apt/lists/partial`. Used `pypdf` extraction instead, not a fabricated `pdftotext` result. Layout extraction initially failed to recognize four reference headings; those uncut files were **not displayed/read**, and were overwritten by safe extraction using normal text order. Final extraction found a References heading in every paper and withheld everything from that heading onward. An extraction warning about form XObjects occurred; figure text and typography may be incomplete. Equations below were reconstructed from readable main-text expressions, not code.
- Reference lists begin on PDF pages 10, 10, 11, 10, 12, 14, and 10 respectively for [1]–[7]. The safe body files retain the pre-heading text on those pages, not bibliographies. Automated PDF text processing scanned headings; this is distinct from reading/displaying bibliography contents.
- No search engine, citing page, bibliography traversal, paper-linked repository, dataset site, external reference, or recommended-paper page was opened. URLs reported as code/data availability below are **printed in the allowed papers**, not independently inspected.
- **Incidental exposure, explicitly disclosed:** the allowed official NeurIPS `.tex` template displayed its sample bibliography boilerplate during template inspection; the allowed official handbook displayed its Further reading link labels. None of those referenced documents was opened or used. The allowed papers' main texts also contain ordinary in-text citations/related-work discussion. No attempt was made to identify the excluded paper from any names/titles; because its identity is unknown, absence of all incidental mentions cannot be certified.
- Access failures: guessed official NeurIPS style-page URL returned 404; official CFP → official ZIP succeeded. No allowlisted paper failed. No experiment code was implemented, no dataset was downloaded, and no experiments were run.
- Provenance artifacts: `download_log.json`, `extraction_log.json`, `primary_metadata.json`, `file_manifest.json`, `template_access_log.json`. Unversioned URLs were requested; PDF front matter and same-ID submission histories establish the versions read below. Retained PDF hashes identify the actual bytes.

## 1. Task definition and baseline distinctions

Let `Y ∈ {0,1}^{M×N}` be correctness, with rows = models and columns = benchmark items. Historical/source model rows are available in full. For a new model `m`, observe only a context/query set `S_m` of size `b`; predict `p_mi` on `U_m = {1,…,N} \ S_m`.

Distinguish four tasks rather than silently changing the target:

1. **Known-item, new-model prediction:** unseen model row, historically calibrated item columns. Appropriate for IRT, nearest-source and response-matrix regressions.
2. **New-item prediction:** test columns have no historical source responses. A free learned item ID or fitted item difficulty cannot solve this without additional features or calibration. [4] explicitly uses prompt features; [5] studies a text-feature cold-start setting.
3. **Aggregate score prediction:** `A_m = Σ_i w_i Y_mi`, for fixed known weights summing to one. Good aggregate MAE can coexist with bad entrywise predictions. If a benchmark macro-averages scenarios, `w_i` must reflect that; a flat item mean is not generally equivalent.
4. **Ranking:** ordering `A_m` or a model-derived ability score, possibly with ties. Ranking correlation and selective pairwise confidence are not calibrated entrywise probabilities.

### Recommended minimum baseline suite

| Baseline | Entrywise output? | Why include / status |
|---|---|---|
| Source item mean | Yes, ignores new-model context | Essential zero-shot/difficulty control; closely related to mean-source baseline in [1]. |
| Context row mean / intercept | Yes, identical probability for all unobserved items | Cheap ability-only control; recommendation, not a claimed novel or exact named method. |
| Nearest source / soft k-nearest source | Yes | Strong nearest-source precedent in [1]; binary and soft-k variants must be labeled adaptations. |
| Regularized Bernoulli 1PL and multidimensional 2PL IRT | Yes, known items | Directly justified by [2]; factorization of binary logits is not new merely because it is called matrix completion. |
| Random-context ridge → full score | No, aggregate-only | **Random-Sampling-Learn** is a strong mandatory score baseline from [6]. |
| Random-context ridge → each unseen column | Yes | Natural entrywise adaptation of response regression, not the exact named score-only baseline in [6]. |
| Uniform/stratified sample mean | No meaningful individual predictions | Essential source-free score baseline; must not be omitted in frontier tests [6]. |
| Residual-corrected/AIPW-style estimator | Aggregate correction around entrywise predictor | Strong score baseline [6]; its unbiasedness/consistency needs sampling and fitting conditions, not just the label “AIPW”. |
| Binary correctness clustering + cluster-weighted score | Primarily aggregate | Direct binary-compatible anchor selection from [2]; not original confidence-based APW [1]. |
| Prompt-feature generic assessor | Yes, including new items | Particularly important if new-item/inductive generalization is claimed [4]. Requires features absent from a matrix-only setting. |
| Neural-process predictor + random/static/adaptive acquisition | Yes | Advanced acquisition/prediction comparison from [5], only if implementation resources and text features are available. |

For an initial matrix-only study, prioritize the first eight rows over an expensive RL implementation. Include the assessor when item text/features are available. metabench and continuous CAT are useful aggregate/ranking comparators, not drop-in full binary-matrix predictors.

## 2. Verified paper cards, equations, and protocols

### [1] Anchor Points

**Full title:** Anchor Points: Benchmarking Models with Much Fewer Examples  
**Full authors:** Rajan Vivek; Kawin Ethayarajh; Diyi Yang; Douwe Kiela.  
**Metadata:** first submitted 2023-09-14; **v2, 2024-02-18 read**. A venue was not established from the inspected primary metadata; do not invent one.  
**Exact primary URLs accessed:** https://arxiv.org/pdf/2309.08638 ; https://arxiv.org/abs/2309.08638

**Supporting quotes, each ≤80 characters:**
- “we take the logit transform of the confi-” — §4, PDF p.4.
- “Nearest Source Neighbor is a Strong Baseline” — §6, PDF p.7.
- “Anchor Points Do Not Always Generalize” — §8, PDF p.9.
- “We randomly select 10 models to be source models” — Table 2, PDF p.7.

**Verified method:** It operates on model **class-probability/confidence** predictions, not merely binary correctness. For item `i`, collect source models' correct-class confidences `q_si`; compute `C_ij = corr_s(logit(q_si), logit(q_sj))`. Distance is `D_ij = 1−C_ij`. Select `b` medoids using PAM to minimize

`Σ_{a∈S} Σ_{j∈Q_a} (1−C_aj)`.

The original **Anchor Point Weighted (APW)** score is

`APW(m) = Σ_{a∈S} (|Q_a|/N) q_ma`,

intended to correlate with benchmark performance; it is **not necessarily an unbiased accuracy estimate**. The **Anchor Point Predictor (APP)** fits univariate linear models from an anchor's model predictions to predictions on other items in that anchor's cluster. Main text identifies it as an ensemble; exact fitting/prediction pseudocode is in unread appendices. Do not pretend it is one arbitrary ridge model or a binary logistic model.

**Nearest Source Neighbor:** observe the new model on `b` randomly selected items, find the source with minimum L1 distance on the observed predictions, and borrow that source's predictions elsewhere. For a binary adaptation,

`s* = argmin_{s∈sources} Σ_{i∈S_m} |Y_mi−Y_si|; p_mj = Y_s*j`.

That formula is an explicitly labeled binary adaptation of the confidence-prediction method; optionally average k neighbors, but call it a variant.

**Data/protocol:** six GLUE tasks, MNLI/SST-2/QQP/RTE/MRPC/QNLI; 87 model–prompt pairs spanning BERT, GPT, instruction-tuned GPT, and OpenAI families. Table 2: 10 random source models, 77 held-out target models, 100 randomized runs; Kendall τ AUCC normalized over budgets 1–30. Table 3: same source/target sizes and runs; instance-level metric is **predicted class agreement**, not binary correctness-probability calibration. Reported mean agreement at b=10: APP 0.80 vs nearest source 0.79; large variability across target models remains. Table 2 mean AUCC: APW 0.612, APP 0.571, random exact-score 0.528. These numbers are contextual, not expected results on a binary matrix.

**Failure modes:** source/target correlation shift, sparse minority regions poorly represented, diminishing returns, possible underperformance versus random at larger budgets, quadratic item-pair correlation cost. Binary endpoints make the original logit-confidence correlation undefined; clipping 0/1 and calling it an exact APW reproduction would be misleading. For binary-only work prefer [2]'s correctness clustering, and specify constant-column handling.

**Code/data availability:** no primary repository URL was established in the inspected pre-reference body. No external code search was attempted.

### [2] tinyBenchmarks

**Full title:** tinyBenchmarks: evaluating LLMs with fewer examples  
**Full authors:** Felipe Maia Polo; Lucas Weber; Leshem Choshen; Yuekai Sun; Gongjun Xu; Mikhail Yurochkin.  
**Metadata:** first submitted 2024-02-22; **v2, 2024-05-26 read**; PDF identifies ICML 2024, PMLR 235.  
**Exact primary URLs accessed:** https://arxiv.org/pdf/2402.14992 ; https://arxiv.org/abs/2402.14992

**Supporting quotes:**
- “The two-parameter multidimensional IRT model assumes” — §4.1, PDF p.4.
- “The generalized p-IRT (gp-IRT) estimator.” — §4.2, PDF p.5.
- “dimensions in {2, 5, 10, 15}.” — §4.4, PDF p.6.
- “Results are averaged over 5 restarts.” — §5, PDF p.7.

**Direct binary baseline:** its multidimensional 2PL response model is

`p_mi = σ(α_iᵀ θ_m − β_i)`.

Learn item parameters on source rows; freeze them; fit the new model's `θ_m` by maximizing Bernoulli likelihood on observed items `S_m` only. The main text equates the latter step to logistic regression with fixed item features. The paper's hierarchical variational fitting uses Gaussian parameter priors, Gaussian hyperpriors `N(0,10)` for prior means and Gamma(1,1) precision hyperpriors; point estimates are variational means. Dimension is selected by source-data validation from `{2,5,10,15}`. A penalized point-estimate logistic factorization is an adaptation, not exact Bayesian reproduction.

**p-IRT aggregate estimator, uniform item weights:**

`Â_pIRT(m) = [Σ_{i∈S_m} Y_mi + Σ_{i∈U_m} p̂_mi]/N`.

Observed outcomes are retained exactly. Benchmark scenario weights require the corresponding weighted generalization. Do not average only p̂ over the entire benchmark and call it the exact p-IRT estimator.

**gp-IRT:** let `Â_anchor = Σ_{a∈S} w_a Y_ma` with cluster weights summing to one. Then

`Â_gpIRT = λ Â_anchor + (1−λ) Â_pIRT`.

For random samples, the stated heuristic is `λ = b̂²/(σ̂²/b + b̂²)`: `σ̂²` is average within-source outcome variance; `b̂²` is the square of a held-out-source bias estimate. They split source models, refit IRT on the first part, infer abilities for the second using half the items, predict the unseen half, take model-wise absolute aggregate errors, average these, and square the average. For anchors they divide the variance term by **4** by default. This is important tuning logic, not a universal uncertainty guarantee or arbitrary λ=0.5. All such calibration must stay inside source data.

**Selection:** K-means on item correctness vectors across source models, or on fitted `(α_i,β_i)`; choose the closest **actual item** to each centroid; weight by the fraction of benchmark items in the cluster. Stratified sampling balances subscenario counts as nearly equally as possible; ensure the eventual score matches the benchmark's intended weighting.

**Data/protocol:** Open LLM Leaderboard: 395 models, six scenarios, about 29K examples, 75%/25% train/test models, random or by date. MMLU uses the same models/splits, 57 subjects, about 14K items. HELM Lite v1.0.0: 30 models, ten scenarios, about 10K examples; random split uses 11-fold model CV; shift uses organization-separated models. AlpacaEval 2.0: 100 models ×805 examples; four-fold random CV or latest 25% test models. Five restarts; score absolute error, with rank correlation shown in an appendix not read. A **40 specialized-model** MMLU test probes domain shift. About 2% average score error at 100 items **per scenario**, not 100 for an entire six-scenario leaderboard.

**Failure modes/caveats:** correctness clustering degrades on specialized models; IRT misspecification and capability extrapolation can bias p-IRT; extreme source/target pattern changes require refreshing item calibration. A new row with all 0s/all 1s can have divergent unregularized ability MLE; use a declared prior/penalty and label the choice. These are correctness probabilities under the IRT model; aggregate error evidence is not a calibration study.

**Reported availability, not opened:** https://github.com/felipemaiapolo/tinyBenchmarks ; https://huggingface.co/tinyBenchmarks . PDF says code, pretrained IRT models, tiny datasets and tutorials are released. Current functionality/license not independently verified.

### [3] metabench

**Full title:** metabench -- A Sparse Benchmark of Reasoning and Knowledge in Large Language Models  
**Full authors:** Alex Kipnis; Konstantinos Voudouris; Luca M. Schulze Buschoff; Eric Schulz.  
**Metadata:** first submitted 2024-07-04; **v2, 2025-02-20 read**; PDF identifies ICLR 2025. The primary HTML metadata indexes the third author as “Buschoff, Luca M. Schulze”; the PDF displays the full name above, preserved in BibTeX as the compound surname Schulze Buschoff.  
**Exact primary URLs accessed:** https://arxiv.org/pdf/2407.12844 ; https://arxiv.org/abs/2407.12844

**Supporting quotes:**
- “We use one-dimensional” — §2.3, PDF p.5.
- “we subsampled all six benchmarks to 350 items.” — §2.2, PDF p.5.
- “858 items” — Figure 1, PDF p.2.
- “conditional independence of the LLMs” — §4.1, PDF p.10.

**Pipeline, not a bare IRT baseline:** preprocess → repeated random subset search with a GAM score decoder → IRT → information filtering → GAM score reconstruction (possibly jointly across benchmarks). Source data include 6,875 unique models after initial exclusions, 5,055 evaluated on all six tasks, and >152M responses. Benchmarks: ARC/GSM8K/HellaSwag/MMLU/TruthfulQA/WinoGrande, 28,632 total items.

For each benchmark, drop bottom 0.1% model scores, items with standard deviation <1%, mean accuracy >95%, and near-zero point-biserial item/total correlation. A global 10% model test set is stratified by overall score; a further 10% local validation subset is stratified by per-benchmark score. The wording does not establish an exact reusable random seed or whether that local 10% denominator is all rows versus remaining rows; no exact 80/10/10 reproduction is claimed.

Random-subset search: fit a GAM `ŝ_m = g(subtest_score_m)` on training models, choose subset by validation RMSE over 10,000 trials. Preselect 350 items per benchmark. Fit one-dimensional 2PL/3PL/4PL using R/mirt and compare MAP and EAPsum ability estimates. For 2PL,

`p_mi = σ(a_i θ_m − δ_i); I_i(θ) = a_i² p_i(θ)(1−p_i(θ))`.

Partition the ability support into quantiles, greedily select informative items above threshold τ, remove already selected items, and tune IRT type, ability estimator and threshold on validation score using `RMSE + λk`, with tested λ `{0.01,0.005,0.001}` and chosen trade-off 0.005. The final score decoder uses latent abilities **and subtest scores**; the joint decoder leverages all six benchmarks. Exact GAM formula and some selection settings are in unread appendices, so not fully reproducible from this reading alone.

**Verified result:** 858 retained items across six benchmarks, test mean per-benchmark RMSE 1.24 percentage points using joint reconstruction; overall leaderboard RMSE 0.582 points, Spearman 0.998 (Table 2/§2.5). This is not a direct comparison to tinyBenchmarks on the same source-model population or a 100-total-item result; it uses many more historical models and joint information. The final system calibrates only preselected item sets, not every original column for entrywise prediction.

**Uncertainty and pitfalls:** reconstruction intervals are described as nonparametric intervals from local test RMSE, not proven distribution-free coverage under arbitrary shifts. Do not use final test rows to tune interval widths in a new study. Related model checkpoints violate independence; random row splitting can exaggerate generalization. Static item sets risk memorization; they provide disjoint versions and answer permutations. Preprocessing statistics should be recomputed on training data only in a leakage-controlled adaptation; the described pipeline performs initial cleaning before its split, so match versus improve the protocol explicitly rather than claiming equivalence.

**Reported availability, not opened:** https://github.com/adkipnis/metabench ; https://huggingface.co/datasets/HCAI/metabench . PDF describes R scripts, released IRT/GAM models, and lm-evaluation-harness integration. Repository contents/license not verified.

### [4] 100 instances

**Full title:** 100 instances is all you need: predicting the success of a new LLM on unseen data by testing on a few instances  
**Full authors:** Lorenzo Pacchiardi; Lucy G. Cheke; José Hernández-Orallo. The PDF shortens the middle name to Lucy Cheke; same-ID primary metadata supplies “G.”  
**Metadata:** **v1, 2024-09-05 read**; PDF identifies GenAI Evaluation KDD2024 workshop, August 25, 2024. Do not mislabel this as a main-track KDD paper.  
**Exact primary URLs accessed:** https://arxiv.org/pdf/2409.03563 ; https://arxiv.org/abs/2409.03563

**Supporting quotes:**
- “We use the Area Under the Curve (AUC) as a metric” — §4.3, PDF p.7.
- “the performance on the test set saturates” — §4.3, PDF p.7.
- “XGBoost generally performs better.” — §4.3, PDF p.7.
- “1024 (out of” — §4.2, PDF pp.6–7.

**Directly relevant conditional predictor:** choose reference items `R⊂D_train`; represent model m by its correctness signature `g(m)=(Y_mr)_{r∈R}`; predict

`p̂_mi = h_φ([g(m), f(x_i)])`.

Train h on pairs in `models_train × items_train`, minimizing classification loss; tune using validation models and validation items. New model only needs evaluation on R. New item requires intrinsic features `f(x_i)`, not an observed historical response column. This is **two-axis inductive prediction**, a stronger item-generalization setting than ordinary fixed-benchmark matrix completion.

Assessor options: logistic regression with L1/L2 penalties, XGBoost; features: 1024 prefix dimensions of OpenAI text-embedding-3-large, or cosine similarities to reference-item embeddings, with optional explicit similarity×success interactions. A plain additive logistic model on concatenated features cannot express arbitrary model×item interactions; include the interaction variant or nonlinear predictor when reproducing that aspect.

Selectors: K-means representatives or factor analysis on intrinsic embeddings, binary source-success vectors, or 10D IRT item parameters; compare random and **random best of 20**, whose selection must use validation data and counts as a tuning budget. Reference size around 100 saturates in their experiments; it is not a universal sample-complexity theorem.

**Data/splits:** binary-only HELM-Lite subset: 30 models ×4,285 items in six scenarios. Model split: 18 train/4 validation/8 test, with test models from Anthropic and Meta absent from training. KindsOfReasoning: 14 OpenAI models ×37,529 items across 22 datasets; model split 8/2/4, with GPT-4 versions as test models. In-distribution item splits: HELM 2,400/600/1,285; reasoning 21,016/5,254/11,259. Additional item-OOD splits hold out entire reasoning/task groups. Model-selection criterion is **average validation-model win rate of AUC**, not simply pooled AUC. Main results are per-target-model AUC. No probability calibration guarantee; the paper explicitly notes AUC is insensitive to monotonic distortion.

**Findings/pitfalls:** random references often match advanced selection; generic assessor approaches but usually trails a model-specific assessor trained with all target-row training labels. OOD results degrade and no method wins uniformly. The full-data specific assessor is **not query-budget matched** and should be labeled an information-rich reference. Original embeddings use a paid API; replacing them with a local encoder is a necessary no-account adaptation if features are not already available, not an exact reproduction. We did not access that API.

**Reported availability, not opened:** https://github.com/LoryPack/ReferenceInstancesPredictability ; https://github.com/Kinds-of-Intelligence-CFI/KindsOfReasoning . The second is the reported raw-output/evaluation-data location; availability/license not independently verified.

### [5] Active Evaluation Acquisition

**Full title:** Active Evaluation Acquisition for Efficient LLM Benchmarking  
**Full authors:** Yang Li; Jie Ma; Miguel Ballesteros; Yassine Benajiba; Graham Horwood.  
**Metadata:** **v1, 2024-10-08 read**. No venue was established from the inspected front matter/metadata.  
**Exact primary URLs accessed:** https://arxiv.org/pdf/2410.05952 ; https://arxiv.org/abs/2410.05952

**Supporting quotes:**
- “We represent the relationship between the prompts and” — §2.2, PDF p.2.
- “Set Transformer architecture” — §2.2, PDF p.3.
- “uncertainty and information gain based policies consistently fail” — §4, PDF p.9.
- “all binary accuracy.” — MMLU data description, PDF p.8.

**Predictor:** learn arbitrary-context conditional score distributions using a latent neural process,

`p(Y_U | Y_S,X) = ∫ p(z | Y_S,X) p(Y_U | z,Y_S,X) dz`.

Train with an ELBO using randomly drawn disjoint context and target subsets from historical full model rows. Encoder/prior/posterior use self-attention with Set Transformer induced points; decoder cross-attends to observed prompt–score pairs. Prompt representations use SFR-Embedding-Mistral in main experiments. Exact likelihoods, neural dimensions, sampling/training settings, and PPO details require unread appendices; a small masked MLP or plain IRT is **not** this method.

**Acquisition comparisons:** random/uniform, scenario-stratified, static embedding/correctness/IRT clustering, greedy combinatorial selection, uncertainty, information gain, and PPO-based RL. Dynamic policies recompute after every acquired score. Reward is the reduction in average prediction error on remaining prompts,

`r(S,i) = E[||Ŷ_U−Y_U||²]/|U| − E[||Ŷ_U'−Y_U'||²]/|U'|`,

where `S'=S∪{i}`, `U'=U\{i}`; full responses are used for rewards **during source-model training only**. RL also receives model-predicted scores/uncertainties. Final score combines observed actual scores with predicted missing scores, with dataset weighting. Entropy sampling or Fisher-information CAT is not an exact implementation of this RL policy.

**Data/protocol:** Open LLM Leaderboard 2,084 models ×28,659 prompts; 1,000 older evaluated models train, remaining more recently evaluated models test. MMLU same model set, 14,042 binary questions/57 subjects. HELM-Lite 33 models ×13,021 prompts; 23 random training models. AlpacaEval 130×805, 70% random train. Their “Chatbot Arena” experiment uses **first-turn pairwise annotations on 80 MTBench prompts involving six models**, not a dense live-Arena correctness matrix; model-held-out pairs define test. Missing acquired scores there are filled by the NP itself, an important surrogate-label caveat. Three random seeds; score absolute error and standard deviation. Additional organization shift tests and MMLU cold start withholding responses on 15 subject subsets. Cold start assumes new prompt text is known; uses uncertainty-threshold pseudolabeling.

**Verified numeric comparison/caution:** Table 1 MMLU b=100: tinyBenchmarks selected prompts + IRT error 0.022; RL-selected + IRT **0.028**; TB+NP 0.016; RL+NP 0.013. Thus the text's blanket assertion that RL wins with either predictor has a **table counterexample**. Avoid reproducing it uncritically. Predictor and acquisition must be ablated separately. Table 2 also shows NP imputation can hurt some policies/tasks, notably their sparse pairwise experiment.

**Failure modes:** uncertainty/information-gain policies fail to explore in their tests; embedding similarity need not imply response similarity; source-model bias and unseen prompts remain harder; greedy static optimization is expensive. The paper's claimed O(b) RL acquisition treats policy computation as constant cost, but scoring/masking candidate prompts and encoding sets still matter in implementation; do not advertise benchmark-size-independent wall time without measurement. ELBO fitting does not by itself establish exact stochastic-process consistency or calibrated predictive intervals.

**Availability:** no own code repository URL was established in the inspected main text. Do not confuse its footnote link to tinyBenchmarks code with a release of AEA. No repository discovery attempted.

### [6] How Benchmark Prediction from Fewer Data Misses the Mark

**Full title:** How Benchmark Prediction from Fewer Data Misses the Mark  
**Full authors:** Guanhua Zhang; Florian E. Dorner; Moritz Hardt.  
**Metadata:** first submitted 2025-06-09; **v2, 2026-07-21 read**. This reading is the 2026 revision, not automatically the 2025 original. No venue established.  
**Exact primary URLs accessed:** https://arxiv.org/pdf/2506.07673 ; https://arxiv.org/abs/2506.07673

**Supporting quotes:**
- “Random-Sampling-Learn” — §3.2, PDF p.6.
- “we fit a regression model to predict the” — §1.1, PDF p.3.
- “The lowest-performing50%” — §4.3, PDF p.9.
- “the top30% serve as target models” — §4.3, PDF p.9.
- “beating Random-Samplingin all” — §4.3, PDF p.10.

**Must-run aggregate baseline:** random item set S, fit ridge over source **model rows** to predict each source's full-benchmark mean from its response vector on S:

`(ĉ,v̂) = argmin_{c,v} Σ_{s∈sources} (A_s−c−vᵀY_sS)² + λ||v||²; Â_m=ĉ+v̂ᵀY_mS`.

This formalizes the paper's Random-Sampling-Learn description; intercept/penalty conventions and λ selection are not fully specified in the main text. Random-Search-Learn repeats subset/ridge search 10,000 times with cross-validation selection. It is a costlier comparator, not an equally untuned random baseline. This score-level regression is **not identical to entrywise matrix completion**.

**AIPW-style baseline, exact main-text estimator algebra:** for each new model, fit ridge `g_m` across **observed item rows** to predict that model's correctness from the vector of historical source responses on each item. Write `q_i=g_m(Y_sources,i)`, `ȳ_S=mean_S Y_mi`, `q̄_S=mean_S q_i`, `q̄_U=mean_U q_i`. Their equation (3) is

`Â_AIPW = ȳ_S + [(N−b)/N](q̄_U−q̄_S)`

`             = (1/N)Σ_i q_i + (1/b)Σ_{i∈S}(Y_mi−q_i)`.

The coefficient `(N−b)/N` is the paper's `1/[1+b/(N−b)]`; omitting it while using an **unobserved-only** predicted mean changes the estimator. `g_m` has a different regression orientation and target from Random-Sampling-Learn. These are not interchangeable implementations.

**Statistical caveat:** the paper claims consistency and lower variance, not exact finite-sample unbiasedness for any learner fitted on the same observations. With fixed predictions independent of a uniform sample, the residual correction has a standard design-unbiased interpretation. Fitting a flexible predictor on S, deterministic/adaptive selection, unavailable propensities, weight mismatch, or clipping the final corrected score can invalidate simple guarantees. If cross-fitting or an independent random residual-audit sample is used, label it a robustness adaptation and specify fitting/sampling conditions; do not attribute that implementation to the unread paper code. Keep point predictions and corrected aggregate scores distinct.

**Data/protocol:** 19 binary-accuracy benchmarks: six HELM-Lite tasks with 83 models; five GLUE tasks with 87 model–prompt pairs; seven OpenLLM tasks with 448 models; ImageNet with 110 models. QQP excluded due to broken supplied score file. Main budget 50, ablations `{10,20,50,100,200}`, 100 random trials. Interpolation: random 75% source/25% target models. Extrapolation: lowest-scoring 50% source, highest-scoring 30% target, middle 20% unused. This is a deliberately oracle-defined **offline stress split**, not a deployable procedure that knows a new model's full accuracy without evaluation. Metric: mean absolute full-benchmark score error across targets; normalized analysis divides per-target absolute error by `sqrt(A_m(1−A_m))` and handles endpoints explicitly.

**Verified results (Table 1):** at b=50, interpolation absolute gap in percentage points: random 4.8, random+ridge 2.9, AIPW 3.2, random-search+ridge 2.7. Under extrapolation: random 4.6, random+ridge 13.6, AIPW 4.0, random-search+ridge 12.8. These are averages across heterogeneous benchmarks, not binary entrywise losses. AIPW beats random in all 19 extrapolation benchmarks in their reported study, but gains shrink as model similarity decreases. Do not universalize this as proof that a particular implementation always improves variance in finite samples.

**Similarity diagnostic:** uses chance-corrected source/target agreement (Cohen-kappa-type) averaged over sources. Full-matrix similarity requires held-out outcomes and is suitable **only for retrospective analysis**, not acquisition, validation selection or deployable confidence unless separately estimated from available observations.

**Reported availability, not opened:** https://github.com/socialfoundations/benchmark-prediction . Code availability is printed on PDF p.1; no contents/license verified. Appendix algorithms and exact ridge/PCA/optimization hyperparameters remain unread.

### [7] Confident Rankings

**Full title:** Confident Rankings with Fewer Items: Adaptive LLM Evaluation with Continuous Scores  
**Full authors:** Esma Balkır; Alice Pernthaller; Marco Basaldella; José Hernández-Orallo; Nigel Collier.  
**Metadata:** first submitted 2026-01-20; **v2, 2026-09-14 read**. No venue established from inspected metadata/front matter.  
**Exact primary URLs accessed:** https://arxiv.org/pdf/2601.13885 ; https://arxiv.org/abs/2601.13885

**Supporting quotes:**
- “Continuous Scores” — title, PDF p.1.
- “99% accuracy on confident predictions” — abstract, PDF p.1.
- “all temperature variants of hold-out models are ex-” — §7.1, PDF p.6.
- “family-wise error rate (FWER).” — §9, PDF p.10.

**Scope:** continuous generation scores and adaptive model ranking, not a demonstrated new binary matrix predictor. It reviews binary 1PL `p_i(θ)=σ(a(θ−b_i))`, shared discrimination a, information `I_i(θ)=a²p_i(1−p_i)`. The new continuous model is

`Y_mi | θ_m,b_i,k ~ Normal(μ_mi, k μ_mi(1−μ_mi)); μ_mi=σ(θ_m−b_i)`.

The paper's full continuous Fisher information is `μ(1−μ)/k + (1−2μ)²/2`; the **implemented selection** uses only the first term. It says item ordering agrees with full FI when `a=1/sqrt(k)>sqrt(2)` (eight of nine metric pairs), and reports empirical comparison in an unread appendix. The Gaussian has unbounded support; treating it as Bernoulli on a binary matrix would not be an exact or well-motivated reproduction. For binary work use Bernoulli CAT as a labeled comparator.

**Calibration described:** average score per item over calibration model–temperature configurations; normalize a narrow score range to `[ε,1−ε]` before difficulty logits; `b_i=−logit(p̄_i)`. Estimate global `k=Σ_ij(y_ij−μ_ij)²/Σ_ij μ_ij(1−μ_ij)` using model abilities from logits of scaled row means. Filter negatively correlated item scores from the adaptive pool. These are the stated operational rules; do not silently replace them with jointly optimized item parameters or assume marginal logits solve every latent-trait likelihood. Exact ε/scaling and posterior-grid/update details require more implementation evidence.

**Ranker:** independent per-model ability posteriors, warm-up maximum-information items, test uncertain adjacent pairs, and choose the model with largest

`value_m = SE_m² / [(n_m+1)c_m]`.

Pairwise approximate confidence is `Φ((θ̂_i−θ̂_j)/sqrt(SE_i²+SE_j²))`. Choose next item by maximum information at the selected model's current ability. Stop with resolved comparisons, ties, or budget exhausted. **Implementation ambiguity:** Algorithm 1 declares uncertainty between `1−γ` and `γ`, while the prose stopping rule uses two-sided cutoffs `(1−γ)/2` and `1−(1−γ)/2`. At γ=.95 these mean .95 versus .975 one-sided confidence. Pseudocode uses per-model max-items conditions while later prose emphasizes a total cost budget. These choices must be resolved and documented, not silently called identical.

**Data/protocol:** five generation datasets/nine metric pairs: BioLaySumm val 1,376 items (ROUGE-L/BERTScore/FKGL), GovReport val 973 (ROUGE-L), TruthfulQA val 817 (judge/BERTScore difference), FLORES devtest 1,012 (TR→EN, COMET/BLEU), Nemotron-PII test 2 2,000 (span F1). 21 models, six families, temperatures `{0,.4,.7,1}` giving 84 configurations. Five disjoint four-model holdout sets; **all temperatures of a held-out model excluded from calibration**; remaining 17 models/68 configurations calibrate, test at T=0. Nominal confidence .95, minimum ten items/model, budget equivalent to twenty items/model. Random and static corrected-item-total-correlation subsets are cost-matched. Additional family holdout calibrates on 14 models and tests three models from unseen families.

**Verified outcomes:** mean Kendall τ 0.75 versus random 0.62 and static 0.71; about 2% of held-out full-evaluation items used **after excluding calibration cost**. Confident non-tie comparisons average 99% accuracy, but the ranker labels **51% of comparisons ties**, versus 26% ground-truth ties (Table 3); this is selective accuracy, not 99% accuracy over every pair. Ground-truth ties use bootstrap intervals on full evaluation, with further implementation details unread. Calibration reportedly breaks even after roughly 70 model evaluations, an appendix-based claim summarized in main text, not recomputed here.

**Caveats:** approximate independent-normal pair confidence is model-based, not a universal anytime-valid guarantee. Paper explicitly acknowledges per-comparison rather than family-wise error control; repeated adaptive stopping adds another reason to validate actual error rates. Cost-aware sampling can shift which comparisons are resolved. Low discrimination (Nemotron) offers limited gains. Judge same-family bias and recalibration costs are acknowledged. Full-dataset rank fidelity is not construct validity.

**Reported availability, not opened:** https://github.com/trismik/continuous-cat . Current code/data accessibility and licensing not independently checked.

## 3. Actionable baseline specification for binary matrices

These are **recommended implementation specifications**, not statements that the papers all used these exact choices. No code was implemented.

### 3.1 Cheap controls and entrywise predictors

- **Source item mean:** `p̂_mi=(Σ_s Y_si+α)/(M_src+α+β)`, with e.g. α=β=1 as a declared smoothing choice. Uses no target outcomes; report b=0 and compare against contextual methods.
- **Target ability-only:** `p̂_mi=(Σ_{j∈S_m}Y_mj+α)/(b+α+β)`, constant across i. This separates learning row difficulty/ability from learning interactions.
- **Additive Bernoulli model:** `p̂_mi=σ(u_m+v_i)` with source item effects fitted on source rows, target u fitted on S_m, regularized. A 1PL/Rasch-type baseline, not a novelty claim.
- **Multidimensional IRT/logistic factorization:** `σ(α_iᵀθ_m−β_i)` as in [2]; compare dimensions including 1 and tune only on held-out source-model contexts. Rotational/scale identifiability constraints or priors must be specified. Never fit target embeddings using unseen target cells.
- **Nearest-source control:** minimize observed Hamming/L1 distance as in §2[1]. Use smoothed/soft-k neighbor averages for finite log loss if needed, tuned on source validation; flag as a variant, not exact [1].
- **Entrywise response ridge:** for each output column i, regress `Y_si` on `Y_sS` across source rows with source-only tuning. Query i must not also be the output target. A full-bank fixed selector makes this straightforward; with adaptive S, either refit valid conditional regressions for each context or use a model trained for arbitrary masks. Clip only probabilistic outputs with a declared ε for NLL; keep raw score-estimation variants separate.
- **Generic assessor with item features:** reproduce the conditional signature+features setup of [4] if new items are in scope. A local text encoder instead of its paid API must be labeled an embedding substitution. Compare with item-feature-only, context-only, interaction and nonlinear variants.

### 3.2 Aggregate and acquisition controls

Run flat/stratified sample means, Random-Sampling-Learn [6], p-IRT/gp-IRT [2], correctness-cluster weighted score [2], and a residual-corrected estimator [6]. Compare random and learned item selection while holding the predictor fixed, then compare predictors on the same selection. Static and adaptive policies need separate labels; actual observations cost b in either case, but adaptive overhead/latency is additional.

For nonuniform positive-probability inclusion `π_i`, a fixed-prediction design-based reference is

`Â = Σ_i w_i [q_i + (I_i/π_i)(Y_mi−q_i)]`.

Do not insert guessed propensities into that formula. Deterministic cluster representatives or greedy argmax acquisition can give zero inclusion probability for many items, precluding the usual whole-population correction. An independent randomized residual-audit stream is a practical robustness experiment; its sample costs count toward b.

## 4. Recommended evaluation protocol

### Splits and masking

1. **Primary known-column test:** full source rows for the fixed item bank, held-out new model rows. Split models by **base family/checkpoint ancestry** before tuning, not independent random cells. Keep source-only validation models for hyperparameters, calibration, λ, selector design and early stopping. Recreate the same context budgets and missingness pattern during validation.
2. Also report a random-row interpolation split for comparability, a temporal split using the explicitly recorded release/evaluation date, and a frontier stress split matching [6]'s bottom-50%/top-30% construction. Full scores may define that offline split but must not enter fitting or selection. Do not conflate the deliberately sorted split with a realistic date split.
3. If claiming unseen-item generalization, split columns **as well as rows**, keeping all responses of held-out columns out of item fitting/selection. With text features, distinguish inductive held-out text from transductive access to unlabeled future text. Report an entire-task/subscenario holdout in addition to random columns. A matrix-only learned column ID has no principled cold-start prediction; acknowledge that limit.
4. If studying sparse historical matrices rather than full source rows, create that as a separate regime, share the same source-observation mask across methods, and never encode missing cells as 0. These papers do not automatically establish success in arbitrary sparse-source completion.
5. Exclude queried target cells from the main entrywise test set. Observed outcomes may be retained exactly for full-score reconstruction. Predeclare uniform random contexts vs static selected contexts vs model-adaptive contexts; share random seeds and contexts where comparisons permit. Use budgets `{10,20,50,100,200}` subject to bank size, with b=0 controls.
6. Source-only preprocessing: scaling, embeddings fitted on task data, correlation matrices, IRT fitting, item filters, PCA/factorization, and interval calibration. Avoid test-score-based choice of which models/tasks to keep. Deduplicate related model submissions and item near-duplicates where metadata permits.

### Metrics, calibration, and uncertainty

- **Entrywise primary:** mean per-model negative log-likelihood and Brier score on U_m; also per-model AUROC and AUPRC. Report prevalence and undefined AUROC for all-0/all-1 rows rather than substituting .5. Pooled AUC can be dominated by item easiness or model ability; do not substitute it for macro per-model results.
- **Calibration:** source-validation-fitted probability recalibration only (e.g. a stated logistic/temperature mapping), then held-out reliability plots, Brier/NLL, and ECE with fixed bins and counts. Present raw and recalibrated results; ECE alone is not sufficient. Specify fitting objective, binning, clipping, and calibration set. The allowed papers do not demonstrate all of these checks; this is a proposed stronger protocol.
- **Aggregate secondary:** full-benchmark MAE/RMSE, signed bias, worst-decile/per-family/per-task errors, and micro versus official macro weights. A method can have good score MAE and bad cell probabilities or vice versa. Report both.
- **Ranking secondary:** Kendall τ-b or a specified tie-aware variant, Spearman, pairwise accuracy, fraction confidently resolved, tie precision/recall and confident error **at matched coverage/budget**. Do not advertise selective 99% accuracy without the abstention fraction [7].
- **Uncertainty:** distinguish variability across mask/selector seeds, training initialization, model-family split and target models. Use paired comparisons on shared masks; bootstrap model families or otherwise account for ancestry rather than treating every cell as independent. A 95% model-based posterior interval is not necessarily 95% held-out coverage, especially under frontier shift/adaptive stopping. Report empirical interval coverage and widths; use a prespecified valid simultaneous/sequential procedure before making global or anytime error-control claims.
- **Cost:** online target evaluations, source-label collection/calibration, item embeddings, predictor training, selector search/RL training and adaptive latency. Compare random at **2b** as a practical cost alternative [6] as well as budget-matched random at b. Do not count offline full-source labels or calibration as free without an explicit amortization assumption.

## 5. Honest positioning and next experiments

**Supported positioning:** “We study entrywise binary correctness prediction for held-out models given a limited response context. Relative to the allowed starter literature, we evaluate whether gains survive family and capability shifts and whether probability calibration and aggregate/ranking fidelity agree.” This is a proposed evaluation focus, not an established novelty result.

**Claims not justified by this reading:** first to predict unseen model–item responses; first binary IRT or logistic matrix factorization; first adaptive benchmark selection; first behavioral signature from reference items; first continuous-score ranker; universal superiority to random sampling; calibration guarantees inferred from AUROC, Kendall τ, or mean score error. [1], [2], [4], and [5] already cover substantial parts of response prediction. Restrictions prevent an exhaustive novelty claim; this report makes no statement about the excluded paper.

**Prioritized experiments, not implementations:**

1. **Prediction before selection:** shared random contexts, b in `{10,20,50,100,200}`, compare item mean, target mean, nearest-source, regularized 1PL, multidimensional IRT, entrywise ridge. Measure held-out cell NLL/Brier and full-score MAE. Hypothesis: gains attributed to learned selection may largely come from the predictor [4,6].
2. **Interpolation versus shift:** same predictors under random, family-held-out, date-held-out, and bottom/top capability splits. Hypothesis: learned score/rank gains shrink or reverse at the frontier; report subgroup and worst-case errors, not just the grand mean [1,2,6].
3. **Residual correction versus extra labels:** compare random at b, random at 2b, random+ridge, p-IRT/gp-IRT, and a carefully specified residual-corrected estimator under uniform contexts. Separate entrywise accuracy from score bias; audit the effect of fitting correction and nuisance predictions on the same labels [2,6].
4. **Only then selection ablations:** fix predictor and compare uniform, stratified, correctness-cluster and Bernoulli information-based contexts. Include predictor-only ablation before considering the resource-heavy NP/PPO pipeline. Do not label a simplified CAT/entropy policy an AEA reproduction [5].
5. **If text is available:** two-axis row/column holdout with reference-signature assessor, item-only and interaction baselines; match query budget but disclose encoder substitutions. Hypothesis: fixed-column IRT advantages do not automatically extend to unseen items [4,5].
6. **If ranking is claimed:** calibrate and test pairwise errors versus confidence and resolved fraction under family shift, comparing with matched-cost random and fixed-length Bernoulli CAT. Treat [7]'s continuous ranker as protocol inspiration, not direct evidence for binary entrywise novelty.

## 6. Output inventory and citation policy

- `/work/literature/reading_notes.md` — this report.
- `/work/literature/references.bib` — exactly the seven actually read allowed papers, arXiv metadata and explicit version notes; verified conference information only when present in the PDF.
- `/work/literature/supporting_quotes.json` and `quote_validation.json` — short main-text evidence spans; every supporting quote is ≤80 characters. Hyphenated/concatenated PDF text is preserved where quoted.
- `/work/literature/template_rules.md` — official provenance, 9-page submission/10-page accepted main-track rule, mandatory checklist and access/exposure caveats.
- `/work/paper/neurips_2026.sty`, `neurips_2026.tex`, `checklist.tex`, and original official ZIP — unchanged template files, not a manuscript.

Only [1]–[7] are research citations. Code/dataset availability URLs are quoted source claims, not additional inspected sources. No reference-section work, sample-template bibliography item, or handbook Further reading entry is included in BibTeX.
