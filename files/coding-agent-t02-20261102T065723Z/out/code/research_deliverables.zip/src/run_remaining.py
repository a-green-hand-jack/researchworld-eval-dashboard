"""Wait for the already-running main grid, then execute controls and analysis."""
import json,time,subprocess,sys
from pathlib import Path
main=json.loads(Path('configs/main.json').read_text())
while not all(Path(c['out']).exists() for c in main):time.sleep(5)
with Path('logs/secondary_batch.log').open('w') as f:
 r=subprocess.run([sys.executable,'src/batch.py','configs/secondary.json'],stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise SystemExit(r.returncode)
# Full numerical audit is invoked explicitly after analysis and paper generation.
print('All queued runs completed',flush=True)
