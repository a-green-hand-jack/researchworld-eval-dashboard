"""Compile official NeurIPS sources without requiring GNU make."""
import shutil,subprocess
from common import ROOT


def main():
    paper=ROOT/'paper'
    for command in [
        ['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],
        ['bibtex','main'],
        ['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],
        ['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex']]:
        subprocess.run(command,cwd=paper,check=True)
    shutil.copy2(paper/'main.pdf',ROOT/'paper.pdf')
    from pypdf import PdfReader
    reader=PdfReader(paper/'main.pdf')
    content_end=None
    for i,page in enumerate(reader.pages):
        text=page.extract_text() or ''
        if 'References' in text and ('Balk' in text or 'Pacchiardi' in text):
            content_end=i;break
    assert content_end is not None,'Cannot identify bibliography boundary'
    assert content_end<=9,f'Content exceeds9 pages: {content_end}'
    print(f'Compiled: {len(reader.pages)} total pages, {content_end} content pages. Official limit9.')

if __name__=='__main__':main()
