# Self-review resolutions and retained limitations

The independent review is retained unchanged at artifacts/paper_review.md. It examined a historical draft, not the final repaired artifact.

## F1 — numerical ranking ties: repaired
- Review reproduced machine-precision perturbations that violate the shared-query fixed-difference common-offset invariant. This is an evaluation bug, not a new estimator failure.
- Chosen numerical policy: round true/predicted fractions to10 decimals for ordering only, much smaller than the smallest bank's single-item score increment. No jitter, outcome-selected significance tolerance, clipping, method tuning, or raw-error change.
- src/recompute_metrics.py recalculated all existing rank fields from saved predictions. logs/rank_correction_ledger.csv retains18326 changed rank fields. 1170 original uniform/stratified offset checks passed, including gap and all budgets. New runs use the same policy directly.
- Primary MAE/RMSE/bias predictions and contrasts unchanged. Frontier stratified mean remains higher Spearman than SCFD (rounded final0.694 vs0.676).
- Added unit rank-invariance regression test. No primary experiment rerun required.

## F2 — incremental contribution / main-track strength: not a factual defect that wording can solve
- Main text now explicitly states the SCFD gain over fixed stratified difference is only0.03pp frontier and0.15pp random holdout.
- This near-equivalence is promoted as a negative result; no SOTA, new survey principle, targetwise coverage, practical necessity, or acceptance-readiness claim.
- Standard theorem and limited new insight may still be insufficient for main-track acceptance. That venue-risk judgment remains an honest limitation; no extra favorable result was invented or selected to dismiss it.

## F3 — no-audit label cost: repaired
- Both opposite pilot fits jointly use all b labels. Each directional nuisance fits one half; their imputation estimates are averaged without audit correction. Main caption and appendix now distinguish per-fit labels from total cost.

## F4 — nearest-source omission: addressed with fixed post-review comparator
- Added src/nearest_source.py on all130 original main cells x4saved uniform contexts; minimum queried Hamming distance, average all tied source rows, retain actual queried outcomes.
- No tuning or target outcomes beyond queried labels. The nearest-source regression test checks ties and observed retention. (Final suite adds one nearest-source test plus rank and invalid-budget tests,12total.)
- Final nearest-source MAE4.16pp IID/9.26pp frontier. Full results retained, not used to change frozen SCFD settings/contrasts. Gap grid not extended for this optional comparator, disclosed.

## F5 — unsupported asymptotic error-floor wording: removed
- Figure1 now states persistent error over studied finite budgets, and is explicitly cited in result prose. No asymptotic floor is inferred from four points.

## F6 — MIRT reproduction/compute: repaired
- Added target Newton cap60, step-norm limit2, tolerance1e-7; no saved target-optimizer certificate is claimed. All260source/inner numerical statuses successful (not a global-optimum certificate).
- Paper now reports measured MIRT569.5s stage wall time and64.0summed cell-minutes, including calibration/scoring. Original/main80.3s, diagnostics78.8s, gap20.0s, nearest4.95s from script summaries, not delayed process-poll elapsed values.

## F7 — navigation/checklist: repaired
- Checklist references reproduction/LLM disclosure through app:repro labels instead of nonexistent AppendixI.
- Figure1 explicitly cross-referenced, all citations and source files compile without unresolved references/overfull boxes. Official style unchanged.

## Other final verification
- Added explicit sampler partition/size guards; no valid grid's design or prediction changed.
- Initial9tests and final12tests pass. Numerical all-record and paper/ZIP checks are recorded in artifacts/final_verification.json.
- GNU make unavailable; README and paper commands use tested src/build_paper.py. Initial build failures (undefined capital-Alpha, missing xcolor) repaired without altering official style.
- Historical independent-audit and review reports are evidence of the trajectory, not claims that repaired defects remain present. No independent human peer review or acceptance certification occurred.
