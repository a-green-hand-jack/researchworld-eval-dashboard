"""Shared plotting style: colour-blind-safe rule colours, fixed per rule across all figures."""
import matplotlib as mpl
import numpy as np, pandas as pd

RULE_COLOR = {  # Okabe-Ito
    "mean": "#0072B2", "geomean": "#56B4E9", "harmonic": "#009E73", "median": "#D55E00",
    "min": "#CC79A7", "borda": "#E69F00", "condorcet": "#000000", "plurality": "#7F7F7F",
}
RULE_LABEL = {"mean": "mean", "geomean": "geometric mean", "harmonic": "harmonic mean", "median": "median",
              "min": "min", "borda": "Borda", "condorcet": "Condorcet winner", "plurality": "plurality"}
RULE_MARK = {"mean": "o", "geomean": "s", "harmonic": "^", "median": "v", "min": "D", "borda": "P",
             "condorcet": "X", "plurality": "*"}
DATASET_LABEL = {"ollb": "Open LLM Leaderboard (6 tasks)", "helm": "HELM MMLU (57 subjects)"}

def setup():
    mpl.rcParams.update({
        "font.family": "serif", "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
        "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
        "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.6,
        "lines.linewidth": 1.2, "pdf.fonttype": 42, "ps.fonttype": 42, "figure.dpi": 150,
        "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    })

TEXTWIDTH_IN = 5.5   # NeurIPS/ICLR text width 5.5in; ICML two-column figure* 6.75in -- set per venue decision

RANK_BINS = [(2, 4), (5, 8), (9, 16), (17, 32), (33, 64), (65, 128), (129, 256), (257, 512), (513, 1024), (1025, 2048), (2049, 10**6)]

def log_axis(ax):
    import matplotlib.ticker as mt
    ax.set_xscale("log"); ax.xaxis.set_major_formatter(mt.ScalarFormatter()); ax.xaxis.set_minor_formatter(mt.NullFormatter())


def rank_binned(d, col, B=1000, seed=0, min_n=3):
    """Median of `col` and 95% bootstrap CI (over targets) per rank bin, by mean-rule rank of the target.
    Returns DataFrame [bin_lo, bin_hi, x (geometric centre of observed ranks), n, med, lo, hi]."""
    rng = np.random.default_rng(seed); rows = []
    for lo, hi in RANK_BINS:
        s = d[(d.rank_mean >= lo) & (d.rank_mean <= hi)]
        v = s[col].to_numpy(float)
        if len(v) < min_n: continue
        bs = np.median(rng.choice(v, (B, len(v))), axis=1)
        rows.append(dict(bin_lo=lo, bin_hi=hi, x=float(np.exp(np.log(s.rank_mean).mean())), n=len(v),
                         med=float(np.median(v)), lo=float(np.percentile(bs, 2.5)), hi=float(np.percentile(bs, 97.5))))
    return pd.DataFrame(rows)

def load_core(resdir, dataset):
    """results/core_<dataset>.csv of the analysis; returns (DataFrame, [(file, sha256)]).
    Adds feas (status != infeasible/censored) and cost columns normalised by the number of tasks."""
    import pathlib, hashlib
    p = pathlib.Path(resdir) / f"core_{dataset}.csv"; d = pd.read_csv(p)
    n = N_TASKS[dataset]; d["feas"] = d.status.isin(["ok", "already_first"]); d["cens"] = d.status == "censored"
    d["Kn"] = d.K / n; d["L1n"] = d.L1 / n
    return d, [(p.name, hashlib.sha256(p.read_bytes()).hexdigest())]

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k / n; den = 1 + z * z / n; c = (p + z * z / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return c - h, c + h

def feas_binned(d, min_n=3):
    """Feasible fraction per rank bin (by rank_mean) with Wilson 95% interval."""
    rows = []
    for lo, hi in RANK_BINS:
        s = d[(d.rank_mean >= lo) & (d.rank_mean <= hi) & ~d.cens]
        if len(s) < min_n: continue
        k = int(s.feas.sum()); l, h = wilson(k, len(s))
        rows.append(dict(x=float(np.exp(np.log(s.rank_mean).mean())), n=len(s), frac=k / len(s), lo=l, hi=h))
    return pd.DataFrame(rows)

N_TASKS = {"ollb": 6, "helm": 57}
MAIN_RULES = ["mean", "median", "min", "borda", "condorcet"]
PRIMARY_CAP = {"ollb": "emp99", "helm": "emp99T"}
CAP_LABEL = {"emp99": "primary cap (empirical 99th-pct gain)", "emp99T": "primary cap (transfer: MMLU-PRO 99th-pct gain)",
             "ceil": "oracle cap (score $\\leq$ 100)"}
