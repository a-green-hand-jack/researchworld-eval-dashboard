"""Queue an independent replication after the exploratory feature jobs finish."""
import json,time,subprocess,sys
from pathlib import Path
runs=json.loads(Path('configs/features.json').read_text())
while not all(Path(c['out']).exists() for c in runs):time.sleep(3)
with Path('logs/replication_batch.log').open('w') as f:
 r=subprocess.run([sys.executable,'src/batch.py','configs/replication.json','--jobs','2'],stdout=f,stderr=subprocess.STDOUT)
 raise SystemExit(r.returncode)
