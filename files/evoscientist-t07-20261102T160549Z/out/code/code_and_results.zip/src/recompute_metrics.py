"""Recompute rank-only metrics from existing predictions after tie audit.

No fitting, querying, selection or error-metric changes. Preserve a before/after
ledger so this numerical correction is transparent.
"""
import json
import numpy as np
import pandas as pd
from common import ROOT,sha256
from run_experiments import metrics


def main():
    ledger=[];invariants=0
    for dirname in ['runs','irt_runs','nearest_runs']:
        for path in sorted((ROOT/'artifacts'/dirname).glob('*.json')):
            data=json.loads(path.read_text())
            if 'records' not in data:continue
            preds=np.load(path.with_suffix('.npz'))
            base=np.load(ROOT/'artifacts/runs'/path.with_suffix('.npz').name)
            true=base['true'];rep=base['rep']
            if dirname=='runs':
                budgets=sorted(set(r['budget'] for r in data['records']))
                for b in budgets:
                    for a,c in [('uniform','item_difference'),('stratified_mean','stratified_difference')]:
                        ma=metrics(true[rep],base[f'{a}__b{b}'][rep]);mc=metrics(true[rep],base[f'{c}__b{b}'][rep])
                        for key in ['rho','tau','pair_agreement']:
                            assert ma[key]==mc[key],(path.name,b,a,c,key,ma[key],mc[key])
                        invariants+=1
            for r in data['records']:
                idx=rep if r['weighting']=='group' else np.arange(len(true))
                value=preds[f"{r['method']}__b{r['budget']}"]
                updated=metrics(true[idx],value[idx])
                for key in ['mae','mse','rmse','bias','p95','out_of_range']:
                    assert abs(updated[key]-r[key])<1e-13,(path,key)
                for key in ['rho','tau','pair_agreement']:
                    old=r[key];new=updated[key]
                    if old!=new:
                        ledger.append(dict(file=str(path.relative_to(ROOT)),method=r['method'],budget=r['budget'],
                                           weighting=r['weighting'],metric=key,old=old,new=new))
                    r[key]=new
            data['ranking_policy']='Round truth/prediction to10 decimals for rank metrics only; raw errors unchanged.'
            data['ranking_evaluator_sha256']=sha256(ROOT/'src/run_experiments.py')
            path.write_text(json.dumps(data,indent=2,allow_nan=False))
    pd.DataFrame(ledger).to_csv(ROOT/'logs/rank_correction_ledger.csv',index=False)
    print('Changed rank fields:',len(ledger),'offset-invariance checks passed:',invariants)

if __name__=='__main__':main()
