"""Download only the allowed fixed snapshot; never use a live branch.

The full vendor git checkout supplied with this workspace is optional. Fresh
reproduction fetches just the 13 matrices and the baseline verification files.
"""
import argparse,json,urllib.request
from common import ROOT,DATA,NAMES,COMMIT,sha256


def main():
    p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');a=p.parse_args()
    vendor=ROOT/'vendor/benchmark-prediction'
    rels=[f'data/scores/{n}.jbl' for n in NAMES]
    rels+=['LICENSE.txt','README.md','benchpred/random.py','benchpred/aipw.py','benchpred/base.py','benchpred/anchor_points.py','benchpred/tiny_bench.py']
    base=f'https://raw.githubusercontent.com/socialfoundations/benchmark-prediction/{COMMIT}/'
    records=[]
    for rel in rels:
        path=vendor/rel
        if not path.exists():
            if a.verify_only:raise FileNotFoundError(path)
            path.parent.mkdir(parents=True,exist_ok=True)
            req=urllib.request.Request(base+rel,headers={'User-Agent':'sparse-evaluation-reproduction/1.0'})
            with urllib.request.urlopen(req,timeout=180) as response:data=response.read()
            path.write_bytes(data)
        records.append(dict(file=rel,url=base+rel,sha256=sha256(path),bytes=path.stat().st_size))
        print(rel,records[-1]['sha256'])
    ref=ROOT/'artifacts/data_audit.csv'
    if ref.exists():
        import csv
        with ref.open() as f:expected={r['benchmark']:r['sha256'] for r in csv.DictReader(f)}
        for rec in records:
            if rec['file'].startswith('data/scores/'):
                n=rec['file'].split('/')[-1][:-4]
                assert rec['sha256']==expected[n],f'Hash mismatch: {n}'
    (ROOT/'artifacts').mkdir(exist_ok=True)
    (ROOT/'artifacts/download_manifest.json').write_text(json.dumps(dict(commit=COMMIT,files=records),indent=2))

if __name__=='__main__':main()
