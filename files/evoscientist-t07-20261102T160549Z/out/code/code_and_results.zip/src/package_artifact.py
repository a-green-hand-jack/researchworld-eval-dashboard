"""Package portable code/results and complete stand-alone LaTeX inputs."""
from pathlib import Path
import json,zipfile
from common import ROOT,sha256


def main():
    # Avoid self-referential archive hashes. The final root verification report
    # is generated AFTER packaging and supplied separately.
    excluded_names={'final_verification.json','package_manifest.json'}
    root_files=['README.md','final_report.md','research_request.md','todos.md','plan_review.md',
                'requirements.txt','LICENSE','run_all.sh','paper.pdf']
    code_files=[ROOT/f for f in root_files]
    for directory in ['src','tests','artifacts','logs','paper']:
        code_files += [p for p in (ROOT/directory).rglob('*') if p.is_file()
            and '__pycache__' not in p.parts and p.name not in excluded_names
            and p.suffix not in ['.pyc','.aux','.log','.out','.blg','.fdb_latexmk','.fls']]
    # Include raw stdout logs as scientific provenance, not TeX's long aux logs.
    code_files += [p for p in (ROOT/'logs').rglob('*.log')]
    code_files += [p for p in (ROOT/'literature').glob('*') if p.suffix in ['.md','.json','.bib']]
    vendor=ROOT/'vendor/benchmark-prediction'
    code_files += [vendor/'LICENSE.txt',vendor/'README.md']
    code_files += list((vendor/'benchpred').rglob('*.py'))
    latex_files=[p for p in (ROOT/'paper').rglob('*') if p.is_file() and p.suffix not in ['.aux','.log','.out','.blg'] and p.name!='main.pdf']
    report={}
    for name,files in [('code_and_results.zip',code_files),('paper_source.zip',latex_files)]:
        path=ROOT/name
        with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for p in sorted(set(files)):
                z.write(p,p.relative_to(ROOT))
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist())
        report[name]={'files':len(set(files)),'bytes':path.stat().st_size,'sha256':sha256(path)}
    assert (ROOT/'code_and_results.zip').stat().st_size<100_000_000,'Official100MB supplement limit'
    (ROOT/'artifacts/package_manifest.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
