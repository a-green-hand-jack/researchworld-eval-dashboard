"""Post-review simple nearest-source control, no tuning or target full labels.

Distance: Hamming on common uniform queries. Exact distance ties average all
nearest source rows. Observed outcomes retained; unqueried values borrowed.
"""
import json,time
import numpy as np
from common import ROOT,load
from run_experiments import metrics


def predict(source,ids,y):
    # binary squared distance equals Hamming; memory bounded target x source.
    dist=y.sum(1)[:,None]+source[:,ids].sum(1)[None,:]-2*y@source[:,ids].T
    nearest=(dist==dist.min(1)[:,None]).astype(float)
    nearest/=nearest.sum(1)[:,None]
    unqueried_total=source.sum(1)-source[:,ids].sum(1)
    return (y.sum(1)+nearest@unqueried_total)/source.shape[1]


def main():
    out=ROOT/'artifacts/nearest_runs';out.mkdir(parents=True,exist_ok=True)
    stage=time.perf_counter()
    for path in sorted((ROOT/'artifacts/runs').glob('*.npz')):
        if '__gap__' in path.name:continue
        start=time.perf_counter();s=np.load(path)
        name,regime,seedpart=path.stem.split('__');seed=int(seedpart[1:])
        x=load(name);source=x[s['source_rows']];target=x[s['target_rows']]
        arrays={};records=[]
        for b in [10,25,50,100]:
            ids=s[f'u_{b}'];value=predict(source,ids,target[:,ids])
            arrays[f'nearest_source__b{b}']=value
            for weighting,idx in [('group',s['rep']),('row',np.arange(len(target)))]:
                records.append(dict(benchmark=name,regime=regime,seed=seed,budget=b,method='nearest_source',weighting=weighting,
                                    **metrics(s['true'][idx],value[idx])))
        np.savez_compressed(out/path.name,**arrays)
        (out/path.with_suffix('.json').name).write_text(json.dumps(dict(records=records,wall_seconds=time.perf_counter()-start),indent=2))
    (ROOT/'artifacts/nearest_summary.json').write_text(json.dumps(dict(cells=130,wall_seconds=time.perf_counter()-stage),indent=2))

if __name__=='__main__':main()
