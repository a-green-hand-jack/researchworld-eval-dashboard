"""LaTeX tables from the analysis results.
Usage: python3 figures/src/tables.py RESULTS_DIR OUT_DIR
 T2  tables/T2_theory_check.tex  closed forms P1-P3 vs exact solvers (aggregated from results/theory_check.csv)
 T3  tables/T3_rules_<dataset>_<cap>.tex  per rule and rank stratum: feasible share, median K and L1 among feasible targets with
     95% bootstrap CIs over targets (B=2000, seed 0), and median L1 ratio to the mean rule over targets feasible under both (their count in parentheses).
 T4  tables/T4_frontier_<dataset>.tex  feasibility frontier per cap role and rule (Wilson 95% CI, r*, all-feasible-up-to rank, half-feasibility bin).
     r*, all-feasible-up-to (with bootstrap-over-targets CIs) are read from summary/frontier_*.csv after checking that they equal the values recomputed from core_*.csv.
 T5  tables/T5_variants_<dataset>.tex  sensitivity variants at the primary cap (summary/summary_variants.csv), one row per variant x rule.
 T6  tables/T6_paired_<dataset>_<cap>.tex  rule vs mean, paired on targets feasible under both (summary/paired_*.csv), by rank stratum.
Also writes tables/MANIFEST.json (input hashes)."""
import sys, pathlib, json, hashlib
import numpy as np, pandas as pd
sys.path.insert(0, str(pathlib.Path(__file__).parent)); import style
res, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]); out.mkdir(exist_ok=True, parents=True)
rng = np.random.default_rng(0); man = {}
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ci_med(v, B=2000):
    v = np.asarray(v, float)
    if len(v) == 0: return None
    bs = np.median(rng.choice(v, (B, len(v))), axis=1)
    return np.median(v), *np.percentile(bs, [2.5, 97.5])
def fmt(m, digits=2):
    if m is None: return "--"
    return f"{m[0]:.{digits}f} [{m[1]:.{digits}f}, {m[2]:.{digits}f}]"
RN = {"mean": "mean", "median": "median", "min": "min", "borda": "Borda", "condorcet": "Condorcet"}

# ---- T2
t = pd.read_csv(res / "theory_check.csv"); man["theory_check.csv"] = sha(res / "theory_check.csv")
t = t[t.comparison.isin(["closed_form_vs_solver", "closed_form_vs_generic"])]
rows = []
for (ds, rule, cmp), g in t.groupby(["dataset", "rule", "comparison"], sort=False):
    solver_only = g.max_abs_dev_L1.isna().all()
    rows.append((ds, rule, cmp, g.cap.nunique(), "--" if solver_only else f"{int(g.n_targets.iloc[0])}",
                 "solver only" if solver_only else f"{g.max_abs_dev_L1.max():.1e}",
                 "--" if solver_only else f"{g.max_abs_dev_K.max():.0f}", "--" if solver_only else f"{int(g.feasibility_mismatches.sum())}"))
L = [r"\begin{tabular}{@{}llllrrr@{}}", r"\toprule",
     r"data & rule & reference & max$|\Delta L_1|$ & max$|\Delta K|$ & feas.\ mismatches & caps \\", r"\midrule"]
nm = {"closed_form_vs_solver": "exact solver", "closed_form_vs_generic": "generic LP/MILP"}
for ds, rule, cmp, ncap, nt, dev, dk, mm in rows:
    L.append(f"{'OLLB' if ds == 'ollb' else 'HELM'} & {RN[rule]} & {nm[cmp]} & {dev} & {dk} & {mm} & {ncap} \\\\")
L += [r"\bottomrule", r"\end{tabular}"]
(out / "T2_theory_check.tex").write_text("\n".join(L) + "\n")

# ---- T3
STRATA = [("rank 2--10", 2, 10), ("rank 11--50", 11, 50)]
for ds in ("ollb", "helm"):
    d, prov = style.load_core(res, ds); man[prov[0][0]] = prov[0][1]
    for cap in (style.PRIMARY_CAP[ds], "ceil"):
        dc = d[(d.cap == cap) & (d.rank_mean >= 2)]
        piv = dc.pivot_table(index="target", columns="rule", values="L1", aggfunc="first")
        L = [r"\begin{tabular}{@{}l" + "rrrr" * len(STRATA) + r"@{}}", r"\toprule"]
        L.append(" & " + " & ".join(rf"\multicolumn{{4}}{{c}}{{{s[0]}}}" for s in STRATA) + r" \\")
        L.append(" & " + " & ".join([r"feas.\ & $K$ & $L_1$ & $L_1/L_1^{\text{mean}}$"] * len(STRATA)) + r" \\"); L.append(r"\midrule")
        for rule in style.MAIN_RULES:
            cells = []
            for _, lo, hi in STRATA:
                s = dc[(dc.rule == rule) & dc.rank_mean.between(lo, hi) & ~dc.cens]
                if s.empty: cells += ["--"] * 4; continue
                f = s[s.feas]; k = int(len(f))
                m_K = ci_med(f.K.to_numpy(float)); m_L = ci_med(f.L1.to_numpy(float))
                both = f.target[np.isfinite(piv.loc[f.target, "mean"].to_numpy())] if "mean" in piv else []
                ratio = None; npair = 0
                if rule != "mean" and len(both):
                    base = piv.loc[both, "mean"].to_numpy(float); num = f.set_index("target").loc[both, "L1"].to_numpy(float)
                    ok = base > 0
                    ratio = ci_med(num[ok] / base[ok]) if ok.any() else None; npair = int(ok.sum())
                cells += [f"{k}/{len(s)}", fmt(m_K, 1), fmt(m_L, 1), "--" if rule == "mean" else fmt(ratio) + f" ({npair})"]
            L.append(RN[rule] + " & " + " & ".join(cells) + r" \\")
        L += [r"\bottomrule", r"\end{tabular}"]
        (out / f"T3_rules_{ds}_{cap}.tex").write_text("\n".join(L) + "\n")
# ---- T4
def frontier(dc):
    s = dc[~dc.cens]; n = len(s); k = int(s.feas.sum()); lo, hi = style.wilson(k, n)
    rstar = int(s[s.feas].rank_mean.max()) if k else None
    srt = s.sort_values("rank_mean"); bad = srt[~srt.feas]
    r_all = int(bad.rank_mean.min()) - 1 if len(bad) else int(srt.rank_mean.max())   # all targets with rank <= r_all are feasible
    half = None
    for blo, bhi in style.RANK_BINS:
        b = s[s.rank_mean.between(blo, bhi)]
        if len(b) >= 3 and b.feas.mean() < 0.5: half = f"{blo}--{min(bhi, int(s.rank_mean.max()))}"; break
    return n, k, lo, hi, rstar, r_all, half, int(dc.cens.sum())
def ci_int(x, lo, hi):
    x, lo, hi = int(x), int(lo), int(hi)
    return f"{x}" if lo == hi == x else f"{x} [{lo}, {hi}]"
for ds in ("ollb", "helm"):
    d, prov = style.load_core(res, ds)
    fr = pd.read_csv(res / "summary" / f"frontier_{ds}.csv"); man[f"summary/frontier_{ds}.csv"] = sha(res / "summary" / f"frontier_{ds}.csv")
    fr = fr[fr.group == "frontier"].set_index(["cap", "rule"])
    L = [r"\begin{tabular}{@{}llrrcccl@{}}", r"\toprule",
         r"cap & rule & targets & feasible & share [95\% CI] & $r^*$ [95\% CI] & all feas.\ up to [95\% CI] & first bin $<$ 1/2 \\", r"\midrule"]
    for role, cap in (("primary", style.PRIMARY_CAP[ds]), ("oracle", "ceil")):
        for rule in style.MAIN_RULES:
            dc = d[(d.cap == cap) & (d.rule == rule) & (d.rank_mean >= 2)]
            if dc.empty: continue
            n, k, lo, hi, rstar, r_all, half, nc = frontier(dc)
            f = fr.loc[(cap, rule)]
            # the analysis' frontier file and our recomputation from the core table must agree
            assert int(f.n_feasible) == k and (not k or int(f.max_feasible_rank) == rstar), (ds, cap, rule, "r*", f.max_feasible_rank, rstar)
            assert int(f.prefix_rank) == r_all, (ds, cap, rule, "prefix", f.prefix_rank, r_all)
            note = r"$^\dagger$" if (ds == "ollb" and rule in ("borda", "condorcet")) else ""
            L.append(f"{role} (\\texttt{{{cap}}}) & {RN[rule]}{note} & {n} & {k} & {k / n:.2f} [{lo:.2f}, {hi:.2f}] & "
                     f"{ci_int(f.max_feasible_rank, f.max_feasible_lo, f.max_feasible_hi) if k else '--'} & "
                     f"{ci_int(f.prefix_rank, f.prefix_lo, f.prefix_hi)} & {half or 'none'} \\\\")
        if role == "primary": L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabular}"]
    (out / f"T4_frontier_{ds}.tex").write_text("\n".join(L) + "\n")

# ---- T5
VSRC = res / "summary" / "summary_variants.csv"; vr = pd.read_csv(VSRC); man["summary/summary_variants.csv"] = sha(VSRC)
VLAB = {"margin1_eps": "margin 1 pt", "margin2_eps": "margin 2 pt", "var_ollb_nomerge": "no merged models", "var_ollb_raw": "raw scores",
        "var_ollb_top500": "top-500 slice", "weights": "random weights", "zcost": r"cost in $\sigma$ units"}
RL = dict(RN, plurality="plurality", dirichlet1="Dirichlet(1)", dirichlet5="Dirichlet(5)", onehot="one-hot")
VORD = list(VLAB); RORD = ["mean", "median", "min", "borda", "condorcet", "plurality", "dirichlet1", "dirichlet5", "onehot"]
def num(x, d=1): return "--" if pd.isna(x) else f"{x:.{d}f}"
for ds in ("ollb", "helm"):
    prim = style.PRIMARY_CAP[ds]
    v = vr[(vr.dataset == ds) & (vr.group == "all")]
    # primary cap wherever the variant has it; raw-score runs exist only for ceil and gain10, no-merge also at the oracle cap
    v = v[(v.cap == prim) | (v.variant == "var_ollb_raw") | ((v.variant == "var_ollb_nomerge") & (v.cap == "ceil"))]
    L = [r"\begin{tabular}{@{}lllrrccc@{}}", r"\toprule",
         r"variant & cap & rule & $n$ & censored & feas.\ share (base) & median $K$ / $L_1$ & $L_1/L_1^{\text{base}}$ ($n_{\text{both}}$) \\", r"\midrule"]
    first = True
    for var in VORD:
        vv = v[v.variant == var]
        if vv.empty: continue
        if not first: L.append(r"\midrule")
        first = False
        vv = vv.assign(_r=vv.rule.map(RORD.index), _c=(vv.cap != prim).astype(int)).sort_values(["_c", "cap", "_r"])
        lab = VLAB[var]
        for _, r in vv.iterrows():
            # for the top-500 ordinal rules the baseline exists only for the 50 best targets: its share is not comparable
            base_ok = pd.notna(r.feas_frac_base) and not (var == "var_ollb_top500" and r.rule in ("borda", "condorcet", "plurality"))
            fs = f"{r.feas_frac:.2f}" + (f" ({r.feas_frac_base:.2f})" if base_ok else "")
            ratio = "--" if pd.isna(r.L1_ratio_med) else f"{r.L1_ratio_med:.2f} ({int(r.n_both)})"
            L.append(f"{lab} & \\texttt{{{r.cap}}} & {RL[r.rule]} & {int(r.n)} & {int(r.n_censored)} & {fs} & "
                     f"{num(r.K_med_feas)} / {num(r.L1_med_feas)} & {ratio} \\\\")
            lab = ""
    L += [r"\bottomrule", r"\end{tabular}"]
    (out / f"T5_variants_{ds}.tex").write_text("\n".join(L) + "\n")

# ---- T6
for ds in ("ollb", "helm"):
    PSRC = res / "summary" / f"paired_{ds}.csv"; pr = pd.read_csv(PSRC); man[f"summary/paired_{ds}.csv"] = sha(PSRC)
    strata = ["all"] + [g for g in pr.group.unique() if g != "all"]
    for role, cap in (("primary", style.PRIMARY_CAP[ds]), ("oracle", "ceil")):
        pc = pr[(pr.cap == cap) & (pr.rule_b == "mean")]
        L = [r"\begin{tabular}{@{}l" + "c" * len(strata) + r"@{}}", r"\toprule",
             "rule vs mean & " + " & ".join("all" if g == "all" else f"rank {g}" for g in strata) + r" \\", r"\midrule"]
        for rule in ("median", "min", "borda", "condorcet"):
            cells = []
            for g in strata:
                x = pc[(pc.rule_a == rule) & (pc.group == g)]
                if x.empty: cells.append("--"); continue
                x = x.iloc[0]; cnt = f"{int(x.n_both)}/{int(x.n_either)}"
                if pd.isna(x.L1_ratio_med): cells.append(rf"\shortstack{{--\\{cnt}}}")
                else: cells.append(rf"\shortstack{{{x.L1_ratio_med:.2f}\\{{[}}{x.L1_ratio_lo:.2f}, {x.L1_ratio_hi:.2f}{{]}}\\{cnt}}}")
            dag = r"$^\dagger$" if (ds == "ollb" and rule in ("borda", "condorcet")) else ""
            L.append(rf"\shortstack{{\phantom{{0}}\\{RN[rule]}{dag}\\\phantom{{0}}}}" + " & " + " & ".join(cells) + r" \\[3pt]")
        L += [r"\bottomrule", r"\end{tabular}"]
        (out / f"T6_paired_{ds}_{cap}.tex").write_text("\n".join(L) + "\n")
json.dump(dict(script="figures/src/tables.py", inputs=man), open(out / "MANIFEST.json", "w"), indent=1)
