# Experiment protocol review

## 1. Assumptions, scope, and verdict

**Proceed, with protocol repairs—not a superiority or broad novelty claim.** The defensible question is whether an honestly audited, finite-population difference estimator trades same-sample fitting bias for tolerable variance under capability shift. Design-unbiasedness is a sampling-theoretic property, not evidence of lower MAE, better rankings, or useful confidence intervals.

Reviewed only `/work/research_request.md`, `/work/literature/reading_notes.md`, relevant local planning/math-audit guidance, and observation O-14fd345f4ce2505f. No web search, excluded-paper identification, implementation, data inspection, or experiment was performed. Baseline code details and hardware remain **unverified**. This document proposes runs; it reports no experimental results.

Constraints: the 13 named binary matrices at repository commit `55faff496947789f94e6b5908c77cbc3e84f81ad`; CPU only; one week; approximately 1 GB storage guidance; no paid services or LLM reruns. Keep all legitimate rows, including all-zero rows, and all original item multiplicities. Study fixed known items and held-out models, not new-item generalization or adaptive acquisition. Unless official weights are available and implemented separately, call the target the **flat matrix mean**, not the official benchmark score.

### Reject-first: top five likely objections

| Rejection risk | Required defense / consequence |
|---|---|
| **1. “This is standard difference estimation/cross-fitting, not a new estimator principle.”** | Explicitly credit the standard sampling argument. Position the contribution as an implementation/protocol audit and measured bias–variance trade-off on these matrices. A finite-population coefficient is not itself a novel contribution. Restricted reading cannot establish exhaustive novelty. |
| **2. “Your oracle split or preprocessing leaks target outcomes; duplicate grouping does not make models independent.”** | Separate split builder, predictor, and evaluator; fingerprint whole rows only inside the split builder. Keep related-model limitations explicit and add family holdout only if reliable metadata exists. |
| **3. “You weakened or duplicated the strong baselines.”** | Pin regression orientation, coefficient, intercept, scaling, penalty, and scoring formulas. Test algebraic equivalence before treating AIPW and corrected difference as different methods. Separate common-query prediction comparisons from anchor-selection comparisons. |
| **4. “Unbiasedness is bought with excessive variance and extra fitting.”** | Same labels, same nuisance model, same alpha; one-way versus two-way audit; source-difficulty difference and raw uniform controls; raw uniform at 2b as a clearly higher-cost comparator. Report RMSE, tails, and runtime, not just bias. |
| **5. “Five seeds and correlated rows cannot support your uncertainty or robustness claims.”** | Paired seed-level summaries, equal duplicate-group weighting, a small repeated-mask study, and a separate treatment of score-interval coverage. Do not treat cells, folds, benchmarks, or repeated appearances of a target as independent replicates. |

## 2. Mathematical audit: what is actually guaranteed

Fix the full target response vector y, source data, the item bank, and any source-only tuning. Write the estimand as mu = sum_i y_i / N. Draw S uniformly without replacement, |S|=b, then partition it uniformly and independently of outcomes into P,A with fixed p,a>0 and p+a=b. Conditional on P, A is a simple random sample of size a from the N-p remaining items.

Fit q^P using target labels in P only. **Conditional on P, the entire vector q^P must be fixed with respect to the audit draw A** (or condition additionally on learner randomness independent of A). Then

T(P→A) = [sum_P y + sum_{i not in P} q_i^P]/N
          + (N-p)/N · mean_A(y-q^P).

For e_i=y_i-q_i^P on the complement of P,

E[mean_A e | P,q^P] = mean_{i not in P} e,

so **E[T(P→A) | P,q^P] = mu**. The swapped estimator has the analogous guarantee conditional on A. Consequently their half-average is marginally design-unbiased. It is **not generally unbiased conditional on the realized S, nor is the half-average generally unbiased conditional on P**: the swapped term has a different conditioning argument. No source/target distributional match, correct regression model, or large-sample consistency is needed for this point-estimate statement.

The correct directional conditional variance is

Var[T(P→A) | P,q^P]
= ((N-p)/N)^2 · (1-a/(N-p)) · S_e^2/a,

where S_e^2 is the finite-population residual variance over the complement of P, with denominator N-p-1. Handle a census separately. The two directional estimates share labels and predictions and are dependent; do not average their variance estimates as if independent.

**Important repairs and edge cases:**

- Audit independence means **more than not using y_A**. Choosing alpha, pilot preprocessing, scaling, or predictor variants using the realized audit membership can make q^P depend on A. Source-only transforms fixed before S are fine; pilot-fitted transforms are fine. A transform fitted on the union P∪A is not automatically justified. Audit labels must not select alpha, rank, clipping, stopping, or which result to report.
- Use the complement of the **pilot**, not merely the unqueried set U: the prediction sum includes A. The observed-outcome term contains only P. Using all queried outcomes plus this correction double-counts audit information.
- The correction factor is (N-p)/N for P→A and (N-a)/N for A→P—not (N-b)/N. Those factors belong to different estimators.
- A final score may lie outside [0,1]. Do not clip it in the theorem-bearing analysis. Clipping the **nuisance prediction** using a fixed pilot/source-only rule does not invalidate the argument; clipping the final point estimate generally destroys exact unbiasedness. A separately labeled clipped-score sensitivity is permissible, with no unbiasedness claim.
- At b=25 use p=12,a=13. The proposed half-average remains unbiased, but even a constant nuisance predictor no longer reduces exactly to the 25-item sample mean. **Recommended preregistered refinement:** use `(a/b)T(P→A)+(p/b)T(A→P)`. These audit-size weights are fixed by design, preserve unbiasedness, and recover the raw sample mean for a constant nuisance at every budget. This equals the half-average at the even budgets. Keep the original equal average as a b=25 sensitivity only; do not choose weights from target errors.
- This is an **item-sampling guarantee for fixed target rows and fixed source data**, not a guarantee of generalization to an independent population of model families. Nonuniform benchmark weights, adaptive sampling, deterministic anchors, or outcome-dependent budgets require a separately derived estimator.

### Confidence intervals: choose an honest level of ambition

Point unbiasedness does not make a t interval exact. A directional plug-in standard error using the audit residual sample variance is useful diagnostically, but a=5 at b=10 is too small to claim reliable Gaussian coverage without evidence.

For a conservative finite-sample reference, conditional on P all residuals on its complement lie in the known range

L_P = min_{i not in P}(-q_i^P),  U_P = max_{i not in P}(1-q_i^P).

A without-replacement Hoeffding bound gives directional radius

c_P = (N-p)/N · (U_P-L_P) · sqrt(log(4/alpha)/(2a)).

Use the analogous c_A. Assign failure probability alpha/2 to each direction; the weighted aggregate radius `w c_P+(1-w)c_A` is valid by a union bound, **without independence of folds**. These bounds may be nearly vacuous, especially with extrapolating ridge predictions. Report that limitation, not a practical-precision claim. Intersecting an interval with the known parameter space [0,1] is distinct from clipping the point estimate. Any narrower heuristic interval must be explicitly empirical/model-based and coverage-tested. No simultaneous rank or anytime guarantee follows.

## 3. Leakage controls and data quality

### Split-builder / predictor / evaluator contract

1. **Split builder:** alone may inspect full target rows to form duplicate groups and oracle capability splits. Group exact response vectors separately for each benchmark; missingness, if any, is not zero. Save opaque row memberships and split hashes. Do not give predictors full-row fingerprints, target scores, capability order, duplicate multiplicities of hidden target groups, or target-dependent summary statistics as features.
2. **Predictor:** receives source rows, fixed source metadata/transforms, item IDs/features allowed in this matrix-only setting, query IDs, and queried target labels only. No joint target fitting, target-pool normalization, or hidden-target reconstruction for tuning. Source full scores are legitimate training labels for score regression.
3. **Evaluator:** receives full target truth only after predictions and protocol choices are frozen. Full-row residuals, similarity statistics, and score strata are retrospective diagnostics, never deployable selection features.

Duplicate grouping is a declared **oracle, split-only operation**, not a procedure available before evaluating an unknown model. Equality across observed responses also does not establish shared ancestry. Conversely, nonidentical checkpoints may be very strongly related.

### Split definitions that need pinning

- IID: randomly assign approximately 70% of **unique response groups** to sources and 30% to targets, then expand groups back to all rows. Log both row counts and group counts. It is not necessarily a 70/30 row split.
- Frontier: order unique groups by flat full score; assign lower groups to sources, upper groups to targets. Do not split a score-tie block across the capability boundary. Choose the tied-block boundary closest to the desired 70% source count using a fixed tie rule; report realized fractions, score gap, and score ranges. If all scores tie, report frontier as uninformative rather than manufacturing shift.
- Frontier lower70/upper30 is **not** the more separated lower50/upper30 construction described in the notes. Call it the study's contiguous oracle-frontier split. A lower50/upper30 sensitivity, leaving the middle20 unused, is optional—not a silent replacement.
- Five frontier seeds usually change queries/partitions, not the sorted source population. Do not portray them as five independent frontier model splits. IID seeds change both source assignment and query design; log these randomness sources separately.
- Keep all rows physically. For the main evaluation give each target duplicate group equal weight; also report original row-weighted metrics as a sensitivity. Preserve pinned source-row training behavior and disclose duplicate-source effects on feature multiplicity/regularization. Do not silently deduplicate source features or reweight only the proposed method.
- If trustworthy family/checkpoint metadata is available in the permitted repository, add a small family-disjoint check. If unavailable, say **duplicate-group-disjoint**, not family-independent or strictly independent model draws. Do not infer ancestry from response equality or model names alone.

### Source-only validation

Fixed alpha=10 needs no target-based tuning. For every other tunable choice (Rasch penalties, optional ridge sensitivity, or interval calibration), reserve a group-disjoint inner validation subset of the outer source groups. A practical default is 80/20 within sources: random for IID, lower/upper source-score groups for a frontier-mimicking inner split. Recreate the query budgets there. During inner validation, withhold each validation model's full row from source-response covariates, item calibration, and preprocessing; only its context labels enter inference, and its remaining truth enters validation scoring. Freeze choices before outer targets are scored, then refit on all outer sources. Use a prespecified score-error objective and a small fixed candidate grid; if there are too few unique source groups, use declared fixed defaults rather than target tuning. An interval calibrated within sources still need not cover frontier targets.

### Mandatory checks before fitting

Validate shape, item/row identity and orientation, binary support {0,1}, finite values, and missing-value encoding. Preserve constant columns and all-zero/all-one rows unless provenance establishes corruption; endpoints are legitimate data, not an automatic cleaning rule. Log row/column prevalence, constant counts, duplicate-group sizes, and source/target unique counts. Retain duplicate item columns with their original item weights. Never use target distributions to filter items, select rank, normalize features, or set IRT priors.

Check b≤N; an unavailable budget is reported for every method, not silently replaced by another budget. Undefined rank correlations for constant targets/predictions remain undefined with counts. Trace one source/target row through masking and scoring. A predictor must produce identical outputs after **unqueried** target labels are perturbed while split membership, queries, and source data are frozen. Similarly, changing y_A must not change q^P, and changing audit membership while holding P fixed must not change the fitted q^P function.

## 4. Fair baseline and query controls

### Primary common-query track

Within benchmark × regime × seed, use one uniform item permutation; budgets {10,25,50,100} are nested prefixes. Use the **same S across all target rows and all uniform-query methods**, and a label-independent partition shared across targets. This is both efficient and important for rankings: shared item difficulty creates correlated target errors. Respect that dependence in uncertainty calculations. Nesting budgets does not create four independent experiments.

| Method | Required specification |
|---|---|
| Raw uniform | mean_S y, including endpoint rows. This is the indispensable source-free, design-unbiased comparator. |
| Random-Sampling-Learn, pinned | Across source **model rows**, regress full source score on responses on S. A score decoder, not a per-target item predictor. Record actual pinned code conventions; no theorem from the other regression orientation transfers to it. |
| AIPW, pinned | Per target, regress target y on source-response covariates across sampled **items**. Record exact prediction/scoring code, not only the label. |
| Coefficient-correct difference | With q fitted on S: `mean_all(q)+mean_S(y-q) = mean_S(y)+(N-b)/N·(mean_U(q)-mean_S(q))`. If pinned AIPW already uses this formula and the same q, these are **one baseline**, not two independent competitors. If not, report pinned versus repaired code transparently. |
| Source-difficulty difference | Fix d_i from source item means before target sampling; use `mean_all(d)+mean_S(y-d)`. Already design-unbiased and cheap. Separates the value of target-adaptive ridge from residual correction itself. |
| Rasch 1PL | Fit source item effects using sources only; infer target scalar ability from S with a declared regularizer/prior so all-zero/all-one contexts remain finite. Aggregate as `[sum_S y+sum_U p]/N`. Label point-estimate fitting as an adaptation where appropriate. No hidden-target ability fitting. |
| Proposed audit estimator | Same per-target source-response ridge nuisance as the matched AIPW control; alpha fixed at 10; explicit intercept, scaling, objective normalization, and the pilot/audit factors above. Count the complete union P∪A as cost b. |

**Fixed alpha=10 is a clean matched control only when intercept/scaling and the loss convention are identical.** Sum-of-squares + alpha penalty and mean-square + alpha penalty are not interchangeable. Training on b/2 rather than b changes effective regularization under the summed-loss convention; the pilot-cost trade-off must be acknowledged. If the pinned baseline uses a different alpha or preprocessing, retain it and add a separately named matched-nuisance variant. Do not overwrite a pinned method to favor the proposal. Source-only sensitivity tuning may be secondary, not selected after target inspection.

### Separate acquisition track

A deterministic anchor set cannot also be the shared uniform S. Do not conflate these comparisons.

For a binary Anchor Points adaptation use source-correctness clustering, actual-item representatives, and cluster-size weights; explicitly label it a **binary clustering adaptation**, not exact confidence-based Anchor Points. Specify constant/duplicate item handling, empty clusters, representative ties, and exact number of distinct queried items. Avoid quadratic item-correlation/PAM storage under the resource limit.

Compare anchor-weighted score at b against uniform-query results at b, clearly marking that this compares end-to-end acquisition plus estimation. To isolate selection, evaluate the *same Rasch aggregation rule* on anchor and uniform sets. Do not apply the uniform design-unbiased correction theorem to deterministic anchors with zero inclusion probabilities. No need to add a new adaptive selector or neural model.

Report raw uniform at 2b as a separate higher-label-cost option whenever 2b≤N; reuse its larger permutation prefix. It must not be presented as budget-matched.

## 5. Minimal ablations and feasible stress test

Do not add low rank to the initial study. Its source-only fitting is possible, but would introduce another mechanism and tuning axis.

### Minimal mechanism panel

1. **Same nuisance family, different honesty:** matched full-S ridge difference versus the proposed pilot/audit correction, with alpha/intercept/scaling fixed. This combines honest residual evaluation with smaller nuisance training sets, not an isolated coefficient change. For a cleaner no-extra-fit control, reuse q^P and compute `mean_all(q^P)+mean_S(y-q^P)` (and the swapped analogue). This deliberately reuses pilot-training residuals in the correction while holding each fitted predictor fixed relative to its honest counterpart; label it a contaminated-residual ablation, not an additional faithful literature baseline.
2. **No target-trained nuisance:** raw uniform and fixed source-difficulty difference. If the latter matches or beats cross-fitting, the substantive result is that target-specific nuisance fitting was unnecessary or too variable.
3. **One direction versus two:** retain T(P→A) and T(A→P) already computed; compare one preregistered direction with the weighted symmetrization. No extra labels. Do not select the better direction on targets.
4. **Correction versus imputation:** report the uncorrected pilot imputation `[sum_P y+sum_notP q^P]/N` using the same fit; separate predictor bias from residual-correction cost. Its observed-label budget is p even though it is evaluated alongside a b-label system; label this diagnostic honestly.
5. **Finite-population algebra check, not a claimed new method:** compute with/without the proper factor on tiny cases and measure the change only as an explicit intentionally incorrect control. Do not mislabel an incorrect formula as a faithful literature baseline. Test the original versus audit-size average at b=25 only.

### Small repeated-mask study (mandatory before bias/coverage claims)

Preselect two benchmarks by item counts alone: the largest and median-sized of the 13 (fixed name tie-break), before method results. Freeze one source split per regime; select up to six target groups per split by a fixed hash, not by which method wins. Run b=10 and b=100 where available, with **200 independent query/partition replicates**. Every replicate shares its query across methods and targets. This is 1,600 query designs if both benchmarks/budgets/regimes are available; batch target fits. Benchmark cost first; if needed use 100 replicates, disclose the larger Monte Carlo error, and make no precise tail-coverage claim.

Run only the cheap relevant estimators here: raw uniform, fixed-difficulty difference, matched full-S ridge difference, one-way audit, and two-way audit. Reuse cached fits for imputation and interval diagnostics. Do not rerun expensive clustering or source IRT per replicate.

Measure per-target signed bias, MC standard error, variance/MSE, 95th-percentile absolute error, out-of-range score frequency, interval coverage/width, and fold covariance. Log each fold's out-of-fit audit residual mean/variance and compare them with training residuals; do not use these audit diagnostics to select the predictor or reported direction. Full unqueried residual statistics belong to the evaluator only. Compute the replicate-level macro error before its MC standard error; targets sharing a query are not independent replicates. Monte Carlo error of a single coverage rate near .95 with R=200 is about 1.5 percentage points, so do not sell small coverage differences as decisive. This study conditions on selected rows/splits; it is not a 13-benchmark population-coverage result.

Before it, exhaustively enumerate a tiny synthetic binary case (e.g. N=6,b=4, all 90 ordered pilot/audit allocations) to check unbiasedness and coefficients at numerical precision. Include constant and deliberately misspecified nuisance predictions, y all zero/all one, and b=N. Include an odd-budget example to verify the unequal-fold weighting. Enumeration checks an implementation; the conditional-expectation argument above supplies the general proof.

If one optional stress remains affordable, prefer lower50/upper30 at b=50 over another model family or low-rank variant. Keep all zero rows in its lower source portion. Select stress tests before inspecting gains.

## 6. Evaluation and uncertainty aggregation

**Preregister the primary cell:** frontier, b=50, equal-benchmark macro MAE with equal target-group weights within each benchmark. Main paired contrasts: proposed versus raw uniform and versus matched full-S AIPW/difference. Retain pinned Random-Sampling-Learn as a strong reported comparator. Budgets 10/25/100 and IID are secondary; no best-budget headline or test-set method selection.

For each benchmark/regime/seed/budget, average absolute and squared errors within target groups first. Define macro MAE as the mean of benchmark MAEs; macro RMSE as the square root of the mean of benchmark group-MSEs. Also show benchmark-level RMSE so an alternative averaging convention cannot be hidden. Report signed bias, 95th-percentile absolute error, worst-decile error, and original row-weighted sensitivity. Use fraction units in artifacts and clearly labeled percentage points in figures.

For rankings, use group-level true scores and estimates, Kendall tau-b and Spearman with declared tie handling; report undefined cases. Do not compute a leaderboard correlation by concatenating unrelated benchmarks. Report per-benchmark correlations and valid counts. A global cross-benchmark leaderboard would require aligned model identities, an explicitly defined aggregate score, and separate validation. No confident-pair claims are needed for this study.

**Three uncertainties must remain separate:**

- **Design/run variability:** show all five paired seed-level macro deltas, mean, SD, and range. Frontier split uncertainty is not represented by query seeds. Five seeds are a coarse comparison, not proof of unbiasedness or calibrated 95% coverage.
- **Target-population variability:** conditional group/family-cluster bootstrap can supplement tables when enough independent groups exist. Pair all methods and keep a row/group together across its repeated appearances. With reliable global model/family IDs, resample those clusters jointly across benchmarks. Without them, a within-benchmark duplicate-group bootstrap is only a conditional sensitivity and may understate lineage dependence. Do not pool the five source splits as independent target datasets or bootstrap cells. Treat the fixed set of 13 benchmarks descriptively, not as 13 independent draws from all benchmarks.
- **Individual score uncertainty:** interval coverage/width is assessed by repeated masks, separately from uncertainty in mean MAE. A bootstrap interval for the aggregate performance table is not a confidence interval for a target's score. Account for shared queries when making paired/rank comparisons; do not assume independent target errors.

Prefer effect sizes and the complete per-benchmark tables to significance tests with five seeds. Any exploratory interval must state exactly what was resampled, what was held fixed, and what population it is meant to cover. Source-validation-calibrated intervals have no automatic frontier coverage guarantee.

## 7. Numbered execution stages and gates

These are high-level run specifications, not claims that scripts already exist.

### Stage 0 — Freeze the protocol and environment (first half-day)
- **Goal:** remove ambiguities before looking at performance.
- **Run:** inspect pinned repository/data provenance and baseline functions; record split/query contracts, formulas, random streams, alpha conventions, weighting, and artifact schema. Audit local resources.
- **Success signals:** exact commit and hashes recorded; AIPW/difference duplication resolved; all method labels/formulas fixed; CPU/RAM/disk feasibility established.
- **Artifacts:** frozen protocol, baseline specification table, package/version manifest, resource log, seed/split manifests.

### Stage 1 — Data, masking, and estimator verification (day 1)
- **Goal:** establish integrity and the intended information boundary.
- **Run:** matrix audits; duplicate/tie-aware split construction; hidden-label and audit-invariance checks; exhaustive tiny-estimator tests; one representative endpoint fit per method.
- **Success signals:** no cross-split duplicate groups, no forbidden label access; correct finite-population algebra to numerical tolerance; zero/one rows and constant items retained; all methods handle feasible budgets. Invalid/missing encodings are resolved from provenance rather than recoded as failures.
- **Artifacts:** data/split audit tables, test logs, tiny-enumeration table, implementation-discrepancy ledger.

### Stage 2 — Matched baselines and full primary grid (days 2–4)
- **Goal:** complete 13 benchmarks × 2 regimes × 5 seeds × 4 budgets with common queries.
- **Run:** timed one-benchmark pilot first; then cached/batched CPU evaluation, writing incremental results and failures. Anchor selection runs separately. Source models are fitted once per source split where possible.
- **Success signals:** all available grid cells accounted for, exact query counts and shared masks verified, pinned and matched-nuisance methods distinguished, no target-driven tuning. Completion—not a positive gain—is the gate.
- **Artifacts:** predictions/score errors, fold diagnostics, paired metric tables, budget curves, per-method runtime/memory table, failure log.

### Stage 3 — Bias–variance and uncertainty stress (days 4–5)
- **Goal:** test whether the honesty guarantee has useful empirical cost/benefit.
- **Run:** the prespecified repeated-mask panel and minimal ablations; optional gap split only if core grid is complete and time remains.
- **Success signals:** bias reported against MC error; dependent folds handled; coverage distinguished from point unbiasedness; tails and negative results visible. No requirement to beat random.
- **Artifacts:** bias/variance/MSE table, error-tail and coverage-width plots, fold-covariance diagnostics, raw-versus-clipped sensitivity if included.

### Stage 4 — Freeze conclusions and reproducibility handoff (days 6–7)
- **Goal:** turn measured evidence into narrow claims and an auditable handoff.
- **Run:** regenerate tables/figures from frozen outputs; provenance and leakage review; verify every numerical claim against an artifact. Leave time for the caller's manuscript and reproducibility deliverables.
- **Success signals:** no unsupported novelty, independence, superiority, or coverage claims; every planned cell is completed or marked failed/unavailable; all displayed numbers trace to real outputs.
- **Artifacts:** final comparison/ablation tables, compact pipeline schematic with information barriers, MAE/RMSE budget plots, bias–variance figure, limitations/negative-result summary, commands and observed runtime ledger.

## 8. Dependencies, preflight, iteration triggers, and stop rules

### Dependencies and local feasibility

- Required data: exactly the permitted binary `.jbl` matrices, pinned repository source, and any available model/item IDs. No external embeddings, paid API, GPU model, or extra dataset is necessary. Treat pickle/joblib loading as execution of a trusted artifact: verify pinned provenance first.
- Expected packages: compatible Python; `numpy`, `scipy`, `pandas`, `scikit-learn`, `joblib`, `matplotlib`; optionally `threadpoolctl`, `psutil`, and the caller's existing test runner. Record exact versions/BLAS threading. Add an IRT-specific dependency only if the selected source-only Rasch fitter actually requires it.
- Preflight should record CPU cores, available RAM, free disk, current artifact footprint, BLAS library/thread count, and Python/package versions. Record GPU/CUDA/VRAM as **not required; CPU-only policy** rather than making GPU availability a gate. Do not assume this review verified hardware.
- Avoid N×N item matrices, replicated full target matrices, per-target giant inverses, and saved dense per-seed nuisance predictions. Ridge can use b-sized dual solves; fixed queries/source covariates allow factorization reuse and batched target right-hand sides. Compute source-to-query cross-products once per design and stream item predictions as needed. This is a feasibility suggestion, not an implementation requirement.
- Measure a large-item, source-rich case before extrapolating runtime. Cache only reusable source-only quantities; limit threads to avoid oversubscription. Process small stages with checkpointed logs; do not assume a single foreground tool invocation can run for days. Keep storage near the guidance by saving score/fold summaries rather than every dense prediction.

### Hard stop / repair rules

1. **Leakage or broken algebra:** stop affected runs immediately; repair and invalidate/recompute affected outputs. Never keep favorable pre-repair numbers.
2. **Ambiguous data semantics or corruption:** stop the affected benchmark until provenance resolves it. Preserve zero rows; disclose unavailable cells rather than silently dropping hard cases or changing dataset.
3. **Failed pinned baseline:** diagnose and document; do not declare a win from its absence or replace it with an undisclosed adaptation. If unresolved, mark comparisons incomplete.
4. **Infeasible resources:** if the timed projection exceeds the week, remove optional low rank, gap-split expansion, clustering restarts, and dense diagnostics first. Preserve the core 13-benchmark paired comparison and leave at least one day for reporting. If even the core cannot finish, report the actual subset/missing cells; do not select datasets based on gains.
5. **Uninformative correlations or tiny effective sample:** retain score errors but mark ranking/inferential claims unavailable. Do not repair ties by jitter or count duplicates as extra evidence.

### Scientific iteration / stopping rules

- A preregistered practical reference can be **0.5 percentage point macro-MAE improvement** over raw uniform at frontier b=50; this is a decision threshold, not a claimed result or a significance test. Report exact effects even when smaller.
- If the proposed estimator loses RMSE or tail error despite smaller signed bias, conclude that the honest-audit variance cost dominates at these budgets. Do not tune pilots/weights on those targets to manufacture a win.
- If source-difficulty difference is as good or better, prefer the simpler control in recommendations; the value lies in the audit, not in making target-specific ridge appear necessary.
- If full-S AIPW has negligible detectable bias, state that exact unbiasedness was not empirically consequential here. The theorem alone does not establish an improvement.
- If heuristic intervals undercover, remove calibration/coverage language; retain the conservative reference or describe uncertainty as diagnostic. Wider valid intervals are a permissible negative result.
- Do not change the dataset, objective, predictor class, or primary split after seeing target performance. Any revised alpha, low rank, pilot ratio, or model is a separately labeled exploratory study needing fresh validation. End the planned comparison even if negative; do not search indefinitely for a winning configuration.

**Bottom line:** prioritize correct information boundaries, the AIPW/difference identity check, a source-difficulty difference control, dependent-fold uncertainty, and the repeated-mask stress test. Keep the initial model simple. The strongest defensible outcome may be a transparent negative result showing exactly when finite-sample honesty costs more variance than it removes bias.
