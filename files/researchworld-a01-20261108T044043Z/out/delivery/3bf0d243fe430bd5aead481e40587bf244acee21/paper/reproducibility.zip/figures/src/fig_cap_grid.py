"""F3: how the modelling assumption (per-task cap on the achievable gain) changes feasibility and cost, per rule and rank stratum.
Usage: python3 figures/src/fig_cap_grid.py RESULTS_DIR DATASET OUT_STEM
Input: RESULTS_DIR/core_<dataset>.csv. Caps grouped in families, each ordered from tight to loose (the families are not comparable on one axis, so lines are not drawn across them); rules with results at only some caps (ordinal rules on the OLLB
top-50) are drawn as unconnected markers. Left: fraction of targets feasible (Wilson 95% CI); right: median L1/n among feasible
targets (95% bootstrap CI over targets, B=1000, seed 0), omitted where fewer than 3 targets are feasible."""
import sys, argparse, pathlib, json
import numpy as np, pandas as pd, matplotlib.pyplot as plt
sys.path.insert(0, str(pathlib.Path(__file__).parent)); import style
ap = argparse.ArgumentParser(); ap.add_argument("resdir"); ap.add_argument("dataset"); ap.add_argument("out"); a = ap.parse_args(); style.setup()
d, prov = style.load_core(a.resdir, a.dataset); d = d[d.rank_mean >= 2]
FAMILIES = [("uniform +h points", ["gain5", "gain10", "gain20"]), ("empirical percentile", ["emp95", "emp95T", "emp99", "emp99T", "emp99P"]), ("ref.", ["front0", "ceil"])]
LAB = {"gain5": "5", "gain10": "10", "gain20": "20", "emp95": "p95", "emp95T": "p95$^T$", "emp99": "p99", "emp99T": "p99$^T$",
       "emp99P": "pool", "front0": "front", "ceil": "100"}
FAMILIES = [(f, [c for c in cs if c in set(d.cap)]) for f, cs in FAMILIES]
caps, XPOS, k = [], {}, 0
for f, cs in FAMILIES:
    for c in cs: caps.append(c); XPOS[c] = k; k += 1
    k += 1.0
rules = [r for r in style.MAIN_RULES if r in set(d.rule)]
STRATA = [("rank 2--5", 2, 5), ("rank 6--20", 6, 20), ("rank 21--100", 21, 100)] if a.dataset == "ollb" else [("rank 2--5", 2, 5), ("rank 6--20", 6, 20), ("rank 21--78", 21, 78)]
fig, axes = plt.subplots(len(STRATA), 2, figsize=(style.TEXTWIDTH_IN, 1.55 * len(STRATA) + 0.5), sharex=True, squeeze=False)
rng = np.random.default_rng(0); meta = {}
for r, (sl, lo, hi) in enumerate(STRATA):
    ds = d[d.rank_mean.between(lo, hi)]; nt = ds[ds.rule == "mean"].target.nunique()
    for rule in rules:
        for fam, cs in FAMILIES:
            xs, fr, flo, fhi, xm, med, mlo, mhi = [], [], [], [], [], [], [], []
            for cap in cs:
                i = XPOS[cap]; s = ds[(ds.cap == cap) & (ds.rule == rule) & ~ds.cens]
                if len(s) == 0: continue
                k = int(s.feas.sum()); l, h = style.wilson(k, len(s)); xs.append(i); fr.append(k / len(s)); flo.append(l); fhi.append(h)
                meta[f"{sl}/{rule}/{cap}"] = dict(n=int(len(s)), feasible=k)
                f = s[s.feas].L1n.to_numpy(float)
                if len(f) >= 3:
                    bs = np.median(rng.choice(f, (1000, len(f))), axis=1); xm.append(i); med.append(np.median(f)); mlo.append(np.percentile(bs, 2.5)); mhi.append(np.percentile(bs, 97.5))
            partial = len(xs) < len(cs) or rule in ("borda", "condorcet") and a.dataset == "ollb"
            kw = dict(color=style.RULE_COLOR[rule], marker=style.RULE_MARK[rule], ms=3.5, label=style.RULE_LABEL[rule] if fam == FAMILIES[0][0] else None, ls="none" if partial else "-")
            axes[r, 0].plot(xs, fr, **kw); axes[r, 1].plot(xm, med, **kw)
            axes[r, 0].vlines(xs, flo, fhi, color=kw["color"], lw=0.7, alpha=0.7); axes[r, 1].vlines(xm, mlo, mhi, color=kw["color"], lw=0.7, alpha=0.7)
    axes[r, 0].set_ylim(-0.03, 1.03); axes[r, 0].set_ylabel(f"{sl} ({nt} targets)\nfraction feasible", fontsize=7)
    axes[r, 1].set_yscale("symlog", linthresh=0.1); axes[r, 1].set_ylim(bottom=0); axes[r, 1].set_yticks([0, 0.1, 1, 10]); axes[r, 1].set_yticklabels(["0", "0.1", "1", "10"])
    axes[r, 1].set_ylabel("points per task, $L_1/n$", fontsize=7)
for ax in axes[-1]: ax.set_xticks([XPOS[c] for c in caps]); ax.set_xticklabels([LAB[c] for c in caps], fontsize=5.5)
for ax in axes.ravel():
    for fam, cs in FAMILIES[1:]: ax.axvline(XPOS[cs[0]] - 0.9, color="0.8", lw=0.6)
for ax in axes[0]:
    for fam, cs in FAMILIES: ax.text((XPOS[cs[0]] + XPOS[cs[-1]]) / 2, 1.04, fam, transform=ax.get_xaxis_transform(), ha="center", fontsize=5.5, color="0.3")
fig.supxlabel("per-task cap on the gain; within a family from tight to loose", fontsize=6.5)
h, l = axes[0, 0].get_legend_handles_labels(); fig.legend(h, l, loc="upper center", ncol=len(l), frameon=False, fontsize=6.8, bbox_to_anchor=(0.5, 1.01))
fig.tight_layout(rect=(0, 0, 1, 0.92))
for ext in ("pdf", "png"): fig.savefig(f"{a.out}.{ext}", dpi=200)
json.dump(dict(script="figures/src/fig_cap_grid.py", args={k: v for k, v in vars(a).items() if k != "resdir"}, inputs=[dict(file=f, sha256=h) for f, h in prov], cells=meta),
          open(f"{a.out}.json", "w"), indent=1)
