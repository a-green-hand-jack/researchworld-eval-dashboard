import itertools
import importlib.util
import sys
import types
from pathlib import Path
import numpy as np
from numpy.testing import assert_allclose
from sklearn.linear_model import Ridge

sys.path.insert(0, str(Path(__file__).parents[1] / 'src'))
from methods import (ridge_fit, predict_items, full_query_ridge, crossfit,
                     source_strata, designs, direction, fixed_difference,
                     stratified_mean, row_ridge, rasch_fit, rasch_predict)
from common import split_rows


def fixture():
    rng = np.random.default_rng(5)
    return rng.integers(0, 2, (8, 17)).astype(float), rng.integers(0, 2, (3, 17)).astype(float)


def test_ridge_exact_sklearn():
    x, y = fixture(); ids = np.array([1, 5, 8, 11, 15])
    b, a = ridge_fit(x, ids, y[:, ids])
    sk = Ridge(alpha=10).fit(x[:, ids].T, y[:, ids].T)
    assert_allclose(predict_items(x, np.arange(17), b, a), sk.predict(x.T).T, atol=1e-12)


def test_pinned_original_classes():
    # Import exact original code without its unrelated torch/IRT dependency tree.
    root = Path(__file__).parents[1] / 'vendor/benchmark-prediction/benchpred'
    package = types.ModuleType('isolated_vendor'); package.__path__ = [str(root)]
    base = types.ModuleType('isolated_vendor.base')
    base.BenchPred = object
    base.set_random_seed = lambda seed: np.random.seed(seed)
    sys.modules['isolated_vendor'] = package
    sys.modules['isolated_vendor.base'] = base
    for name in ['random', 'aipw']:
        spec = importlib.util.spec_from_file_location('isolated_vendor.' + name, root / (name + '.py'))
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        x, y = fixture()
        if name == 'aipw':
            model = mod.AIPWPred().fit(x, 5, seed=3)
            ids = model.get_coreset()
            expected = model.predict(y[:, ids])
            actual = full_query_ridge(x, ids, y[:, ids])[0]
        else:
            model = mod.RandomSamplingAndLearn().fit(x, 5, seed=3)
            ids = model.get_coreset()
            expected = model.predict(y[:, ids])
            actual = row_ridge(x, ids, y[:, ids])[0]
        assert_allclose(actual, expected, atol=1e-12)


def test_intercept_and_population_identity():
    x, y = fixture(); ids = np.arange(5)
    pinned, population, residual = full_query_ridge(x, ids, y[:, ids])
    assert_allclose(residual, 0, atol=1e-12)
    b, a = ridge_fit(x, ids, y[:, ids])
    q = predict_items(x, np.arange(17), b, a)
    difference = q.mean(1) + (y[:, ids] - q[:, ids]).mean(1)
    assert_allclose(population, difference, atol=1e-12)
    assert np.max(abs(pinned - population)) > 1e-6


def test_exhaustive_design_unbiased_uniform():
    rng = np.random.default_rng(9)
    for n, p, a in [(6, 2, 2), (5, 1, 2), (6, 3, 3)]:
        source = rng.integers(0, 2, (4, n)).astype(float)
        target = np.array([[0, 1] * (n // 2) + ([0] if n % 2 else []), [0] * n, [1] * n], float)
        estimates = []
        for pilot in itertools.combinations(range(n), p):
            rest = [i for i in range(n) if i not in pilot]
            for audit in itertools.combinations(rest, a):
                parts = [np.array(pilot), np.array(audit)]
                ys = [target[:, parts[0]], target[:, parts[1]]]
                estimates.append(crossfit(source, parts, ys, [np.arange(n)])[0])
        assert_allclose(np.mean(estimates, 0), target.mean(1), atol=1e-12)


def test_exhaustive_design_unbiased_stratified():
    n = 6
    source = np.array([[0,0,1,0,1,1],[1,0,0,1,1,0],[0,1,1,1,0,0]], float)
    target = np.array([[1,0,1,0,1,0],[0]*n,[1]*n], float)
    strata = [np.arange(3), np.arange(3,6)]
    estimates = []
    allocations = [[(p,a) for p in h for a in h if a != p] for h in strata]
    for choices in itertools.product(*allocations):
        parts = [np.array([c[k] for c in choices]) for k in [0,1]]
        ys = [target[:, parts[0]], target[:, parts[1]]]
        estimates.append(crossfit(source, parts, ys, strata)[0])
    assert_allclose(np.mean(estimates,0), target.mean(1), atol=1e-12)


def test_stratum_mean_and_difference_census():
    x, y = fixture(); ids = np.arange(17)
    strata = source_strata(x)
    assert_allclose(stratified_mean(17, ids, y, strata), y.mean(1))
    assert_allclose(fixed_difference(x, ids, y, strata), y.mean(1))


def test_no_duplicate_leakage():
    x, _ = fixture(); x = np.r_[x, x[:3]]
    for regime in ['iid', 'frontier']:
        s,t,g = split_rows(x, regime,0)
        assert not set(g[s]) & set(g[t])


def test_masking_and_audit_fit_independence():
    x, y = fixture(); strata = source_strata(x)
    ids, parts, ss, sp = designs(17,10,0,strata)
    observed = y[:,ids].copy()
    before = full_query_ridge(x,ids,observed)[1]
    y[:,[i for i in range(17) if i not in ids]] = 1 - y[:,[i for i in range(17) if i not in ids]]
    assert_allclose(before, full_query_ridge(x,ids,y[:,ids])[1])
    b,a = ridge_fit(x,parts[0],y[:,parts[0]])
    y[:,parts[1]] = 1-y[:,parts[1]]
    b2,a2 = ridge_fit(x,parts[0],y[:,parts[0]])
    assert_allclose(b,b2); assert_allclose(a,a2)


def test_query_counts_endpoint_rasch():
    x,y = fixture(); strata = source_strata(x)
    u,up,s,sp = designs(17,10,0,strata)
    assert len(np.unique(s)) == 10 and not set(sp[0]) & set(sp[1])
    beta,_,_ = rasch_fit(x)
    pred = rasch_predict(beta,u,np.array([[0]*10,[1]*10],float))
    assert np.isfinite(pred).all() and pred[0] < pred[1]


def test_rank_common_offset_roundoff_invariance():
    from run_experiments import metrics
    truth=np.array([.1,.2,.3,.4,.5])
    raw=np.array([.2,.2,.4,.4,.6])
    shifted=raw+.0009745164960183
    shifted[1]-=1e-16;shifted[3]+=1e-16
    a,b=metrics(truth,raw),metrics(truth,shifted)
    for key in ['rho','tau','pair_agreement']:
        assert a[key]==b[key]
    assert a['mae']!=b['mae'] # quantization affects ordering only


def test_nearest_source_ties_and_observed_retention():
    from nearest_source import predict
    source=np.array([[1,0,0,0],[1,0,1,1],[0,1,0,0]],float)
    ids=np.array([0,1]);y=np.array([[1,0]],float)
    # First two source signatures tie exactly; their unqueried totals average1.
    assert_allclose(predict(source,ids,y),[.5])


def test_invalid_stratum_budget_rejected():
    import pytest
    x,y=fixture();strata=source_strata(x)
    with pytest.raises(AssertionError):designs(17,18,0,strata)
    with pytest.raises(AssertionError):designs(17,5,0,strata)

