"""CPU-only estimators. Inference accepts ONLY queried target labels.

Score units are fractions, never percentages. No final-score clipping.
"""
import warnings
import numpy as np
from scipy.special import expit, logit
from sklearn.linear_model import RidgeCV
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import pairwise_distances_argmin


def source_strata(source, h=5):
    order = np.argsort(source.mean(0), kind='stable')
    return [np.sort(g) for g in np.array_split(order, h)]


def designs(n, budget, seed, strata):
    assert 2 * len(strata) <= budget <= n, 'infeasible pilot/audit budget'
    members=np.concatenate(strata)
    assert len(members)==n and np.array_equal(np.sort(members),np.arange(n)), 'strata must partition bank'
    rng = np.random.default_rng(20000 + seed)
    uniform = rng.permutation(n)[:budget]
    # Independent of labels and common across all targets.
    up = [uniform[:budget // 2], uniform[budget // 2:]]
    rng = np.random.default_rng(30000 + seed)
    h = len(strata)
    extra = rng.permutation(h)[:budget % h]
    p, a = [], []
    for j, ids in enumerate(strata):
        nh = budget // h + int(j in extra)
        assert nh <= len(ids), 'requested stratum sample exceeds population'
        sel = rng.permutation(ids)[:nh]
        k = nh // 2
        assert k > 0 and nh - k > 0
        p.extend(sel[:k]); a.extend(sel[k:])
    sp = [np.array(p, dtype=int), np.array(a, dtype=int)]
    return uniform, up, np.r_[sp[0], sp[1]], sp


def ridge_fit(source, ids, y, alpha=10.):
    """sklearn Ridge(alpha=alpha,fit_intercept=True) via exact dual solve.

    Covariates are SOURCE MODEL responses, examples are QUERIED ITEMS.
    y shape target x queried_items. Nuisance depends on pilot ids/labels only.
    """
    x = source[:, ids].T
    xm, ym = x.mean(0), y.mean(1)
    xc = x - xm
    yc = y.T - ym
    dual = np.linalg.solve(xc @ xc.T + alpha * np.eye(len(ids)), yc)
    coef = xc.T @ dual
    intercept = ym - xm @ coef
    return coef, intercept


def predict_items(source, ids, coef, intercept):
    return (source[:, ids].T @ coef + intercept).T


def sum_predictions(source, ids, coef, intercept):
    # ids may be the whole bank or a stratum complement.
    return source[:, ids].sum(1) @ coef + len(ids) * intercept


def row_ridge(source, ids, y):
    # Pinned Random-Sampling-Learn orientation and RidgeCV defaults.
    r = RidgeCV(alphas=(.1, 1., 10.))
    r.fit(source[:, ids], source.mean(1))
    return r.predict(y), float(r.alpha_)


def full_query_ridge(source, ids, y):
    n = source.shape[1]
    coef, intercept = ridge_fit(source, ids, y)
    qs = predict_items(source, ids, coef, intercept)
    qsum = sum_predictions(source, np.arange(n), coef, intercept)
    residual = (y - qs).mean(1)
    rest_mean = (qsum - qs.sum(1)) / (n - len(ids))
    # Exact pinned code; intercept makes its residual correction zero.
    pinned = rest_mean + (n - len(ids)) / n * residual
    population = (qsum - qs.sum(1) + y.sum(1)) / n
    return pinned, population, residual


def fixed_difference(source, ids, y, strata=None):
    d = source.mean(0)
    if strata is None:
        return d.mean() + (y - d[ids]).mean(1)
    result = np.full(y.shape[0], d.mean())
    for h in strata:
        loc = np.flatnonzero(np.isin(ids, h))
        result += len(h) / len(d) * (y[:, loc] - d[ids[loc]]).mean(1)
    return result


def stratified_mean(n, ids, y, strata):
    result = np.zeros(len(y))
    for h in strata:
        loc = np.flatnonzero(np.isin(ids, h))
        result += len(h) / n * y[:, loc].mean(1)
    return result


def direction(source, pilot, audit, yp, ya, strata):
    """Exactly unbiased conditional on pilot; audit membership cannot enter fit.

    Returns honest estimate, unaudited imputation, contaminated correction.
    """
    n = source.shape[1]
    coef, intercept = ridge_fit(source, pilot, yp)
    qp = predict_items(source, pilot, coef, intercept)
    qa = predict_items(source, audit, coef, intercept)
    qsum = sum_predictions(source, np.arange(n), coef, intercept)
    impute = (yp.sum(1) + qsum - qp.sum(1)) / n
    honest = impute.copy()
    for h in strata:
        ploc = np.flatnonzero(np.isin(pilot, h))
        aloc = np.flatnonzero(np.isin(audit, h))
        remaining = len(h) - len(ploc)
        assert len(aloc) > 0
        honest += remaining / n * (ya[:, aloc] - qa[:, aloc]).mean(1)
    # Deliberately contaminated residual: held fixed fits but reuses pilot errors.
    both = np.r_[pilot, audit]
    contaminated = qsum / n
    for h in strata:
        ploc = np.flatnonzero(np.isin(pilot, h))
        aloc = np.flatnonzero(np.isin(audit, h))
        errors = np.c_[yp[:, ploc] - qp[:, ploc], ya[:, aloc] - qa[:, aloc]]
        contaminated += len(h) / n * errors.mean(1)
    return honest, impute, contaminated


def crossfit(source, parts, yparts, strata):
    t1, i1, c1 = direction(source, parts[0], parts[1], yparts[0], yparts[1], strata)
    t2, i2, c2 = direction(source, parts[1], parts[0], yparts[1], yparts[0], strata)
    # Fixed half-average: prespecified before experiments, both directions unbiased.
    return (t1 + t2) / 2, t1, (i1 + i2) / 2, (c1 + c2) / 2


def rasch_fit(source, max_iter=200, tol=1e-6):
    """Penalized 1PL, alternating damped Newton: sum NLL+theta²/8+beta²/18.

    Not the multidimensional IRT/gpIRT algorithms from tinyBenchmarks.
    """
    m, n = source.shape
    theta = np.zeros(m)
    beta = -logit((source.sum(0) + .5) / (m + 1))
    for it in range(max_iter):
        p = expit(theta[:, None] - beta)
        diff = p - source
        v = p * (1 - p)
        dt = -(diff.sum(1) + theta / 4) / (v.sum(1) + .25)
        db = (diff.sum(0) - beta / 9) / (v.sum(0) + 1 / 9)
        dt = np.clip(dt, -1, 1); db = np.clip(db, -1, 1)
        theta += .5 * dt; beta += .5 * db
        # Resolve the common-shift likelihood invariance by exactly minimizing
        # its quadratic prior. Prevents slow drift mistaken for convergence.
        shift = -(theta.sum() / 4 + beta.sum() / 9) / (m / 4 + n / 9)
        theta += shift; beta += shift
        if max(abs(dt).max(), abs(db).max(), abs(shift)) < tol:
            break
    return beta, it + 1, max(abs(dt).max(), abs(db).max(), abs(shift))


def rasch_predict(beta, ids, y):
    theta = np.zeros(len(y))
    for _ in range(80):
        p = expit(theta[:, None] - beta[ids])
        step = ((p - y).sum(1) + theta / 4) / ((p * (1 - p)).sum(1) + .25)
        theta -= np.clip(step, -1, 1)
        if abs(step).max() < 1e-8:
            break
    p_all = expit(theta[:, None] - beta)
    return (p_all.sum(1) - p_all[:, ids].sum(1) + y.sum(1)) / len(beta)


def binary_anchors(source, budget, seed):
    """Linear-memory, approximate binary-correctness Anchor Points adaptation."""
    x = source.T.copy()
    km = MiniBatchKMeans(n_clusters=budget, random_state=seed, n_init=3,
                        batch_size=1024, max_iter=100, reassignment_ratio=0)
    with warnings.catch_warnings(record=True) as caught:
        km.fit(x)
    selected = []
    for center in km.cluster_centers_:
        distances = ((x - center) ** 2).sum(1)
        distances[selected] = np.inf
        selected.append(int(np.argmin(distances)))
    selected = np.array(selected)
    labels = pairwise_distances_argmin(x, x[selected], metric='euclidean')
    weights = np.bincount(labels, minlength=budget) / len(x)
    assert len(np.unique(selected)) == budget
    return selected, weights, [str(w.message) for w in caught]
