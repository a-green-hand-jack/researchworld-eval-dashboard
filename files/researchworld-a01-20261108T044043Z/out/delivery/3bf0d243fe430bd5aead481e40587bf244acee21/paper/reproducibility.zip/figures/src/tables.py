"""LaTeX tables from the analysis results.
Usage: python3 figures/src/tables.py RESULTS_DIR OUT_DIR
 T2  tables/T2_theory_check.tex  closed forms P1-P3 vs exact solvers (aggregated from results/theory_check.csv)
 T3  tables/T3_rules_<dataset>_<cap>.tex  one row per rule and rank stratum (T5_supp_rules_<dataset>.tex: supplementary rules, same layout): feasible share, median K and L1 among feasible targets with
     95% bootstrap CIs over targets (B=2000, RNG seeded from a hash of the input vector, so identical data give identical intervals in every table), and median L1 ratio to the mean rule over targets feasible under both (their count in parentheses).
 T6  tables/T6{a,b,c,d}_*.tex  sensitivity variants from summary/summary_variants.csv (margin; model sets; cost scale; task weights).
 T6b_copeland  tables/T6b_copeland.tex  Copeland on the top-500 slice: certified feasibility vs solved point costs per rank stratum (results/variants).
 T8-T10  tables/T8a_cap_uncertainty, T8b_allowance_ablation, T9_helm_allowance, T10a_ordinal_sample, T10b_ordinal_paired  results/cap_evidence and results/ordinal_sample (cap uncertainty, allowance ablation, HELM transfer allowance, wider ordinal sample).
 T7  tables/T7_leaf_vs_six.tex  OLLB 39 score components vs the six tasks on the same 499 models, paired per target (results/leaf/paired_leaf_vs_six.csv).
 T4  tables/T4_frontier_<dataset>.tex  feasibility frontier per cap role and rule (Wilson 95% CI, r*, all-feasible-up-to rank, half-feasibility bin).
Also writes tables/MANIFEST.json (input hashes)."""
import sys, pathlib, json, hashlib
import numpy as np, pandas as pd
sys.path.insert(0, str(pathlib.Path(__file__).parent)); import style
res, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]); out.mkdir(exist_ok=True, parents=True)
man = {}
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ci_med(v, B=2000):
    v = np.asarray(v, float)
    if len(v) == 0: return None
    # draws keyed by the input vector: the same data always gives the same interval, whatever the table or call order
    r = np.random.default_rng(int.from_bytes(hashlib.sha256(v.tobytes()).digest()[:8], "little"))
    bs = np.median(r.choice(v, (B, len(v))), axis=1)
    return np.median(v), *np.percentile(bs, [2.5, 97.5])
def fmt(m, digits=2):
    if m is None: return "--"
    return f"{m[0]:.{digits}f} [{m[1]:.{digits}f}, {m[2]:.{digits}f}]"
PRE = r"\begingroup\footnotesize\setlength{\tabcolsep}{3pt}" + "\n"   # every table file sets its own size: \input it directly, no \resizebox
RN = {"mean": "mean", "median": "median", "min": "min", "borda": "Borda", "condorcet": "Condorcet"}

# ---- T2
t = pd.read_csv(res / "theory_check.csv"); man["theory_check.csv"] = sha(res / "theory_check.csv")
t = t[t.comparison.isin(["closed_form_vs_solver", "closed_form_vs_generic"])]
rows = []
for (ds, rule, cmp), g in t.groupby(["dataset", "rule", "comparison"], sort=False):
    solver_only = g.max_abs_dev_L1.isna().all()
    rows.append((ds, rule, cmp, g.cap.nunique(), "--" if solver_only else f"{int(g.n_targets.iloc[0])}",
                 "solver only" if solver_only else f"{g.max_abs_dev_L1.max():.1e}",
                 "--" if solver_only else f"{g.max_abs_dev_K.max():.0f}", "--" if solver_only else f"{int(g.feasibility_mismatches.sum())}"))
L = [PRE + r"\begin{tabular}{@{}llllrrr@{}}", r"\toprule",
     r"data & rule & reference & max$|\Delta L_1|$ & max$|\Delta K|$ & feas.\ mismatches & caps \\", r"\midrule"]
nm = {"closed_form_vs_solver": "exact solver", "closed_form_vs_generic": "generic LP/MILP"}
for ds, rule, cmp, ncap, nt, dev, dk, mm in rows:
    L.append(f"{'OLLB' if ds == 'ollb' else 'HELM'} & {RN[rule]} & {nm[cmp]} & {dev} & {dk} & {mm} & {ncap} \\\\")
L += [r"\bottomrule", r"\end{tabular}\endgroup"]
(out / "T2_theory_check.tex").write_text("\n".join(L) + "\n")

# ---- T3 / T5 (one row per rule x rank stratum; set \footnotesize, 7-8 pt at 5.5 in without resizing)
RN.update({"geomean": "geometric", "harmonic": "harmonic", "pow-2": "power $p{=}{-}2$", "plurality": "plurality", "copeland": "Copeland"})
STRATA = [("2--10", 2, 10), ("11--50", 11, 50), ("all", 2, 10**9)]
ORD_TOP50 = {"ollb": ("borda", "condorcet", "plurality")}   # solved exactly for the 50 best OLLB targets only: no 'all' row
def rule_table(dc, rules, ds):
    piv = dc.pivot_table(index="target", columns="rule", values="L1", aggfunc="first")
    L = [PRE + r"\begin{tabular}{@{}llrcccc@{}}", r"\toprule",
         r"rule & rank & feas.\ & $K$ [95\% CI] & $L_1$ [95\% CI] & $L_1/L_1^{\text{mean}}$ [95\% CI] & paired $n$ \\", r"\midrule"]
    for ri, rule in enumerate(rules):
        if ri: L.append(r"\addlinespace[2pt]")
        for si, (sn, lo, hi) in enumerate(STRATA):
            top50 = rule in ORD_TOP50.get(ds, ())
            if sn == "all" and top50: continue
            s = dc[(dc.rule == rule) & dc.rank_mean.between(lo, hi) & ~dc.cens]
            lab = (RN[rule] + (r"$^\dagger$" if top50 else "")) if si == 0 else ""
            if s.empty: continue
            f = s[s.feas]; k = int(len(f)); m_K = ci_med(f.K.to_numpy(float)); m_L = ci_med(f.L1.to_numpy(float))
            ratio, npair = None, 0
            if rule != "mean" and "mean" in piv and k:
                base = piv.loc[f.target, "mean"].to_numpy(float); num = f.L1.to_numpy(float)
                ok = np.isfinite(base) & (base > 0) & np.isfinite(num); npair = int(ok.sum())
                ratio = ci_med(num[ok] / base[ok]) if ok.any() else None
            L.append(f"{lab} & {sn} & {k}/{len(s)} & {fmt(m_K, 1)} & {fmt(m_L, 1)} & {'--' if rule == 'mean' else fmt(ratio)} & {'--' if rule == 'mean' else npair} \\\\")
    L += [r"\bottomrule", r"\end{tabular}\endgroup"]
    return "\n".join(L) + "\n"
for ds in ("ollb", "helm"):
    d, prov = style.load_core(res, ds); man[prov[0][0]] = prov[0][1]
    for cap in (style.PRIMARY_CAP[ds], "ceil"):
        dc = d[(d.cap == cap) & (d.rank_mean >= 2)]
        (out / f"T3_rules_{ds}_{cap}.tex").write_text(rule_table(dc, style.MAIN_RULES, ds))
    # T5: supplementary rules at the primary cap; the mean rule is included as the reference of the paired ratio
    sup = ("mean", "geomean", "harmonic", "pow-2", "plurality") if ds == "ollb" else ("mean", "geomean", "harmonic", "plurality", "copeland")
    dc = d[(d.cap == style.PRIMARY_CAP[ds]) & (d.rank_mean >= 2)]
    (out / f"T5_supp_rules_{ds}.tex").write_text(rule_table(dc, sup, ds))
# ---- T4
def frontier(dc):
    s = dc[~dc.cens]; n = len(s); k = int(s.feas.sum()); lo, hi = style.wilson(k, n)
    rstar = int(s[s.feas].rank_mean.max()) if k else None
    srt = s.sort_values("rank_mean"); bad = srt[~srt.feas]
    r_all = int(bad.rank_mean.min()) - 1 if len(bad) else int(srt.rank_mean.max())   # all targets with rank <= r_all are feasible
    half = None
    for blo, bhi in style.RANK_BINS:
        b = s[s.rank_mean.between(blo, bhi)]
        if len(b) >= 3 and b.feas.mean() < 0.5: half = f"{blo}--{min(bhi, int(s.rank_mean.max()))}"; break
    return n, k, lo, hi, rstar, r_all, half, int(dc.cens.sum())
for ds in ("ollb", "helm"):
    d, prov = style.load_core(res, ds)
    L = [PRE + r"\begin{tabular}{@{}llrrcrrl@{}}", r"\toprule",
         r"cap & rule & targets & feasible & share [95\% CI] & $r^*$ & all feas.\ up to & first bin $<$ 1/2 \\", r"\midrule"]
    for role, cap in (("primary", style.PRIMARY_CAP[ds]), ("oracle", "ceil")):
        for rule in style.MAIN_RULES:
            dc = d[(d.cap == cap) & (d.rule == rule) & (d.rank_mean >= 2)]
            if dc.empty: continue
            n, k, lo, hi, rstar, r_all, half, nc = frontier(dc)
            note = r"$^\dagger$" if (ds == "ollb" and rule in ("borda", "condorcet")) else ""
            L.append(f"{role} (\\texttt{{{cap}}}) & {RN[rule]}{note} & {n} & {k} & {k / n:.2f} [{lo:.2f}, {hi:.2f}] & {rstar if rstar else '--'} & {r_all} & {half or 'none'} \\\\")
        if role == "primary": L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabular}\endgroup"]
    (out / f"T4_frontier_{ds}.tex").write_text("\n".join(L) + "\n")
# ---- T6: sensitivity variants (summary_variants.csv of the analysis; group 'all' only). Medians are the analysis's point values, shares get Wilson 95% CIs
vp = res / "summary" / "summary_variants.csv"; man["summary/summary_variants.csv"] = sha(vp)
V = pd.read_csv(vp); V = V[V.group == "all"]
VR = {"mean": "mean", "median": "median", "min": "min", "borda": "Borda", "condorcet": "Condorcet", "plurality": "plurality", "copeland": "Copeland",
      "dirichlet1": "Dirichlet(1)", "dirichlet5": "Dirichlet(5)", "onehot": "one task"}
DS = {"ollb": "OLLB", "helm": "HELM"}
def share(r):
    k = int(round(r.feas_frac * r.n)); l, h = style.wilson(k, int(r.n)); return f"{k}/{int(r.n)} [{l:.2f}, {h:.2f}]"
def num(x, d=1): return "--" if pd.isna(x) else f"{x:.{d}f}"
def vtable(rows, cols, head, spec):
    L = [PRE + r"\begin{tabular}{@{}" + spec + r"@{}}", r"\toprule", head + r" \\", r"\midrule"]; last = None; prev = None
    for key, r in rows:
        if last is not None and key != last: L.append(r"\addlinespace[2pt]")
        L.append(" & ".join(c(r, prev) for c in cols) + r" \\"); last = key; prev = r
    L += [r"\bottomrule", r"\end{tabular}\endgroup"]; return "\n".join(L) + "\n"
def first(f, kf=lambda r: (r.variant, r.dataset)): return lambda r, p: f(r) if p is None or kf(p) != kf(r) else ""
ratio = lambda r: num(r.L1_ratio_med, 2); both = lambda r: "--" if pd.isna(r.n_both) else str(int(r.n_both))
base = lambda r: "--" if pd.isna(r.feas_frac_base) else f"{r.feas_frac_base:.2f}"
def block(rows, label):  # label(r) -> text of the first column
    return [(label(r), r) for r in rows.itertuples()]
# T6a: score margin
v = V[V.variant.isin(["margin1_eps", "margin2_eps"])].copy(); v["m"] = v.variant.map({"margin1_eps": "1", "margin2_eps": "2"})
v["o"] = v.rule.map({r: i for i, r in enumerate(VR)}); v = v.sort_values(["dataset", "m", "o"])
rows = [((r.dataset, r.m), r) for r in v.itertuples()]
cols = [first(lambda r: DS[r.dataset], lambda r: r.dataset), first(lambda r: r.m, lambda r: (r.dataset, r.m)), lambda r, p: VR[r.rule], lambda r, p: share(r), lambda r, p: base(r), lambda r, p: num(r.K_med_feas), lambda r, p: num(r.L1_med_feas), lambda r, p: both(r), lambda r, p: ratio(r)]
(out / "T6a_margin.tex").write_text(vtable(rows, cols, r"data & margin & rule & feasible [95\% CI] & base share & median $K$ & median $L_1$ & paired $n$ & $L_1/L_1^{\text{base}}$", "llllcccrc"))
# Copeland on the top-500 slice: certified feasibility (solver-feasible, solver-infeasible, or censored but winning/losing at the cap-saturated vector) kept apart from the solved point costs
sp_ = res / "variants" / "copeland_top500_screen.csv"; cv_ = res / "variants" / "var_ollb_top500.csv"; man["variants/copeland_top500_screen.csv"] = sha(sp_); man["variants/var_ollb_top500.csv"] = sha(cv_)
CS = pd.read_csv(sp_); CS = CS[CS.rank_mean >= 2]
CC = pd.read_csv(cv_); CC = CC[CC.rule == "copeland"][["target", "L1", "K"]]; CS = CS.merge(CC, on="target", how="left")
assert len(CS) == 499
BINS = [("2--5", 2, 5), ("6--10", 6, 10), ("11--30", 11, 30), ("31--100", 31, 100), ("101--300", 101, 300), ("$>$300", 301, 10**6)]
def cop_stats(d):
    # screen schema of the analysis: l1_status (solved / infeasible / censored), feasibility (feasible / infeasible, settled separately from L1), K_status
    f = d[d.l1_status == "solved"]; cen = d[d.l1_status == "censored"]; ok = int((d.feasibility == "feasible").sum())
    return dict(n=len(d), feas=ok, lo=style.wilson(ok, len(d))[0], hi=style.wilson(ok, len(d))[1],
                inf_solver=int((d.l1_status == "infeasible").sum()), inf_screen=int((cen.feasibility == "infeasible").sum()),
                solved=len(f), cens_feas=int((cen.feasibility == "feasible").sum()), K=f.K.median() if len(f) else np.nan, L1=f.L1.median() if len(f) else np.nan)
COP = cop_stats(CS)
assert (CS[(CS.l1_status == "censored") & (CS.feasibility == "feasible")].K_status == "solved").all() and np.isfinite(CS[CS.feasibility == "feasible"].K).all()   # feasible but L1-censored targets have a solved K
fp_ = res / "variants" / "copeland_top500_feasibility.csv"; man["variants/copeland_top500_feasibility.csv"] = sha(fp_); CF = pd.read_csv(fp_).set_index("group")
# consistency with the analysis summary (solved-finite share and censored count)
_c = pd.read_csv(vp); _c = _c[(_c.variant == "var_ollb_top500") & (_c.rule == "copeland") & (_c.group == "all")].iloc[0]
assert COP["solved"] == int(round(_c.feas_frac * _c.n)) and COP["cens_feas"] + COP["inf_screen"] == int(_c.n_censored), (COP, dict(_c))
for _lab, _lo, _hi in BINS:   # per-stratum counts against the analysis's own file
    _c2 = cop_stats(CS[(CS.rank_mean >= _lo) & (CS.rank_mean <= _hi)]); _r = CF.loc[{"2--5": "2-5", "6--10": "6-10", "11--30": "11-30", "31--100": "31-100", "101--300": "101-300", "$>$300": ">300"}[_lab]]
    assert (_c2["n"], _c2["feas"], _c2["solved"], _c2["cens_feas"]) == (_r.n, _r.n_feasible, _r.n_L1_solved, _r.n_L1_censored_feasible), (_lab, _c2, dict(_r))
assert (COP["n"], COP["feas"], COP["solved"], COP["cens_feas"], COP["inf_screen"]) == tuple(int(CF.loc["all, rank>=2", k]) for k in ("n", "n_feasible", "n_L1_solved", "n_L1_censored_feasible", "n_L1_censored_infeasible"))
assert abs(COP["L1"] - _c.L1_med_feas) < 1e-6 and abs(COP["K"] - _c.K_med_feas) < 1e-6
# T6b: changed model sets (two tables) on OLLB (nomerge: rivals and targets without merged models; top500: rival set restricted to the 500 best models)
v = V[V.variant.isin(["var_ollb_nomerge", "var_ollb_top500"])].copy(); v["o"] = v.rule.map({r: i for i, r in enumerate(VR)})
v["nm"] = v.variant.map({"var_ollb_nomerge": "no merged models", "var_ollb_top500": "top-500 rivals"}); v["cr"] = v.cap.map({"emp99": 0, "ceil": 1}); v = v.sort_values(["variant", "cr", "o"])
t500 = v.variant == "var_ollb_top500"
v.loc[t500, ["feas_frac_base", "n_both", "L1_ratio_med"]] = np.nan   # base share/ratios of the ordinal rules are not defined on the full board (top-50 base) -> suppressed
v["cen"] = v.n_censored.astype(int)
for var, fn in (("var_ollb_nomerge", "T6b_nomerge.tex"), ("var_ollb_top500", "T6b_top500.tex")):
    vv = v[v.variant == var]; rows = [((r.cap,), r) for r in vv.itertuples()]
    cp = first(lambda r: "primary" if r.cap == "emp99" else "oracle", lambda r: r.cap)
    if var == "var_ollb_nomerge":
        cols = [cp, lambda r, p: VR[r.rule], lambda r, p: share(r), lambda r, p: base(r), lambda r, p: num(r.K_med_feas), lambda r, p: num(r.L1_med_feas), lambda r, p: both(r), lambda r, p: ratio(r)]
        head, spec = r"cap & rule & feasible [95\% CI] & base share & median $K$ & median $L_1$ & paired $n$ & $L_1/L_1^{\text{base}}$", "llcccrrc"
    else:
        # Copeland is the only censored rule here: its feasible share is the certified one (solved + screened, see below), its costs are conditional on the solved targets
        cop = lambda r, f, g: (f(r) if r.rule != "copeland" else g)
        cols = [cp, lambda r, p: VR[r.rule] + (r"$^\ddagger$" if r.rule == "copeland" else ""),
                lambda r, p: cop(r, share, f"{COP['feas']}/{COP['n']} [{COP['lo']:.2f}, {COP['hi']:.2f}]"), lambda r, p: str(r.cen),
                lambda r, p: num(r.K_med_feas), lambda r, p: num(r.L1_med_feas)]
        head, spec = r"cap & rule & feasible [95\% CI] & $L_1$ censored & median $K$ & median $L_1$", "llcccc"
    (out / fn).write_text(vtable(rows, cols, head, spec))
L = [PRE + r"\begin{tabular}{@{}lrcccccc@{}}", r"\toprule",
     r" & & certified & infeasible & $L_1$ & $L_1$ censored & median & median \\",
     r"rank & $n$ & feasible [95\% CI] & solver / screen & solved & feas. / infeas. & $K^\ddagger$ & $L_1^\ddagger$ \\", r"\midrule"]
for lab, lo_, hi_ in BINS + [("all", 2, 10**6)]:
    d = CS[(CS.rank_mean >= lo_) & (CS.rank_mean <= hi_)]; c = cop_stats(d)
    if lab == "all": L.append(r"\addlinespace[2pt]")
    L.append(f"{lab} & {c['n']} & {c['feas']}/{c['n']} [{c['lo']:.2f}, {c['hi']:.2f}] & {c['inf_solver']} / {c['inf_screen']} & {c['solved']} & {c['cens_feas']} / {c['inf_screen']} & {num(c['K'])} & {num(c['L1'])} \\\\")
L += [r"\bottomrule", r"\end{tabular}\endgroup"]
(out / "T6b_copeland.tex").write_text("\n".join(L) + "\n")
# T6c: cost scale (raw OLLB scores; cost in across-model task standard deviations): within-scale values only, no ratio to the main specification
v = V[V.variant.isin(["var_ollb_raw", "zcost"])].copy(); v["o"] = v.rule.map({r: i for i, r in enumerate(VR)})
v["sc"] = np.where(v.variant == "zcost", "task-SD units, " + v.dataset.map(DS), "OLLB raw, points")
v["cr"] = v.cap.map(lambda c: 0 if c.startswith("emp") or c == "gain10" else 1); v = v.sort_values(["sc", "cr", "o"])
rows = [((r.sc, r.cap), r) for r in v.itertuples()]
cols = [first(lambda r: r.sc, lambda r: r.sc), first(lambda r: {"emp99": r"\texttt{emp99}", "emp99T": r"\texttt{emp99T}", "gain10": "+10", "ceil": "oracle"}[r.cap], lambda r: (r.sc, r.cap)), lambda r, p: VR[r.rule], lambda r, p: share(r), lambda r, p: "--" if r.variant == "zcost" else num(r.K_med_feas), lambda r, p: num(r.L1_med_feas)]
(out / "T6c_scale.tex").write_text(vtable(rows, cols, r"cost scale & cap & rule & feasible [95\% CI] & median $K$ & median $L_1$", "lllccc"))
# T6d: random task weights (n counts draws at the stratified targets, not distinct models)
v = V[V.variant == "weights"].copy(); v["o"] = v.rule.map({r: i for i, r in enumerate(VR)}); v = v.sort_values(["dataset", "o"])
rows = [((r.dataset,), r) for r in v.itertuples()]
cols = [first(lambda r: DS[r.dataset], lambda r: r.dataset), lambda r, p: VR[r.rule], lambda r, p: share(r), lambda r, p: base(r), lambda r, p: num(r.K_med_feas), lambda r, p: num(r.L1_med_feas), lambda r, p: both(r), lambda r, p: ratio(r)]
(out / "T6d_weights.tex").write_text(vtable(rows, cols, r"data & weights & feasible draws [95\% CI] & base share & median $K$ & median $L_1$ & paired $n$ & $L_1/L_1^{\text{unif.}}$", "llcccrcc"))
# ---- T7: OLLB 39 score components (leaves) vs the six published tasks, same 499 models (results/leaf/paired_leaf_vs_six.csv, group 'all')
lp = res / "leaf" / "paired_leaf_vs_six.csv"; man["leaf/paired_leaf_vs_six.csv"] = sha(lp)
Lp = pd.read_csv(lp); Lp = Lp[Lp.group_by_six_rank == "all"]; SC = 6 / 39   # cost per task: L1/39 on the leaves over L1/6 on the six tasks = (L1 ratio) x 6/39
CAPN = {"ceil": "oracle", "gain10": "+10", "emp99task": r"\texttt{emp99}$^{\S}$"}
def leaf_rows(rules, note):
    out_rows = []
    for cap in ("ceil", "gain10", "emp99task"):
        for rule in rules:
            r = Lp[(Lp.cap == cap) & (Lp.rule == rule)].iloc[0]
            out_rows.append((cap, r, note))
    return out_rows
L = [PRE + r"\begin{tabular}{@{}llrrrrc@{}}", r"\toprule",
     r"cap & rule & examined & feas.\ 39 & feas.\ six & paired $n$ & $(L_1/39)\,/\,(L_1/6)$ [95\% CI] \\", r"\midrule"]
for blk, (rules, note) in enumerate((( ("mean", "median", "min"), ""), (("borda", "condorcet", "plurality"), r"$^\dagger$"))):
    if blk: L.append(r"\midrule")
    for cap in ("ceil", "gain10", "emp99task"):
        for ri, rule in enumerate(rules):
            r = Lp[(Lp.cap == cap) & (Lp.rule == rule)].iloc[0]
            rat = f"{r.L1_ratio_med * SC:.2f} [{r.L1_ratio_lo * SC:.2f}, {r.L1_ratio_hi * SC:.2f}]"
            L.append(f"{CAPN[cap] if ri == 0 else ''} & {RN[rule]}{note} & {int(r.n_targets)} & {int(r.n_feasible_leaf)} & {int(r.n_feasible_six)} & {int(r.n_both)} & {rat} \\\\")
        if cap != "emp99task": L.append(r"\addlinespace[2pt]")
L += [r"\bottomrule", r"\end{tabular}\endgroup"]
(out / "T7_leaf_vs_six.tex").write_text("\n".join(L) + "\n")
# ---- T8: OLLB cap uncertainty (pair bootstrap of the 540 gain vectors) and allowance ablation (results/cap_evidence/)
cp = res / "cap_evidence" / "pair_bootstrap_summary.csv"; lp8 = res / "cap_evidence" / "loto_allowance.csv"
man["cap_evidence/pair_bootstrap_summary.csv"] = sha(cp); man["cap_evidence/loto_allowance.csv"] = sha(lp8)
PB = pd.read_csv(cp); LT = pd.read_csv(lp8)
def rng3(o, lo, hi, d=0, pct=False):
    f = (lambda x: f"{100 * x:.{d}f}") if pct else (lambda x: f"{x:.{d}f}")
    return f"{f(o)} [{f(lo)}, {f(hi)}]"
def pb(rule, stat, d=0, pct=False):
    r = PB[(PB.rule == rule) & (PB.stat == stat)].iloc[0]; return rng3(r.observed, r.p2_5, r.p97_5, d, pct)
L = [PRE + r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
     r"rule & feasible targets & share (\%) & largest feasible rank & all-feasible prefix \\", r"\midrule"]
for rule in ("mean", "median", "min"):
    L.append(f"{RN[rule]} & {pb(rule, 'n_feasible')} & {pb(rule, 'share', 1, True)} & {pb(rule, 'max_feasible_rank')} & {pb(rule, 'prefix_rank')} \\\\")
L += [r"\bottomrule", r"\end{tabular}\endgroup"]
(out / "T8a_cap_uncertainty.tex").write_text("\n".join(L) + "\n")
TASKN = {"IFEval": "IFEval", "BBH": "BBH", "MATH Lvl 5": "MATH", "GPQA": "GPQA", "MUSR": "MuSR", "MMLU-PRO": "MMLU-Pro"}
L = [PRE + r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
     r"allowance left out & \texttt{emp99} cap (points) & mean & median & min \\", r"\midrule",
     "none (primary) & -- & " + " & ".join(pb(r, "n_feasible") for r in ("mean", "median", "min")) + r" \\", r"\midrule"]
for task in TASKN:
    c = PB[(PB.rule == "all") & (PB.stat == f"emp99_cap_{task}")].iloc[0]
    cells = []
    for rule in ("mean", "median", "min"):
        r = LT[(LT.dropped == task) & (LT.rule == rule)].iloc[0]; cells.append(f"{int(r.n_feasible)} [{r.n_feasible_p2_5:.0f}, {r.n_feasible_p97_5:.0f}]")
    L.append(f"{TASKN[task]} & {rng3(c.observed, c.p2_5, c.p97_5, 1)} & " + " & ".join(cells) + r" \\")
L += [r"\bottomrule", r"\end{tabular}\endgroup"]
(out / "T8b_allowance_ablation.tex").write_text("\n".join(L) + "\n")

# ---- T9: HELM transfer allowance sensitivity (results/cap_evidence/helm_transfer_sensitivity.csv)
hp = res / "cap_evidence" / "helm_transfer_sensitivity.csv"; man["cap_evidence/helm_transfer_sensitivity.csv"] = sha(hp)
HT = pd.read_csv(hp)
HN = [("ollb_emp99_GPQA", r"GPQA \texttt{emp99}"), ("ollb_emp99_MMLU-PRO", r"MMLU-Pro \texttt{emp99}$^{\star}$"), ("ollb_emp99_MUSR", r"MuSR \texttt{emp99}"),
      ("ollb_emp99_BBH", r"BBH \texttt{emp99}"), ("ollb_emp99_MATH Lvl 5", r"MATH \texttt{emp99}"), ("ollb_emp99_IFEval", r"IFEval \texttt{emp99}"),
      ("gain5", "uniform $+5$"), ("gain10", "uniform $+10$"), ("gain20", "uniform $+20$")]
assert set(HT.allowance) == {a for a, _ in HN}
L = [PRE + r"\begin{tabular}{@{}lrrrrr@{}}", r"\toprule",
     r"allowance (all 57 subjects) & $h$ & \multicolumn{2}{c}{mean rule} & median rule & min rule \\", r"\cmidrule(lr){3-4}",
     r" & & feas.\ (\%) [CI of \%] & prefix / max rank & feas.\ (\%) & feas.\ (\%) \\", r"\midrule"]
for a, nm_ in HN:
    if a == "gain5": L.append(r"\midrule")
    g = HT[HT.allowance == a].set_index("rule")
    m = g.loc["mean"]
    c_mean = f"{int(m.n_feasible)} ({100 * m.share:.0f}) [{100 * m.share_p2_5:.0f}, {100 * m.share_p97_5:.0f}]"
    L.append(f"{nm_} & {m.h:.1f} & {c_mean} & {int(m.prefix_rank)} / {int(m.max_feasible_rank)} & "
             + " & ".join(f"{int(g.n_feasible[r])} ({100 * g.share[r]:.0f})" for r in ("median", "min")) + r" \\")
L += [r"\bottomrule", r"\end{tabular}\endgroup"]
(out / "T9_helm_allowance.tex").write_text("\n".join(L) + "\n")

# ---- T10: wider ordinal sample (results/ordinal_sample/): 15 targets per rank stratum of the OLLB board, Borda and Condorcet
sp = res / "ordinal_sample" / "summary_status.csv"; pp = res / "ordinal_sample" / "paired_vs_mean.csv"
man["ordinal_sample/summary_status.csv"] = sha(sp); man["ordinal_sample/paired_vs_mean.csv"] = sha(pp)
SS = pd.read_csv(sp); PV = pd.read_csv(pp); STR = ["51-100", "101-300", "301-1000", ">1000"]
CN = {"ceil": "oracle", "emp99": r"\texttt{emp99}"}
L = [PRE + r"\begin{tabular}{@{}llrrrrrr@{}}", r"\toprule",
     r" & & \multicolumn{4}{c}{feasible / 15 by rank stratum} & \multicolumn{2}{c}{all 60 sampled targets} \\",
     r"\cmidrule(lr){3-6}\cmidrule(l){7-8}",
     r"cap & rule & 51--100 & 101--300 & 301--1000 & $>$1000 & feasible & infeas.\ / censored \\", r"\midrule"]
for cap in ("emp99", "ceil"):
    for ri, rule in enumerate(("borda", "condorcet")):
        g = SS[(SS.cap == cap) & (SS.rule == rule)].set_index("stratum")
        a = g.loc["all"]
        assert (g.n_infeasible_milp == 0).all() and (g.n_censored == 0).all() and (g.n_already_first == 0).all()
        L.append(f"{CN[cap] if ri == 0 else ''} & {RN[rule]} & " + " & ".join(f"{int(g.n_feasible[s])}" for s in STR)
                 + f" & {int(a.n_feasible)} & {int(a.n_infeasible_screen)} / {int(a.n_censored)} \\\\")
    if cap == "emp99": L.append(r"\addlinespace[2pt]")
L += [r"\bottomrule", r"\end{tabular}\endgroup"]
(out / "T10a_ordinal_sample.tex").write_text("\n".join(L) + "\n")
L = [PRE + r"\begin{tabular}{@{}llrrrrr@{}}", r"\toprule",
     r"cap & rule & rule feas. & mean feas. & both & $L_1$ ratio to mean [95\% CI] & $K$ ratio to mean [95\% CI] \\", r"\midrule"]
for cap in ("emp99", "ceil"):
    for ri, rule in enumerate(("borda", "condorcet")):
        r = PV[(PV.cap == cap) & (PV.rule == rule)].iloc[0]
        L.append(f"{CN[cap] if ri == 0 else ''} & {RN[rule]} & {int(r.n_rule_feasible)} & {int(r.n_mean_feasible_on_sample)} & {int(r.n_both)} & "
                 f"{r.L1_ratio_median:.2f} [{r.L1_ratio_lo:.2f}, {r.L1_ratio_hi:.2f}] & {r.K_ratio_median:.1f} [{r.K_ratio_lo:.1f}, {r.K_ratio_hi:.1f}] \\\\")
    if cap == "emp99": L.append(r"\addlinespace[2pt]")
L += [r"\bottomrule", r"\end{tabular}\endgroup"]
(out / "T10b_ordinal_paired.tex").write_text("\n".join(L) + "\n")
json.dump(dict(script="figures/src/tables.py", inputs=man), open(out / "MANIFEST.json", "w"), indent=1)
