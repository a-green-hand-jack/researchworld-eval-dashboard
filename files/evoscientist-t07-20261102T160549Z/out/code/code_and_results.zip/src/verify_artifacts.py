"""Read-only final audit of all saved metric records, masks and paper limits."""
import json,zipfile
import numpy as np
from pypdf import PdfReader
from common import ROOT,load,sha256
from run_experiments import metrics


def main():
    report={'counts':{},'metric_records_verified':0,'group_metric_records_verified':0,'offset_invariants':0}
    for directory,expected in [('runs',195),('irt_runs',130),('nearest_runs',130)]:
        files=sorted((ROOT/'artifacts'/directory).glob('*.json'))
        assert len(files)==expected,(directory,len(files))
        report['counts'][directory]=len(files)
        for path in files:
            data=json.loads(path.read_text())
            saved=np.load(path.with_suffix('.npz'))
            base=np.load(ROOT/'artifacts/runs'/path.with_suffix('.npz').name)
            true=base['true'];rep=base['rep']
            for r in data['records']:
                # Check every raw-error record and every group-level rank record.
                idx=rep if r['weighting']=='group' else np.arange(len(true))
                pred=saved[f"{r['method']}__b{r['budget']}"]
                calc=metrics(true[idx],pred[idx])
                for key in calc:
                    a,b=calc[key],r[key]
                    assert (a is None and b is None) or (a is not None and b is not None and abs(a-b)<1e-12),(path,key,a,b)
                report['metric_records_verified']+=1
                report['group_metric_records_verified']+=int(r['weighting']=='group')
            if directory=='runs':
                for budget in sorted(set(r['budget'] for r in data['records'])):
                    for prefix in ['uniform','stratified']:
                        a='uniform' if prefix=='uniform' else 'stratified_mean'
                        b='item_difference' if prefix=='uniform' else 'stratified_difference'
                        ma=metrics(true[rep],saved[f'{a}__b{budget}'][rep]);mb=metrics(true[rep],saved[f'{b}__b{budget}'][rep])
                        assert all(ma[k]==mb[k] for k in ['rho','tau','pair_agreement'])
                        report['offset_invariants']+=1
    # Recheck true labels against the actual fixed matrices, not only saved truth.
    for name in ['gsm','mmlu_pro','openllm_math']:
        x=load(name)
        for regime in ['iid','frontier']:
            s=np.load(ROOT/'artifacts/runs'/f'{name}__{regime}__s0.npz')
            assert np.array_equal(s['true'],x[s['target_rows']].mean(1))
    pdf=PdfReader(ROOT/'paper.pdf')
    refpage=next(i for i,p in enumerate(pdf.pages) if 'References' in (p.extract_text() or '') and 'Balk' in (p.extract_text() or ''))
    assert refpage<=9
    log=(ROOT/'paper/main.log').read_text()
    assert 'undefined' not in log.lower() and 'Overfull' not in log
    checklist=(ROOT/'paper/checklist_filled.tex').read_text()
    assert 'TODO' not in checklist and checklist.count('Question:')==16
    assert sha256(ROOT/'paper/neurips_2026.sty')=='c3fc2894e83d2517ca18b66741d6c595986d97957dc08ec08bb2125a7ec4555a'
    report.update(paper_pages=len(pdf.pages),content_pages=refpage,official_content_limit=9,
                  checklist_questions=16,style_unchanged=True,pdf_sha256=sha256(ROOT/'paper.pdf'))
    for name in ['code_and_results.zip','paper_source.zip']:
        path=ROOT/name
        if path.exists():
            with zipfile.ZipFile(path) as z:assert z.testzip() is None
            report[name]={'bytes':path.stat().st_size,'sha256':sha256(path)}
    (ROOT/'artifacts/final_verification.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
