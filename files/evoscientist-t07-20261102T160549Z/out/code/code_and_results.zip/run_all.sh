#!/bin/sh
set -eu
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
JOBS=${JOBS:-8}
FORCE=""
if [ "${1:-}" = "--force" ]; then FORCE="--force"; fi
python src/download_data.py
python -m pytest tests -q
python src/audit.py
python src/run_experiments.py --jobs "$JOBS" $FORCE
python src/diagnostics.py --jobs "$JOBS" --reps 200
python src/run_experiments.py --regimes gap --budgets 50 --jobs "$JOBS" $FORCE
python src/irt_comparator.py --jobs "$JOBS" $FORCE
python src/nearest_source.py
python src/analyze.py
python src/fill_checklist.py
python src/build_paper.py
python src/verify_artifacts.py
