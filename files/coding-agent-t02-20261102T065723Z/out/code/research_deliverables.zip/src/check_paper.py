"""Check page budget and text integrity, and render a visual inspection contact sheet."""
import json,re,zipfile,hashlib
from pathlib import Path
import pymupdf
from PIL import Image,ImageDraw

def main():
 doc=pymupdf.open('paper/main.pdf');texts=[p.get_text() for p in doc]
 norm=lambda x:re.sub(r'\s+',' ',x).lower()
 first_statement=next(i for i,t in enumerate(texts) if 'ai use statement' in norm(t))
 assert first_statement<=9,('Main text exceeds official 9-page limit',first_statement)
 full='\n'.join(texts)
 Path('paper/generated/pdf_text.txt').write_text(full)
 assert '??' not in full,'Unresolved reference in PDF'
 assert not re.search(r'\b(?:TODO|TBD)\b',full),'Draft marker remains'
 for phrase in ['Abstract','Introduction','Related work','Experimental method','Results','Discussion','Conclusion','References']:
  assert phrase.lower() in full.lower(),phrase
 assert 'iclr2027_conference' in Path('paper/main.tex').read_text()
 # Full size page-1 preview plus a small contact sheet for all pages.
 out=Path('paper/generated');out.mkdir(exist_ok=True)
 doc[0].get_pixmap(matrix=pymupdf.Matrix(1.5,1.5)).save(out/'page1.png')
 thumbs=[]
 for i,page in enumerate(doc):
  pix=page.get_pixmap(matrix=pymupdf.Matrix(.55,.55));im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);canvas=Image.new('RGB',(im.width,im.height+20),'#ddd');canvas.paste(im,(0,20));ImageDraw.Draw(canvas).text((5,3),f'Page {i+1}',fill='black');thumbs.append(canvas)
 cols=3;tw=max(x.width for x in thumbs);th=max(x.height for x in thumbs);sheet=Image.new('RGB',(cols*tw,((len(thumbs)+cols-1)//cols)*th),'#bbb')
 for i,im in enumerate(thumbs):sheet.paste(im,((i%cols)*tw,(i//cols)*th))
 sheet.save(out/'contact_sheet.png')
 with zipfile.ZipFile('references/iclr-2027-style-files.zip') as archive:
  for name in ['iclr2027_conference.sty','iclr2027_conference.bst']:
   assert Path('paper',name).read_bytes()==archive.read('iclr2027/'+name),('Modified official style',name)
 report={'official_style_verified':True,'pdf':'paper/main.pdf','total_pages':len(doc),'main_text_pages':first_statement,'main_limit':9,'official_template':'ICLR 2027','text_integrity_passed':True,'page_text_lengths':[len(t) for t in texts]}
 (out/'paper_checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
