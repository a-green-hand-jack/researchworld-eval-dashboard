import json, platform, sys
from pathlib import Path
import numpy as np
import pandas as pd
import scipy, sklearn, joblib
from common import ROOT, DATA, NAMES, COMMIT, load, sha256


def main():
    out = ROOT / 'artifacts'; out.mkdir(exist_ok=True)
    audit = []
    for name in NAMES:
        x = load(name)
        unique_rows, counts = np.unique(x, axis=0, return_counts=True)
        audit.append(dict(benchmark=name, models=x.shape[0], items=x.shape[1],
            unique_models=len(unique_rows), duplicate_rows=len(x)-len(unique_rows),
            max_duplicate_group=int(counts.max()), zero_models=int((x.sum(1)==0).sum()),
            one_models=int((x.mean(1)==1).sum()), constant_items=int((x.var(0)==0).sum()),
            duplicate_items=x.shape[1]-len(np.unique(x,axis=1).T),
            mean=float(x.mean()), min_score=float(x.mean(1).min()), max_score=float(x.mean(1).max()),
            sha256=sha256(DATA / (name + '.jbl'))))
    pd.DataFrame(audit).to_csv(out / 'data_audit.csv',index=False)
    versions = {k:v.__version__ for k,v in dict(numpy=np,pandas=pd,scipy=scipy,sklearn=sklearn,joblib=joblib).items()}
    from threadpoolctl import threadpool_info
    versions.update(python=sys.version,platform=platform.platform(),commit=COMMIT,blas=threadpool_info())
    (out/'environment.json').write_text(json.dumps(versions,indent=2))
    print(pd.DataFrame(audit).drop(columns='sha256').to_string(index=False))

if __name__ == '__main__': main()
