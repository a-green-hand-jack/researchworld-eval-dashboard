"""Package the complete deliverables without the local dependency environment or Git internals."""
from pathlib import Path
import hashlib,zipfile,json
roots=['README.md','RESEARCH_LOG.md','requirements-lock.txt','environment.json','Makefile','pilot_manifest.json','configs','src','results','logs','paper','references']
files=[]
for name in roots:
 p=Path(name)
 files.extend([p] if p.is_file() else [q for q in p.rglob('*') if q.is_file() and '__pycache__' not in q.parts])
files=sorted(p for p in set(files) if not (p.parent==Path('logs') and p.name.startswith('package')))
checks='\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p) for p in files)+'\n'
Path('SHA256SUMS').write_text(checks)
with zipfile.ZipFile('research_deliverables.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files+[Path('SHA256SUMS')]:z.write(p,str(p))
print(json.dumps({'archive':'research_deliverables.zip','bytes':Path('research_deliverables.zip').stat().st_size,'files':len(files)+1},indent=2))
