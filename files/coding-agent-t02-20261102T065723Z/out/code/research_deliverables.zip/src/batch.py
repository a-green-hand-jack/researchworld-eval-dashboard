"""Run a JSON list of training argument dictionaries with bounded CPU concurrency."""
import argparse,json,subprocess,sys,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
p=argparse.ArgumentParser();p.add_argument('manifest');p.add_argument('--jobs',type=int,default=4);args=p.parse_args()
runs=json.loads(Path(args.manifest).read_text())
def run(c):
 out=Path(c['out']);log=Path('logs')/(out.stem+'.log')
 if out.exists():return f'SKIP {out}'
 cmd=[sys.executable,'src/train.py']
 for k,v in c.items():cmd.extend(['--'+k,str(v)])
 t=time.time()
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return f'{r.returncode} {out} {time.time()-t:.1f}s'
with ThreadPoolExecutor(args.jobs) as pool:
 for s in pool.map(run,runs):print(s,flush=True)
