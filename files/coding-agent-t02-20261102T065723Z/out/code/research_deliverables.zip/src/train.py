"""Full-batch modular arithmetic experiments; no external training data."""
import argparse, json, time, os, platform
from pathlib import Path
import numpy as np
import torch
from torch import nn

def parser():
 p=argparse.ArgumentParser()
 for k,d in [('width',64),('seed',0),('p',31),('steps',20000),('eval_every',100),('threads',1)]:p.add_argument('--'+k,type=int,default=d)
 for k,d in [('fraction',.3),('lr',.003),('decay',1.),('init_scale',1.)]:p.add_argument('--'+k,type=float,default=d)
 p.add_argument('--freeze_features_at',type=int,default=-1)
 p.add_argument('--init_mode',choices=['default','norm_matched'],default='default')
 p.add_argument('--activation',choices=['relu','square'],default='relu')
 p.add_argument('--task',choices=['add','multiply','random'],default='add')
 p.add_argument('--out',required=True)
 return p

def run(args):
 torch.set_flush_denormal(True)
 torch.set_num_threads(args.threads);torch.set_num_interop_threads(1)
 torch.manual_seed(args.seed)
 p=args.p
 a=torch.arange(p).repeat_interleave(p);b=torch.arange(p).repeat(p)
 x=torch.cat([nn.functional.one_hot(a,p),nn.functional.one_hot(b,p)],1).float()
 y=(a+b)%p if args.task!='multiply' else (a*b)%p
 # Matched splits across widths, disjoint RNG from model initialization.
 gen=torch.Generator().manual_seed(100000+args.seed)
 order=torch.randperm(p*p,generator=gen);n=int(args.fraction*p*p)
 tr,va=order[:n],order[n:]
 if args.task=='random':y=torch.randint(p,(p*p,),generator=torch.Generator().manual_seed(200000+args.seed))
 model=nn.Sequential(nn.Linear(2*p,args.width,bias=False),nn.ReLU() if args.activation=='relu' else Square(),nn.Linear(args.width,p,bias=False))
 with torch.no_grad():
  for v in model.parameters():v.mul_(args.init_scale)
  if args.init_mode=='norm_matched':model[0].weight.mul_((64/args.width)**.5)
 opt=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=args.decay,betas=(.9,.999),eps=1e-8,foreach=False)
 xt,yt=x[tr],y[tr]
 residual=(torch.arange(p)[None,:]-a[:,None]-b[:,None])%p
 rows=[];start=time.perf_counter();start_cpu=time.process_time()
 def evaluate(step):
  with torch.no_grad():
   logits=model(x);pred=logits.argmax(1);centered=logits-logits.mean(1,keepdim=True)
   sums=torch.zeros(p).scatter_add_(0,residual.flatten(),centered.flatten())/(p*p)
   structure=(p*p*sums.square().sum()/centered.square().sum().clamp_min(1e-30)).item()
   rows.append(dict(step=step,train_acc=(pred[tr]==y[tr]).float().mean().item(),test_acc=(pred[va]==y[va]).float().mean().item(),train_loss=nn.functional.cross_entropy(logits[tr],yt).item(),test_loss=nn.functional.cross_entropy(logits[va],y[va]).item(),norm=sum(v.square().sum().item() for v in model.parameters())**.5,structure=structure,elapsed=time.perf_counter()-start))
 evaluate(0)
 frozen=None
 for step in range(1,args.steps+1):
  opt.zero_grad(set_to_none=True);loss=nn.functional.cross_entropy(model(xt),yt);loss.backward();opt.step()
  if frozen is not None:
   with torch.no_grad():
    coef=(model[0].weight*frozen).sum(1,keepdim=True)/frozen.square().sum(1,keepdim=True).clamp_min(1e-30)
    model[0].weight.copy_(coef.clamp_min(0)*frozen)
  if step==args.freeze_features_at:frozen=model[0].weight.detach().clone()
  if step%args.eval_every==0 or step==args.steps:evaluate(step)
 out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
 result={'config':vars(args),'parameters':sum(v.numel() for v in model.parameters()),'train_n':len(tr),'test_n':len(va),'elapsed':time.perf_counter()-start,'cpu_seconds':time.process_time()-start_cpu,'flush_denormal':True,'torch':torch.__version__,'python':platform.python_version(),'history':rows}
 temp=out.with_suffix('.tmp');temp.write_text(json.dumps(result));temp.replace(out)
 torch.save({'state_dict':model.state_dict(),'train_indices':tr,'test_indices':va,'config':vars(args),'frozen_directions':frozen},out.with_suffix('.pt'))
 print(json.dumps({'out':str(out),'seconds':result['elapsed'],'final':rows[-1]}),flush=True)
class Square(nn.Module):
 def forward(self,x):return x*x
if __name__=='__main__':run(parser().parse_args())
