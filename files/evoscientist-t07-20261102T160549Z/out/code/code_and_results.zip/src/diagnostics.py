"""Repeated real-data query masks; not synthetic benchmark results."""
import os
for _v in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']: os.environ[_v]='1'
import argparse,json,time
import numpy as np
from joblib import Parallel,delayed
from threadpoolctl import threadpool_limits
from common import ROOT,NAMES,load,split_rows
from methods import source_strata,designs,full_query_ridge,fixed_difference,stratified_mean,crossfit


def run(name,regime,budget,reps):
    start=time.perf_counter()
    out=ROOT/'artifacts/diagnostics';out.mkdir(parents=True,exist_ok=True)
    with threadpool_limits(limits=1):
        x=load(name);s,t,g=split_rows(x,regime,0)
        _,first=np.unique(g[t],return_index=True)
        chosen=np.random.default_rng(910).permutation(first)[:6]
        t=t[chosen];source=x[s];target=x[t];true=target.mean(1)
        strata=source_strata(source)
        arrays={k:[] for k in ['uniform','item_difference','aipw_pinned','aipw_population','cfd_uniform',
                               'stratified_mean','stratified_difference','scfd','scfd_one','scfd_no_audit','scfd_contaminated']}
        for r in range(reps):
            u,up,ss,sp=designs(x.shape[1],budget,500000+r,strata)
            yu,ys=target[:,u],target[:,ss]
            arrays['uniform'].append(yu.mean(1))
            arrays['item_difference'].append(fixed_difference(source,u,yu))
            pin,pop,_=full_query_ridge(source,u,yu)
            arrays['aipw_pinned'].append(pin);arrays['aipw_population'].append(pop)
            arrays['cfd_uniform'].append(crossfit(source,up,[target[:,p] for p in up],[np.arange(x.shape[1])])[0])
            arrays['stratified_mean'].append(stratified_mean(x.shape[1],ss,ys,strata))
            arrays['stratified_difference'].append(fixed_difference(source,ss,ys,strata))
            cf,one,impute,contam=crossfit(source,sp,[target[:,p] for p in sp],strata)
            for k,v in dict(scfd=cf,scfd_one=one,scfd_no_audit=impute,scfd_contaminated=contam).items():arrays[k].append(v)
        arrays={k:np.array(v) for k,v in arrays.items()}
        np.savez_compressed(out/f'{name}__{regime}__b{budget}.npz',true=true,target_rows=t,**arrays)
        records=[]
        for method,p in arrays.items():
            err=p-true
            mask_bias=err.mean(1)
            mask_mae=abs(err).mean(1)
            individual_bias=err.mean(0)
            records.append(dict(benchmark=name,regime=regime,budget=budget,method=method,
                repetitions=reps,targets=len(t),bias=float(mask_bias.mean()),
                bias_mcse=float(mask_bias.std(ddof=1)/np.sqrt(reps)),
                mae=float(mask_mae.mean()),mae_mcse=float(mask_mae.std(ddof=1)/np.sqrt(reps)),
                mse=float((err**2).mean()),
                variance=float(err.var(0,ddof=0).mean()),bias_squared=float((individual_bias**2).mean()),
                max_abs_individual_bias=float(abs(individual_bias).max()),
                out_of_range=float(np.mean((p<0)|(p>1)))))
        (out/f'{name}__{regime}__b{budget}.json').write_text(json.dumps(dict(records=records,wall_seconds=time.perf_counter()-start,rows=t.tolist()),indent=2))
        print(name,regime,budget,round(time.perf_counter()-start,2),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--reps',type=int,default=200);p.add_argument('--jobs',type=int,default=8)
    args=p.parse_args()
    sizes=sorted([(load(n).shape[1],n) for n in NAMES])
    names=[sizes[-1][1],sizes[len(sizes)//2][1]]
    tasks=[(n,r,b) for n in names for r in ['iid','frontier'] for b in [10,100]]
    start=time.perf_counter()
    Parallel(n_jobs=args.jobs)(delayed(run)(n,r,b,args.reps) for n,r,b in tasks)
    (ROOT/'artifacts/diagnostic_summary.json').write_text(json.dumps(dict(names=names,reps=args.reps,wall_seconds=time.perf_counter()-start),indent=2))

if __name__=='__main__':main()
