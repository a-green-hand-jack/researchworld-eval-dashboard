"""Shared data provenance and split construction; never used for target inference."""
from pathlib import Path
import hashlib
import joblib
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'vendor/benchmark-prediction/data/scores'
NAMES = 'arc_challenge bbh gpqa ifeval mmlu_pro musr openllm_math commonsense gsm legalbench math med_qa mmlu'.split()
COMMIT = '55faff496947789f94e6b5908c77cbc3e84f81ad'
BUDGETS = [10, 25, 50, 100]


def load(name):
    x = np.asarray(joblib.load(DATA / f'{name}.jbl'), dtype=np.float64)
    assert x.ndim == 2 and np.isfinite(x).all()
    assert np.isin(x, [0, 1]).all()
    return x


def split_rows(x, regime, seed, fraction=.7):
    # Full responses are permitted ONLY here for group integrity/oracle stress.
    u, inv = np.unique(x, axis=0, return_inverse=True)
    rng = np.random.default_rng(1000 + seed)
    order = rng.permutation(len(u))
    if regime in ['frontier', 'gap']:
        order = order[np.argsort(u[order].mean(1), kind='stable')]
        means = u[order].mean(1)
        boundaries = np.flatnonzero(np.diff(means) > 1e-14) + 1
        assert len(boundaries), 'frontier uninformative: all scores tie'
        cut = boundaries[np.argmin(abs(boundaries - fraction * len(u)))]
        src_groups = order[:cut]
        if regime == 'gap':
            src_cut = boundaries[np.argmin(abs(boundaries - .5 * len(u)))]
            src_groups = order[:src_cut]
        tgt_groups = order[cut:]
    else:
        cut = int(np.floor(fraction * len(u)))
        src_groups, tgt_groups = order[:cut], order[cut:]
    src = np.flatnonzero(np.isin(inv, src_groups))
    tgt = np.flatnonzero(np.isin(inv, tgt_groups))
    assert not set(inv[src]) & set(inv[tgt])
    return src, tgt, inv


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
