# Original research request

User supplied TASK.md / starter_literature.md / data.md / resources.md / deliverable.md in conversation. This intake preserves their operative requirements.

研究问题：利用已有源模型在基准每题的二值结果，选择远小于全基准的题目子集，并由新模型的子集结果预测完整得分及模型排序。自行梳理已有方法、提出实现方案、公平对照与消融，真实运行，报告 MAE/RMSE、Spearman/Kendall 和不确定性；允许负面结果。

数据：仅使用公开 binary model-by-item matrices。https://github.com/socialfoundations/benchmark-prediction 固定 commit 55faff496947789f94e6b5908c77cbc3e84f81ad，data/scores 下 arc_challenge, bbh, gpqa, ifeval, mmlu_pro, musr, openllm_math, commonsense, gsm, legalbench, math, med_qa, mmlu 的 .jbl；源/目标模型行划分必须独立。上游 Open LLM Leaderboard/HELM，仓库 MIT。

资源：CPU only，最多一周；约 1 GB 存储为建议。不得付费 API 或重跑 LLM。

交付（全部在 workspace root /work 下）：完整研究论文 PDF + LaTeX；选择 ICML/ICLR/NeurIPS 最新一届官方模板，遵守正文页数及 checklist；包含摘要、引言、相关工作、方法、实验、讨论/局限、真实参考文献。代码与复现说明：环境版本、固定数据版本/获取、随机种子、命令、实测/预计运行时间、每图表对应脚本。每个数字来自实际实验，不得伪造或将示意数据当实测；披露失败、未完成实验。

独立研究限制：不得检索、推测、访问题目未指明的既有目标论文及其镜像、摘要页、评论/复现/引用页面。允许 starter_literature 中文献及指定代码/数据仓库。安全策略：不开放检索，不 citation traversal；只直连以下白名单 arXiv ID 的原论文及指定固定仓库、官方模板页面。如偶然接触禁读内容，立即停止并记录路径及读到的范围。

允许起步文献 arXiv IDs：2309.08638, 2402.14992, 2407.12844, 2409.03563, 2410.05952, 2506.07673, 2601.13885, 2406.01574, 2412.06745, 2211.09110；另允许 Open LLM Leaderboard v2 官方。

用户明确要求无人值守，自行决策直到交付物存在。不委派 code-agent（因为其代码模式选择需人类回答）；直接实现代码，可委派文献阅读、协议反思及论文自审。
