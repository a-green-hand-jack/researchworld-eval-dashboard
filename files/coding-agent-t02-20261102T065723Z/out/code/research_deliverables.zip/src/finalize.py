"""Wait for all configured artifacts, then generate, audit, compile, and check the paper."""
import json,time,subprocess,sys,datetime
from pathlib import Path
configs=['main','secondary','features','replication']
runs=[c for name in configs for c in json.loads(Path(f'configs/{name}.json').read_text())]
while not all(Path(c['out']).exists() and Path(c['out']).with_suffix('.pt').exists() for c in runs):time.sleep(3)
commands=[([sys.executable,'src/construct_circuit.py'],None),([sys.executable,'src/analyze.py'],None),([sys.executable,'src/write_results.py'],None),([sys.executable,'src/audit.py'],None),(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],'paper'),(['bibtex','main'],'paper'),(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],'paper'),(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],'paper'),([sys.executable,'src/check_paper.py'],None)]
for i,(cmd,cwd) in enumerate(commands):
 print('START',i,' '.join(cmd),flush=True)
 with Path(f'logs/finalize_{i}.log').open('w') as f:res=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',i,'status',res.returncode,flush=True)
 if res.returncode:raise SystemExit(res.returncode)
Path('paper/generated/completion.json').write_text(json.dumps({'runs':len(runs),'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pipeline_passed':True},indent=2))
