"""Write manuscript empirical prose using only the accompanying measured summaries."""
import json
from pathlib import Path
import numpy as np
from analyze import ci_mean,SEEDS,H,event,record
P=Path('paper/generated');s=json.loads((P/'summary.json').read_text())
def n(x):return f'{x:,.0f}'
def ci(x,digits=0):
 m,l,h=x
 if digits:return f'{m:.{digits}f} [{l:.{digits}f}, {h:.{digits}f}]'
 return f'{n(m)} [{n(l)}, {n(h)}]'
def g(d,w):return s[f'main_d{d}_w{w}']
ref64,ref256=g(1,64),g(1,256)
a=ref64['success'];b=ref256['success'];diff=s['primary']['waiting_difference_256_minus64']
text=[]
text.append(r'Figure~\ref{fig:curves} and Table~\ref{tab:main} distinguish fitting from generalization. At decay 1, sustained training interpolation occurs in '+', '.join(f'{g(1,w)["interpolate"]}/5 runs at width {w}' for w in [16,32,64,128,256])+'. The corresponding generalization counts are '+', '.join(str(g(1,w)['success'])+'/5' for w in [16,32,64,128,256])+'. These observations demonstrate why a single grokking count would conflate insufficient fitting, delayed success, and unresolved generalization.')
text.append('For the primary paired comparison, widths 64 and 256 have mean restricted generalization waiting times of '+n(ref64['waiting'][0])+' and '+n(ref256['waiting'][0])+' updates, respectively. The width-256 minus width-64 difference is '+ci(diff)+r' updates (95\% paired seed bootstrap interval). Restricted training-event waiting times are '+n(ref64['train_waiting'][0])+' and '+n(ref256['train_waiting'][0])+'; their paired difference is '+ci(s['primary']['train_difference'])+' updates. The individual paired outcomes are in the appendix.')
if b>a and diff[2]<0:
 text.append('Widening therefore changes the slow generalization process much more than the early fitting process at the measured horizon. This contradicts the strong width-independent decay-clock explanation. The narrow model\'s censored time is a lower bound, so the evidence concerns finite-horizon outcomes and restricted waiting times rather than an estimated eventual event time. It does not establish permanent failure at width 64.')
else:
 text.append('The paired results constrain the strong width-independent clock hypothesis at the measured horizon, but must be interpreted together with the observed censoring rather than as unrestricted event-time estimates.')
text.append(f'The original five-pair exact two-sided sign test gives $p={s["primary"]["sign_test_p"]:.4f}$. Its coarse resolution is a reason not to interpret the bootstrap interval as decisive population-level significance. An independently planned ten-pair replication on seeds 20--29 gives a restricted waiting-time difference of {ci(s["replication"]["waiting_difference_256_minus64"])} updates, with {s["replication_w64"]["success"]}/10 versus {s["replication_w256"]["success"]}/10 events and exact sign-test $p={s["replication"]["sign_test_p"]:.4f}$. The replication was designed after seeing the main-grid result and is reported as a separate cohort.')
text.append('Across the full no-decay arm, '+str(sum(g(0,w)['success'] for w in [16,32,64,128,256]))+' of 25 runs reach the generalization criterion. At positive decay, event counts depend on width and decay jointly (Figure~\ref{fig:grid}). In particular, decay 3 gives '+', '.join(f'{g(3,w)["success"]}/5 at width {w}' for w in [16,32,64,128,256])+'. This comparison concerns the same step budget and fixed AdamW learning rate; it does not assert that zero decay precludes grokking under other parameterizations or longer training.')
# Clock comparison: use all seeds and expose censoring; only test a ratio if fully observed.
clock={}
for d in [.3,1,3]:
 times=[]
 for seed in SEEDS:
  r,_=record(f'results/main_d{d}_w256_s{seed}.json');times.append(r['gen_time'])
 clock[d]=times
parts=[]
for d,times in clock.items():
 obs=[.003*d*t for t in times if t is not None]
 val='no confirmed events' if not obs else f'observed scaled times {min(obs):.2f}--{max(obs):.2f}'
 parts.append(f'$\\lambda={d:g}$: {len(obs)}/5 events, {val}')
text.append('The width-256 decay-clock check reports $\\eta\\lambda T_{\\mathrm{gen}}$, not a rescaled censored time: '+'; '.join(parts)+'.')
if all(t is not None for ts in clock.values() for t in ts):
 means=[np.mean([.003*d*t for t in ts]) for d,ts in clock.items()];ratio=max(means)/min(means)
 text.append(f'The ratio of largest to smallest mean scaled event time is {ratio:.2f}, '+('exceeding' if ratio>2 else 'within')+' the prechosen factor-two descriptive tolerance. This is a diagnostic of approximate collapse, not a population equivalence test.')
else:
 text.append('Because at least one decay has censored seeds, an unrestricted comparison of mean scaled event times is not identified. We do not replace those missing events with the deadline to claim a clock collapse.')
x,y=s['delay_metrics']['128'],s['delay_metrics']['256']
text.append(f'Among the fully observed reference widths 128 and 256, mean absolute post-fit delays are {n(x["absolute"][0])} and {n(y["absolute"][0])} steps, while mean ratios $T_{{\\mathrm{{gen}}}}/T_{{\\mathrm{{fit}}}}$ are {x["ratio"][0]:.1f} and {y["ratio"][0]:.1f}. Thus these operational metrics have different width trends. The ratio is especially sensitive to the 100-step evaluation grid and quantization of the short fitting time; it is not evidence of an underlying continuous-time ratio law.')
text.append('A three-checkpoint event need not remain above threshold. For decay 3 and width 256, '+str(sum(v is not None for v in s['durability']['d3_w256']))+'/5 runs satisfy the additional criterion of staying above 95\\% at every remaining observed checkpoint, whereas the original event count is '+str(g(3,256)['success'])+'/5. At decay 1, the corresponding durable-event count at width 256 is '+str(sum(v is not None for v in s['durability']['d1_w256']))+'/5. These retrospective sensitivity results do not change the prespecified primary endpoint.')
(P/'results_text.tex').write_text('\n\n'.join(text)+'\n')

text=[]
for name,label in [('norm','Expected initial norm matching'),('square','Replacing ReLU with a square activation'),('p47','Increasing the prime to 47'),('dense','Increasing the training fraction to 70\\%'),('multiply','Changing addition to multiplication'),('random','Replacing arithmetic labels with independent random labels')]:
 x,y=s[f'{name}_w64'],s[f'{name}_w256']
 text.append(f'{label} gives {x["success"]}/5 versus {y["success"]}/5 generalization events at widths 64 and 256, respectively; mean final accuracies are {x["final_acc"][0]:.3f} and {y["final_acc"][0]:.3f}.')
text.append('Changing the modulus fixes the training fraction, not the number of examples: prime 47 uses 1,104 training pairs rather than 480, and changes both the output dimension and the parameter count at fixed width. Cross-modulus waiting times are therefore not an isolated measure of arithmetic difficulty.')
text.append('These are scope and intervention tests, with uncertainty reported in Table~\\ref{tab:secondary}. In particular, norm matching changes the norm trend while retaining the width intervention, but also changes the initial logit scale. Random labels test a distinct target distribution; failure to generalize there is expected and is not additional evidence for a specific arithmetic circuit. Multiplication includes zero operands and does not have the same additive translation symmetry as addition.')
# Structure association measured on actual final checkpoints.
x,y=ref64['structure'][0],ref256['structure'][0]
text.append(f'At the reference setting, mean final addition-symmetry energy is {x:.3f} at width 64 and {y:.3f} at width 256 (Figure~\\ref{{fig:diagnostics}}). This diagnostic is consistent with a change in output structure when it accompanies better accuracy, but its definition already uses the task symmetry and it cannot independently establish why a feature formed.')
for freeze in [1000,10000]:
 x,y=s[f'freeze{freeze}_w64'],s[f'freeze{freeze}_w256']
 text.append(f'The exploratory direction-freezing intervention after {freeze:,} steps gives {x["success"]}/5 versus {y["success"]}/5 generalization events at widths 64 and 256. Mean final training accuracies are {x["final_train_acc"][0]:.3f} and {y["final_train_acc"][0]:.3f}, and final held-out accuracies are {x["final_acc"][0]:.3f} and {y["final_acc"][0]:.3f}, respectively. The width-256 trajectories are shown in Appendix Figure~\\ref{{fig:freezing}}.')
text.append('A step advantage need not be an advantage at a common compute proxy. For a budget of $64\\times30{,}000$ hidden-unit updates, the actually evaluated checkpoints are '+', '.join(f'width {w} at {s["compute_proxy"][str(w)]["step"]:,} steps' for w in [64,128,256])+'. Their mean held-out accuracies are '+', '.join(f'{s["compute_proxy"][str(w)]["accuracy"][0]:.3f}' for w in [64,128,256])+', respectively. This proxy reflects the width-dependent dense-layer arithmetic at fixed data size; it excludes fixed framework and optimizer overhead and is not measured wall-clock equality. Full intervals and per-seed values are supplied in the appendix.')
(P/'controls_text.tex').write_text('\n\n'.join(text)+'\n')

norm_y=s['norm_w256']['success'];zero=sum(g(0,w)['success'] for w in [16,32,64,128,256])
text=[]
if diff[2]<0 and b>a:
 text.append('The measured width contrast rejects the strong claim that width mainly accelerates memorization while leaving the slow process unchanged. The change occurs after both widths can fit the same training size. It is compatible with a feature-discovery bottleneck: added width changes optimization access to useful structured solutions under regularization. However, no internal circuit was isolated, and alternatives involving conditioning, redundancy, and Adam\'s effective updates remain possible.')
else:
 text.append('The primary contrast does not by itself establish a universal direction of width dependence. The measured map should be read as a conditional relation for the studied optimizer, horizon, and data coverage.')
if norm_y>a:
 text.append('Persistence of the contrast under expected initial norm matching argues against initial total norm alone as a sufficient explanation. It does not refute norm-based theories that depend on the entire optimization path or circuit efficiency.')
else:
 text.append('The initialization control changes the contrast, warning that raw width should not be interpreted independently of parameterization and initial function scale.')
early,late=s['freeze1000_w256'],s['freeze10000_w256']
if early['success']==0 and early['final_train_acc'][0]>.99 and ref256['success']==5:
 text.append(f'The direction intervention supplies additional evidence: fixing hidden directions at step 1,000 preserves final training interpolation yet removes all five reference generalization events. Readout learning, individual feature magnitudes, and weight decay remain active, so their constrained continuation is insufficient from that state under these updates. Fixing directions only at step 10,000 retains {late["success"]}/5 events, showing that continued direction changes are not required after that point in every observed run. The intervention still changes the optimization path, and identifies neither a unique circuit nor a general necessity theorem.')
text.append('The operational distinction between occurrence and latency matters. A configuration with no confirmed event cannot be assigned a small delay; a configuration with both rapid fitting and later generalization can exhibit a large ratio even when its absolute waiting time decreases. The success map, restricted waiting time, and delayed-event counts therefore answer complementary questions. Finite-horizon success is an experimentally useful setting-selection criterion, but it is not a universal phase boundary.')
(P/'discussion_text.tex').write_text('\n\n'.join(text)+'\n')
if diff[2]<0 and b>a:
 conclusion='In this finite-horizon modular study, increasing width can enable delayed generalization and markedly accelerate the slow process after training interpolation is already possible. This rejects our strong width-independent decay-clock conjecture. The width relation changes with regularization and the task controls, and initial expected norm alone is insufficient wherever the matched-norm contrast persists. The supported explanation is conditional access to structured solutions under the complete training setup, with the particular circuit mechanism and eventual outcomes beyond the horizon still unresolved.'
else:
 conclusion='The experiments delimit a conditional relation between width and delayed generalization, rather than a universal parameter-count rule. Censoring-aware comparisons and interventions on regularization, initialization, and task are essential to distinguish a delayed event from failure to observe one. Eventual behavior outside the horizon and a unique feature-level mechanism remain unresolved.'
(P/'conclusion_text.tex').write_text(conclusion+'\n')

# Detailed appendix makes small-n paired uncertainty inspectable.
lines=[r'\subsection{Individual primary outcomes}',r'\begin{center}',r'\begin{tabular}{rrrrrr}',r'\toprule',r'Seed & $T_{\rm fit}^{64}$ & $T_{\rm gen}^{64}$ & $T_{\rm fit}^{256}$ & $T_{\rm gen}^{256}$ & $\tau^{256}-\tau^{64}$ \\',r'\midrule']
for seed in SEEDS:
 r,_=record(f'results/main_d1_w64_s{seed}.json');q,_=record(f'results/main_d1_w256_s{seed}.json')
 ev=lambda z:r'$>29{,}800$' if z is None else n(z)
 lines.append(f'{seed} & {ev(r["train_time"])} & {ev(r["gen_time"])} & {ev(q["train_time"])} & {ev(q["gen_time"])} & {n(q["wait"]-r["wait"])} '+r'\\')
lines += [r'\bottomrule',r'\end{tabular}',r'\end{center}',r'\subsection{Threshold sensitivity}',r'All entries give sustained held-out event times in seed order 10--14; a dash means not confirmed by $H=29{,}800$.']
for threshold,groups in s['threshold_sensitivity'].items():
 for width,times in groups.items():lines.append(f'At threshold {float(threshold):.0%} and width {width}: '+', '.join('--' if t is None else n(t) for t in times)+'.')
lines=[x.replace('%','\\%') if x.startswith('At threshold') else x for x in lines]
lines += [r'\subsection{Matched arithmetic budget proxy}']
for width,vals in s['compute_proxy'].items():lines.append(f'Width {width}, checkpoint {n(vals["step"])}: mean held-out accuracy {ci(vals["accuracy"],3)} (95\\% seed bootstrap interval); individual values '+', '.join(f'{x:.3f}' for x in vals['per_seed'])+'.')
lines += [r'\begin{figure}[h]',r'\centering\includegraphics[width=\linewidth]{figures/feature_freezing.pdf}',r'\caption{Exploratory feature-direction freezing at width 256. Curves are medians with full seed ranges. The first 1,000 or 10,000 steps exactly match the unconstrained reference; subsequent optimization retains the fixed ReLU feature directions, while magnitudes and readout weights remain trainable.}',r'\label{fig:freezing}',r'\end{figure}']
lines += [r'\subsection{Event proportions and computational cost}',r'Exact Clopper--Pearson intervals for every cell are in \texttt{generated/summary.json}; these intervals describe seed-level event probabilities under the complete seed-and-split procedure. Five seeds give limited resolution and no rare-event guarantee.',f'The {s["run_count"]} distinct formal runs consume {s["cpu_seconds"]/3600:.2f} measured process CPU hours in training/evaluation. Interpreter startup, pilots, the interrupted launcher, analysis, and compilation are excluded from that total; individual measured wall times are in the raw JSON and per-run CSV.']
(P/'appendix_text.tex').write_text('\n\n'.join(lines)+'\n')
print('Wrote all empirical manuscript prose from summary.json')
