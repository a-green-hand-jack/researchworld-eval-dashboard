"""Point-estimate multidimensional IRT comparator; not exact Bayesian gpIRT."""
import os
for _v in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[_v]='1'
import argparse,json,time
import numpy as np
from scipy.special import expit,logit
from scipy.optimize import minimize
from joblib import Parallel,delayed
from threadpoolctl import threadpool_limits
from common import ROOT,NAMES,load
from run_experiments import metrics


def fit_mirt(source,rank=5,maxiter=1000):
    m,n=source.shape
    # Source-only spectral initialization: source covariance avoids item² storage.
    centered=source-source.mean(0)
    evals,evec=np.linalg.eigh(centered@centered.T/n)
    theta=evec[:,-rank:]*np.sqrt(m)
    alpha=(centered.T@theta)/(m+1)
    beta=-logit((source.sum(0)+.5)/(m+1))
    def pack(t,a,b):return np.r_[t.ravel(),a.ravel(),b]
    def unpack(v):return v[:m*rank].reshape(m,rank),v[m*rank:(m+n)*rank].reshape(n,rank),v[(m+n)*rank:]
    def objective(v):
        t,a,b=unpack(v)
        z=t@a.T-b
        r=expit(z)-source
        loss=np.logaddexp(0,z).sum()-(source*z).sum()+.5*(t*t).sum()+.5*(a*a).sum()+(b*b).sum()/18
        grad=pack(r@a+t,r.T@t+a,-r.sum(0)+b/9)
        return loss,grad
    start=time.perf_counter()
    result=minimize(objective,pack(theta,alpha,beta),jac=True,method='L-BFGS-B',
                    options={'maxiter':maxiter,'ftol':1e-9,'gtol':1e-4,'maxcor':10})
    t,a,b=unpack(result.x)
    meta=dict(success=bool(result.success),message=str(result.message),iterations=int(result.nit),
              objective=float(result.fun),gradient_inf=float(abs(result.jac).max()),seconds=time.perf_counter()-start)
    return a,b,meta


def predict_mirt(alpha,beta,ids,y):
    # Strictly convex target problem with standard normal theta prior.
    rank=alpha.shape[1];t=np.zeros((len(y),rank));aq=alpha[ids]
    for _ in range(60):
        p=expit(t@aq.T-beta[ids]);r=p-y
        grad=r@aq+t
        hess=np.einsum('ti,ij,ik->tjk',p*(1-p),aq,aq)+np.eye(rank)
        step=np.linalg.solve(hess,grad[...,None])[...,0]
        # Limit rare Newton overshoots on endpoint/near-separable rows.
        scale=np.minimum(1,2/np.maximum(np.linalg.norm(step,axis=1),1e-12))
        t-=step*scale[:,None]
        if np.max(abs(step))<1e-7:break
    pred=expit(t@alpha.T-beta)
    return (pred.sum(1)-pred[:,ids].sum(1)+y.sum(1))/len(beta)


def run(name,regime,seed,force=False):
    out=ROOT/'artifacts/irt_runs';out.mkdir(parents=True,exist_ok=True)
    stem=f'{name}__{regime}__s{seed}';path=out/(stem+'.json')
    if path.exists() and not force:return
    start=time.perf_counter()
    with threadpool_limits(limits=1):
        x=load(name);saved=np.load(ROOT/'artifacts/runs'/(stem+'.npz'))
        src=saved['source_rows'];tgt=saved['target_rows'];source=x[src]
        unique,inv=np.unique(source,axis=0,return_inverse=True)
        order=np.random.default_rng(6021+seed).permutation(len(unique))
        cut=max(5,int(.8*len(unique)))
        inner_src=np.flatnonzero(np.isin(inv,order[:cut]));inner_val=np.flatnonzero(np.isin(inv,order[cut:]))
        assert len(inner_val)>0
        ai,bi,mi=fit_mirt(source[inner_src])
        a,b,mf=fit_mirt(source)
        arrays={};records=[];lambdas={}
        _,vrep=np.unique(inv[inner_val],return_index=True)
        variance=np.mean(source[inner_src].mean(1)*(1-source[inner_src].mean(1)))
        for budget in [10,25,50,100]:
            ids=saved[f'u_{budget}']
            vp=predict_mirt(ai,bi,ids,source[inner_val][:,ids])
            err=vp[vrep]-source[inner_val][vrep].mean(1)
            bias2=np.mean(abs(err))**2
            lam=float(bias2/(variance/budget+bias2))
            lambdas[budget]=lam
            p=predict_mirt(a,b,ids,x[tgt][:,ids])
            mix=lam*x[tgt][:,ids].mean(1)+(1-lam)*p
            for method,value in [('mirt_5',p),('mirt_mix',mix)]:
                arrays[f'{method}__b{budget}']=value
                for weighting,idx in [('group',saved['rep']),('row',np.arange(len(tgt)))]:
                    records.append(dict(benchmark=name,regime=regime,seed=seed,budget=budget,method=method,weighting=weighting,
                                        **metrics(saved['true'][idx],value[idx])))
        np.savez_compressed(out/(stem+'.npz'),**arrays)
        data=dict(records=records,source_fit=mf,inner_fit=mi,lambdas=lambdas,wall_seconds=time.perf_counter()-start)
        path.write_text(json.dumps(data,indent=2,allow_nan=False))
        print(stem,round(data['wall_seconds'],2),'seconds','convergence',mi['success'],mf['success'],flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--names',nargs='+',default=NAMES);p.add_argument('--jobs',type=int,default=8)
    p.add_argument('--seeds',nargs='+',type=int,default=list(range(5)));p.add_argument('--force',action='store_true');a=p.parse_args()
    start=time.perf_counter()
    Parallel(n_jobs=a.jobs)(delayed(run)(n,r,s,a.force) for n in a.names for r in ['iid','frontier'] for s in a.seeds)
    (ROOT/'artifacts/irt_summary.json').write_text(json.dumps(dict(wall_seconds=time.perf_counter()-start,args=vars(a)),indent=2))

if __name__=='__main__':main()
