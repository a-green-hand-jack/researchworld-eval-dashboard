"""All manuscript quantitative tables/figures/macros from saved run artifacts."""
import json,itertools
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import ROOT,NAMES,BUDGETS

LABELS={'uniform':'Uniform','uniform_2b':'Uniform ($2b$; extra cost)',
'item_difference':'Item difference','ridge_score':'Score ridge','aipw_pinned':'AIPW--pinned',
'aipw_population':'AIPW--population','rasch_1pl':'Rasch 1PL','binary_anchors':'Binary anchors',
'anchor_rasch':'Anchors + Rasch','cfd_uniform':'Uniform CFD','stratified_mean':'Stratified mean',
'stratified_difference':'Stratified difference','stratified_ridge':'Stratified score ridge',
'scfd':'SCFD','scfd_one':'SCFD: one direction','scfd_no_audit':'SCFD: no audit',
'scfd_contaminated':'SCFD: contaminated','mirt_5':'MIRT--5 (added)','mirt_mix':'MIRT mixture (added)',
'nearest_source':'Nearest source (added)'}
MAIN=['uniform','stratified_mean','item_difference','stratified_difference','ridge_score',
      'stratified_ridge','aipw_pinned','aipw_population','rasch_1pl','binary_anchors','cfd_uniform','scfd']
COLORS={'uniform':'#555555','stratified_mean':'#009E73','ridge_score':'#E69F00',
        'aipw_population':'#0072B2','scfd':'#CC79A7','item_difference':'#56B4E9'}


def bootstrap(v,seed=701,reps=10000):
    rng=np.random.default_rng(seed)
    z=v[rng.integers(0,len(v),(reps,len(v)))].mean(1)
    return np.quantile(z,[.025,.975])


def write_tab(path,headers,rows,align=None):
    if align is None:align='l'+'r'*(len(headers)-1)
    text='\\begin{tabular}{'+align+'}\n\\toprule\n'+' & '.join(headers)+' \\\\\n\\midrule\n'
    text+='\n'.join(' & '.join(map(str,row))+' \\\\' for row in rows)
    text+='\n\\bottomrule\n\\end{tabular}\n'
    path.write_text(text)


def savefig(fig,base):
    fig.savefig(str(base)+'.pdf',bbox_inches='tight')
    fig.savefig(str(base)+'.png',dpi=300,bbox_inches='tight')
    plt.close(fig)


def main():
    out=ROOT/'artifacts/analysis';out.mkdir(parents=True,exist_ok=True)
    paper=ROOT/'paper';tables=paper/'tables';figs=paper/'figures'
    tables.mkdir(exist_ok=True);figs.mkdir(exist_ok=True)
    all_records=[];runs=[]
    for p in sorted((ROOT/'artifacts/runs').glob('*.json')):
        d=json.loads(p.read_text());all_records+=d['records'];runs.append(d)
    irt_files=sorted((ROOT/'artifacts/irt_runs').glob('*.json'))
    irt_complete=len(irt_files)==130
    irt_meta=[]
    if irt_complete:
        for p in irt_files:
            d=json.loads(p.read_text());all_records+=d['records'];irt_meta.append(d)
        MAIN.extend(['mirt_5','mirt_mix'])
    nearest_files=sorted((ROOT/'artifacts/nearest_runs').glob('*.json'))
    if len(nearest_files)==130:
        for p in nearest_files:all_records+=json.loads(p.read_text())['records']
        MAIN.append('nearest_source')
    df=pd.DataFrame(all_records)
    df.to_csv(out/'all_metrics.csv',index=False)
    group=df[df.weighting=='group']
    core=group[group.regime.isin(['iid','frontier'])&~group.method.isin(['mirt_5','mirt_mix','nearest_source'])]
    assert len(core)==13*2*5*4*17,(len(core),core.method.unique())
    summary=[]
    bybench=group.groupby(['regime','budget','method','benchmark'],as_index=False)[['mae','mse','bias','rho','tau','pair_agreement','p95']].mean()
    bybench.to_csv(out/'per_benchmark.csv',index=False)
    for (regime,budget,method),d in bybench.groupby(['regime','budget','method']):
        ci=bootstrap(d.mae.to_numpy())
        seeds=group[(group.regime==regime)&(group.budget==budget)&(group.method==method)].groupby('seed').mae.mean()
        summary.append(dict(regime=regime,budget=int(budget),method=method,mae=float(d.mae.mean()),
            ci_lo=float(ci[0]),ci_hi=float(ci[1]),rmse=float(np.sqrt(d.mse.mean())),
            bias=float(d.bias.mean()),rho=float(d.rho.mean()),tau=float(d.tau.mean()),
            pair_agreement=float(d.pair_agreement.mean()),p95=float(d.p95.mean()),
            seed_sd=float(seeds.std(ddof=1)),valid_rho=int(d.rho.notna().sum())))
    summ=pd.DataFrame(summary);summ.to_csv(out/'macro_summary.csv',index=False)
    def row(regime,method,b=50):return summ[(summ.regime==regime)&(summ.budget==b)&(summ.method==method)].iloc[0]
    def cival(d):return f'{100*d.mae:.2f} [{100*d.ci_lo:.2f}, {100*d.ci_hi:.2f}]'
    rows=[]
    for method in MAIN:
        a,b=row('iid',method),row('frontier',method)
        rows.append([LABELS[method],cival(a),cival(b),f'{100*a.rmse:.2f}',f'{100*b.rmse:.2f}',f'{a.rho:.3f}',f'{b.rho:.3f}'])
    write_tab(tables/'main.tex',['Method','IID MAE [CI]','Frontier MAE [CI]','IID RMSE','Front. RMSE',r'$\rho$ IID',r'$\rho$ Front.'],rows)
    rows=[]
    for method in ['uniform','stratified_mean','stratified_difference','scfd_no_audit','scfd_contaminated','scfd_one','cfd_uniform','scfd']:
        a,b=row('iid',method),row('frontier',method)
        rows.append([LABELS[method],f'{100*a.mae:.2f}',f'{100*b.mae:.2f}',f'{100*b.bias:+.2f}',f'{100*b.rmse:.2f}'])
    write_tab(tables/'ablation.tex',['Method','IID MAE','Front. MAE','Front. bias','Front. RMSE'],rows)
    rows=[]
    for name in NAMES:
        z=bybench[(bybench.benchmark==name)&(bybench.regime=='frontier')&(bybench.budget==50)]
        rows.append([name.replace('_',r'\_')]+[f'{100*z[z.method==m].mae.iloc[0]:.2f}' for m in ['uniform','stratified_mean','ridge_score','aipw_population','scfd']])
    write_tab(tables/'per_benchmark_frontier.tex',['Bank','Uniform','Strat. mean','Score ridge','AIPW--pop.','SCFD'],rows)
    # Primary paired differences across benchmark units, seeds averaged first.
    effects=[]
    for regime in ['iid','frontier']:
        pivot=bybench[(bybench.regime==regime)&(bybench.budget==50)].pivot(index='benchmark',columns='method',values='mae')
        for base in ['uniform','stratified_mean']:
            diff=(pivot.scfd-pivot[base]).to_numpy()
            lo,hi=bootstrap(diff)
            signs=np.array(list(itertools.product([-1,1],repeat=len(diff))))
            stat=abs(diff.mean());pval=float(np.mean(abs((signs*diff).mean(1))>=stat-1e-14))
            seedvals=group[(group.regime==regime)&(group.budget==50)&group.method.isin(['scfd',base])].groupby(['seed','method']).mae.mean().unstack()
            effects.append(dict(regime=regime,baseline=base,delta=float(diff.mean()),lo=float(lo),hi=float(hi),
                 better_banks=int((diff<0).sum()),p_signflip=pval,seed_deltas=(seedvals.scfd-seedvals[base]).tolist()))
    order=np.argsort([e['p_signflip'] for e in effects]);maximum=0
    for rank,j in enumerate(order):
        maximum=max(maximum,min(1,(len(effects)-rank)*effects[j]['p_signflip']))
        effects[j]['p_holm']=maximum
    (out/'primary_effects.json').write_text(json.dumps(effects,indent=2))
    write_tab(tables/'effects.tex',['Regime','Comparator',r'$\Delta$ MAE [95\% CI]',r'Banks better','Holm $p$'],
        [[e['regime'],LABELS[e['baseline']],f"{100*e['delta']:+.2f} [{100*e['lo']:+.2f}, {100*e['hi']:+.2f}]",f"{e['better_banks']}/13",f"{e['p_holm']:.4f}"] for e in effects])
    # Complete secondary endpoints, all methods including higher-budget reference.
    for regime in ['iid','frontier']:
        rows=[]
        for m in LABELS:
            if m not in summ.method.values:continue
            r=row(regime,m)
            rows.append([LABELS[m],f'{100*r.mae:.2f}',f'{100*r.rmse:.2f}',f'{100*r.bias:+.2f}',
                         f'{r.rho:.3f}',f'{r.tau:.3f}',f'{r.pair_agreement:.3f}',f'{100*r.seed_sd:.2f}'])
        write_tab(tables/f'all_{regime}.tex',['Method','MAE','RMSE','Bias',r'$\rho$',r'$\tau_b$','Pairs','Seed SD'],rows)
    # Full audit table and seed-0 split descriptions.
    audit=pd.read_csv(ROOT/'artifacts/data_audit.csv')
    rows=[]
    for _,a in audit.iterrows():
        rr=next(r for r in runs if r['benchmark']==a.benchmark and r['regime']=='frontier' and r['seed']==0)
        rows.append([a.benchmark.replace('_',r'\_'),int(a.models),int(a['items']),int(a.unique_models),int(a.zero_models),int(a.constant_items),rr['source_groups'],rr['target_groups']])
    write_tab(tables/'data.tex',['Bank','Rows','Items','Unique','Zero rows','Const. items','Src. groups','Tgt. groups'],rows)
    # Row weighting and optional stronger gap stress.
    row_summary=df[df.weighting=='row'].groupby(['regime','budget','method'])[['mae','mse','rho']].mean().reset_index()
    row_summary.to_csv(out/'row_weighted_summary.csv',index=False)
    if 'gap' in summ.regime.values:
        rows=[]
        for m in MAIN:
            if m.startswith('mirt') or m=='nearest_source':continue
            r=row('gap',m)
            rows.append([LABELS[m],cival(r),f'{100*r.rmse:.2f}',f'{100*r.bias:+.2f}',f'{r.rho:.3f}'])
        write_tab(tables/'gap.tex',['Method','Gap MAE [CI]','RMSE','Bias',r'$\rho$'],rows)
    # Diagnostics.
    diag=[]
    for p in sorted((ROOT/'artifacts/diagnostics').glob('*.json')):diag+=json.loads(p.read_text())['records']
    diag=pd.DataFrame(diag);diag.to_csv(out/'repeated_mask_summary.csv',index=False)
    rows=[]
    for name in ['gsm','mmlu_pro']:
        for budget in [10,100]:
            for m in ['uniform','stratified_mean','aipw_population','scfd']:
                r=diag[(diag.benchmark==name)&(diag.regime=='frontier')&(diag.budget==budget)&(diag.method==m)].iloc[0]
                rows.append([name.replace('_',r'\_'),budget,LABELS[m],f'{100*r.mae:.2f}',f'{100*r.bias:+.2f} $\\pm$ {100*r.bias_mcse:.2f}',f'{100*np.sqrt(r.variance):.2f}'])
    write_tab(tables/'diagnostics.tex',['Bank',r'$b$','Method','MAE','Bias $\\pm$ MCSE','SD (within target)'],rows)
    # Quantitative macros for prose, never manually substituted estimates.
    macros=[]
    for regime,prefix in [('iid','IID'),('frontier','Frontier'),('gap','Gap')]:
        if regime not in summ.regime.values:continue
        for m,suffix in [('uniform','Uniform'),('stratified_mean','Strat'),('scfd','SCFD'),('ridge_score','Ridge'),('aipw_population','AIPW'),('item_difference','Difference')]:
            r=row(regime,m)
            macros.append(f'\\newcommand{{\\{prefix}{suffix}}}{{{100*r.mae:.2f}}}')
            macros.append(f'\\newcommand{{\\{prefix}{suffix}Rho}}{{{r.rho:.3f}}}')
    total=sum(r['total_seconds'] for r in runs if r['regime'] in ['iid','frontier'])
    macros.append(r'\newcommand{\CoreCellMinutes}{'+f'{total/60:.1f}'+'}')
    (tables/'numbers.tex').write_text('\n'.join(macros)+'\n')
    rows=[]
    for regime in ['iid','frontier']:
        for budget in BUDGETS:
            rows.append([regime,budget]+[f'{100*row(regime,m,budget).mae:.2f}' for m in ['uniform','stratified_mean','ridge_score','aipw_population','cfd_uniform','scfd']])
    write_tab(tables/'budgets.tex',['Regime',r'$b$','Uniform','Strat. mean','Score ridge','AIPW--pop.','Unif. CFD','SCFD'],rows)
    rows=[]
    for m in MAIN:
        vals=[]
        for regime in ['iid','frontier']:
            z=row_summary[(row_summary.regime==regime)&(row_summary.budget==50)&(row_summary.method==m)].iloc[0]
            vals.append(f'{100*z.mae:.2f}')
        rows.append([LABELS[m]]+vals)
    write_tab(tables/'row_weighted.tex',['Method','IID row MAE','Frontier row MAE'],rows)
    if irt_complete:
        fits=[d[k] for d in irt_meta for k in ['source_fit','inner_fit']]
        failed=sum(not f['success'] for f in fits)
        (out/'irt_integrity.json').write_text(json.dumps(dict(cells=len(irt_meta),fits=len(fits),nonconverged_fits=failed,
            max_iterations=max(f['iterations'] for f in fits),summed_cell_seconds=sum(d['wall_seconds'] for d in irt_meta)),indent=2))
        extra=[r'\newcommand{\IRTFits}{'+str(len(fits))+'}',r'\newcommand{\IRTNonconverged}{'+str(failed)+'}']
        for regime,prefix in [('iid','IID'),('frontier','Frontier')]:
            extra.append(f'\\newcommand{{\\{prefix}MIRT}}{{{100*row(regime,"mirt_5").mae:.2f}}}')
            extra.append(f'\\newcommand{{\\{prefix}MIRTMix}}{{{100*row(regime,"mirt_mix").mae:.2f}}}')
        with (tables/'numbers.tex').open('a') as f:f.write('\n'.join(extra)+'\n')
    # Publication figures. All shown data from summary tables above.
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,
        'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'axes.grid':True,'grid.alpha':.15})
    fig,axs=plt.subplots(1,2,figsize=(6.8,2.8),sharey=True,layout='constrained')
    for ax,regime,title in zip(axs,['iid','frontier'],['Random group holdout','Capability-frontier holdout']):
        for m in ['uniform','stratified_mean','ridge_score','aipw_population','scfd']:
            d=summ[(summ.regime==regime)&(summ.method==m)].sort_values('budget')
            ax.plot(d.budget,100*d.mae,marker='o',markersize=3,color=COLORS[m],label=LABELS[m])
            ax.fill_between(d.budget,100*d.ci_lo,100*d.ci_hi,alpha=.10,color=COLORS[m])
        ax.set_xscale('log');ax.set_xticks(BUDGETS,labels=BUDGETS);ax.set_xlabel('Queried items per target');ax.set_title(title,fontsize=9)
    axs[0].set_ylabel('Macro MAE (percentage points)')
    handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside lower center',ncol=3,frameon=False,fontsize=8)
    savefig(fig,figs/'budget_curves')
    # Benchmark-level effects shown independently of aggregate bootstrap.
    z=bybench[(bybench.regime=='frontier')&(bybench.budget==50)].pivot(index='benchmark',columns='method',values='mae')
    z=z.loc[NAMES]
    fig,ax=plt.subplots(figsize=(6.8,3.0),layout='constrained');idx=np.arange(len(z))
    ax.barh(idx-.17,100*(z.scfd-z.uniform),height=.32,label='SCFD - Uniform',color=COLORS['uniform'])
    ax.barh(idx+.17,100*(z.scfd-z.stratified_mean),height=.32,label='SCFD - Stratified mean',color=COLORS['scfd'])
    ax.axvline(0,color='k',lw=.7);ax.set_yticks(idx,labels=z.index,fontsize=8);ax.invert_yaxis()
    ax.set_xlabel('Frontier MAE difference (percentage points); negative is better')
    ax.legend(frameon=False,fontsize=8,loc='lower right');savefig(fig,figs/'paired_effects')
    # Diagnostic signed bias with 2MCSE, not individual-model confidence intervals.
    fig,axs=plt.subplots(1,2,figsize=(6.8,2.7),layout='constrained',sharey=True)
    chosen=['uniform','stratified_mean','aipw_population','scfd']
    for ax,name in zip(axs,['gsm','mmlu_pro']):
        for j,m in enumerate(chosen):
            d=diag[(diag.benchmark==name)&(diag.regime=='frontier')&(diag.method==m)].sort_values('budget')
            ax.errorbar(np.array([0,1])+(j-1.5)*.1,100*d.bias,yerr=200*d.bias_mcse,
                fmt='o',markersize=4,capsize=2,color=COLORS[m],label=LABELS[m])
        ax.axhline(0,color='k',lw=.7);ax.set_xticks([0,1],labels=['10','100']);ax.set_xlabel('Query budget');ax.set_title(name,fontsize=9)
    axs[0].set_ylabel('Mean signed error (percentage points)')
    handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside lower center',ncol=4,frameon=False,fontsize=8)
    savefig(fig,figs/'bias_diagnostics')
    # Stats/log integrity report.
    report=dict(main_cells=sum(r['regime'] in ['iid','frontier'] for r in runs),
        gap_cells=sum(r['regime']=='gap' for r in runs),main_method_budget_cells=int(len(core)),
        rasch_max_final_step=max(r['rasch_final_step'] for r in runs),
        rasch_max_iterations=max(r['rasch_iterations'] for r in runs),
        undefined_correlations=int(core.rho.isna().sum()),total_cell_seconds=float(total),
        protocol='Group-weighted primary; equal bank weights; CI resamples13 bank means, seeds averaged; descriptive correlated-bank interval')
    (out/'integrity.json').write_text(json.dumps(report,indent=2))
    print(summ[(summ.budget==50)&summ.regime.isin(['iid','frontier'])][['regime','method','mae','rmse','bias','rho']].to_string(index=False))
    print('PRIMARY EFFECTS',json.dumps(effects,indent=2));print('INTEGRITY',report)

if __name__=='__main__':main()
