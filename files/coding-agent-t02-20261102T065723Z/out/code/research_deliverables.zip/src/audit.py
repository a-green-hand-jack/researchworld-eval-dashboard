"""Independent numerical audit of saved artifacts and event handling."""
import sys,json,hashlib,platform,os,argparse
from pathlib import Path
import numpy as np
import torch
from torch import nn
sys.path.insert(0,str(Path(__file__).parent))
from train import Square
from analyze import event,H

def main():
 torch.set_num_threads(1);torch.set_flush_denormal(True)
 parser=argparse.ArgumentParser();parser.add_argument('--partial',action='store_true');args=parser.parse_args()
 report=[];seen=set();missing=[]
 for manifest in ['configs/main.json','configs/secondary.json','configs/features.json','configs/replication.json']:
  for config in json.loads(Path(manifest).read_text()):
   f=Path(config['out'])
   if not f.exists():
    missing.append(str(f))
    if args.partial:continue
    raise AssertionError(f)
   raw=f.read_bytes();d=json.loads(raw);assert d['flush_denormal'] is True;c=d['config'];h=d['history'];p=c['p'];w=c['width'];ck=torch.load(f.with_suffix('.pt'),weights_only=False)
   tr=ck['train_indices'];va=ck['test_indices'];assert len(set(tr.tolist())&set(va.tolist()))==0
   assert sorted(torch.cat([tr,va]).tolist())==list(range(p*p))
   assert len(tr)==int(c['fraction']*p*p)
   model=nn.Sequential(nn.Linear(2*p,w,bias=False),nn.ReLU() if c['activation']=='relu' else Square(),nn.Linear(w,p,bias=False));model.load_state_dict(ck['state_dict'])
   a=torch.arange(p).repeat_interleave(p);b=torch.arange(p).repeat(p);x=torch.cat([nn.functional.one_hot(a,p),nn.functional.one_hot(b,p)],1).float()
   y=(a*b)%p if c['task']=='multiply' else (a+b)%p
   if c['task']=='random':y=torch.randint(p,(p*p,),generator=torch.Generator().manual_seed(200000+c['seed']))
   with torch.no_grad():logits=model(x);pred=logits.argmax(1)
   acc=(pred[va]==y[va]).float().mean().item();assert abs(acc-h[-1]['test_acc'])<1e-7,(f,acc)
   assert d['parameters']==3*p*w==sum(v.numel() for v in model.parameters())
   assert [r['step'] for r in h]==list(range(0,c['steps']+1,c['eval_every']))
   assert np.isfinite([[r[k] for k in ['train_loss','test_loss','norm','structure']] for r in h]).all()
   assert all(-1e-6<=r['structure']<=1+1e-5 for r in h)
   assert c['seed'] in list(range(10,15))+list(range(20,30))
   for v in ['p','width','decay','seed','activation','fraction','task','init_mode']:
    assert ck['config'][v]==c[v]
   if c.get('freeze_features_at',-1)>0:
    frozen=ck['frozen_directions'];weight=model[0].weight.detach();coef=(weight*frozen).sum(1,keepdim=True)/frozen.square().sum(1,keepdim=True).clamp_min(1e-30)
    assert torch.allclose(weight,coef*frozen,atol=1e-5,rtol=1e-5)
    assert (coef>=-1e-6).all()
    baseline=json.loads(Path(f'results/main_d1_w{w}_s{c["seed"]}.json').read_text())['history']
    for row,base in zip(h,baseline):
     if row['step']<=c['freeze_features_at']:
      for key in ['train_acc','test_acc','train_loss','test_loss','norm','structure']:assert abs(row[key]-base[key])<1e-5,(f,key,row['step'])
   # Matched example partitions must be identical across width/activation/regularization.
   key=(p,c['seed'],c['fraction']);idx=tuple(tr.tolist())
   if key in splitmap:assert splitmap[key]==idx
   splitmap[key]=idx
   report.append(dict(path=str(f),sha256=hashlib.sha256(raw).hexdigest(),recomputed_accuracy=acc,passed=True))
 # The projection's closed-form denominator and invariance tested on arbitrary logits.
 p=7;a=torch.arange(p).repeat_interleave(p);b=torch.arange(p).repeat(p);r=(torch.arange(p)[None,:]-a[:,None]-b[:,None])%p
 f=torch.randn(p*p,p);f-=f.mean(1,keepdim=True);g=torch.zeros(p).scatter_add_(0,r.flatten(),f.flatten())/(p*p);proj=g[r]
 assert abs((proj*(f-proj)).sum().item())<1e-4
 assert torch.allclose(proj.norm().square(),p*p*g.norm().square(),atol=1e-5)
 synthetic=[dict(step=i*100,test_acc=t) for i,t in enumerate([0,.96,.96,.2,.96,.96,.96])]
 assert event(synthetic,'test_acc',.95)==400
 assert event(synthetic[:6],'test_acc',.95) is None
 Path('paper/generated/audit_partial.json' if args.partial else 'paper/generated/audit.json').write_text(json.dumps({'all_passed':True,'complete':not missing,'missing':missing,'runs_checked':len(report),'runs':report},indent=2));print('PASS:',len(report),'runs; splits, checkpoint accuracies, counts, numerical finiteness, projection and event checks')
splitmap={}
if __name__=='__main__':main()
