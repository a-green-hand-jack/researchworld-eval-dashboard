# Frozen experiment protocol (before method results)

## Scope and story
Task: predict finite-bank mean binary correctness of unseen model rows. Narrow question: can source-informed, stratified, honest residual audits retain interpolation gains without giving up design unbiasedness under capability shift? Contribution is a controlled investigation and finite-population cross-fitted implementation, NOT invention of difference estimation or exhaustive novelty. Negative results are valid.

Pipeline: source rows -> 5 difficulty strata -> random queried items -> target-only pilot regression -> independent residual audit -> full-bank score. Figures: budget-error curves; per-benchmark paired effects; bias/frontier diagnostics. Fallback story: honesty costs variance and adaptive selection does not automatically outperform simple stratification.

## Data / leakage
All 13 supplied LLM binary banks at fixed commit 55faff496947789f94e6b5908c77cbc3e84f81ad. Retain zeros, constant columns, duplicate rows. Group EXACT duplicate response rows in each bank, split groups together; report both raw and unique counts. Primary metrics weight exact-response target groups equally; original-row weighting is a sensitivity. This refinement follows /work/plan_review.md, adopted BEFORE method results. No target rows used for strata, ridge coefficients across models, source validation, or item representation. Full target rows used only in split construction for explicit frontier stress and final metric computation.

IID: shuffle unique response groups, 70% source / 30% target; frontier: sort groups by full mean and hold out highest 30%, choosing the nearest score-tie-block boundary to avoid splitting equal scores. Frontier uses privileged score information ONLY to define a retrospective stress test, not as a deployment selector. Seeds0..4. No chronological/family claim because names alone do not establish lineage or time.

## Budget / metrics / uncertainty
Budgets10,25,50,100 (strictly < all item-bank sizes). Primary endpoint budget50 macro-averaged MAE (percentage points), separately IID and frontier. Secondary RMSE, signed bias, Spearman rho, Kendall tau-b, pairwise sign agreement excluding true ties; tied predictions score half. Undefined correlations saved null, counts reported. 95% paired bootstrap benchmark-level CIs after averaging 5 seeds (13 non-independent banks, descriptive, not population guarantee). Also seed SDs and benchmark per-condition tables. Primary two contrasts SCFD vs uniform and SCFD vs stratified mean; adjust four protocol x contrast tests with Holm; no exploratory winner-based significance. Source budgets/splits recorded. Metrics not model-deployment confidence intervals.

## Methods
- Uniform: sample without replacement, mean.
- Item difference: source item-mean control variate, full mean + uniform residual mean (no target fitting; exactly design unbiased).
- Ridge score: Random-Sampling-Learn across source model rows, RidgeCV alphas0.1,1,10 (pinned defaults), labels source full means.
- AIPW-pinned: exact equation/code at commit, alpha10/intercept, predicts unobserved mean plus unobserved-fraction times training residual mean.
- AIPW-population: mean of observed + predicted unobserved divided by full bank size; with intercept residual0 equals population-coefficient-corrected difference estimate. Neither gets an honesty/unbiasedness claim.
- Rasch1PL: regularized binary additive logistic matrix fit to sources; target scalar ability fit only sampled outcomes; aggregate observed plus unobserved probabilities. A labeled reimplementation, NOT full tinyBenchmarks/GPIRT.
- Binary anchors: MiniBatchKMeans over source correctness item vectors, choose nearest unused real item to each centroid, cluster-size weighted score. Labeled approximate correctness-space adaptation, NOT confidence Anchor Points or exact repository k-medoids.
- Stratified mean: source mean ranks split into H=5 equal-sized strata; sample floor(b/H) per stratum plus seeded extras, use bank-size weights.
- Stratified ridge score: exact same queries as stratified methods, same RidgeCV.
- Uniform CFD: split each uniform sample into pilot/audit; two swapped full-bank difference estimates, average. Alpha10 same target regression as AIPW.
- SCFD (proposed): H=5 source difficulty strata; split each stratum queried set into disjoint pilot/audit (>=1 each); per-half fit source-response ridge across items alpha10. Full total = observed pilot total + predicted nonpilot total + sum_h remaining stratum size * audit mean residual_h. Divide by N; swap and average. No clipping. Conditional on one pilot, audits uniform on each stratum complement; source-defined strata and predictor fixed given pilot, hence unbiased. Finite-population corrections applied separately per stratum. All validation is source-only.
- Stratified item difference: no target fitting; isolates value of target-specific pilot.
- SCFD one-sided: first pilot/audit estimate only; isolates symmetrization.
- SCFD no audit: population-weighted two imputation estimates; isolates honest correction.

## Stages, gates, and commands
1. Data audit + baseline unit equivalence + finite-population sanity tests. `python -m pytest -q`; `python src/audit.py`. Gate correctness, not numerical match to published protocols (our splits differ).
2. Fixed hyperparameters rather than target-tuned search: alpha10 for target ridge; RidgeCV for row ridge. Smoke one dataset/seed. Gate finite values and access isolation. No test-driven tuning.
3. Main runs `python src/run_experiments.py --jobs 8`; resumable per-bank/protocol/seed JSON + predictions NPZ; seeds0..4 all banks/budgets.
4. Ablations are prespecified above plus the matched-fit contaminated-residual diagnostic. Before method results, adopt the planner's repeated-mask panel: largest and median item bank (mmlu_pro, gsm; name tie-break), seed0 source split per regime, up to6 target groups selected by fixed RNG, budgets10/100, 200 independent masks; report Monte Carlo errors rather than five-mask bias claims. Optional lower50/upper30 gap stress at b50 after main grid. Equal-fold half-average remains prespecified even at b25; it is unbiased but need not recover the sample mean for a constant nuisance. No deployment interval claim.
5. `python src/analyze.py` builds tables/plots; paper includes actual results only. `make -C paper` builds NeurIPS2026 official 9-page main submission + refs/checklist/appendix.

## Rejection risks / limits
Standard survey estimator novelty; approximate not exact clustering/IRT baselines; frontier split not real temporal OOD; duplicates/families correlated; few datasets and shared model pools; no adaptive RL or GPIRT reproduction. Explicitly disclose, do not claim SOTA. If SCFD loses, retain and interpret losses; no posthoc replacement of primary endpoint.

## Resource/attempt budget
CPU only. First smoke timing then launch bounded parallel cells with BLAS1. Limit exploratory changes to bug fixes or recorded diagnostic, never hide failures. Target under ~1GB excluding Python environment and git metadata. All artifacts under /work. No full LLM inference and no paid APIs.

## Completion and documented amendments
- Completed all original130 main cells,65 optionalgap cells and200mask x8diagnostic panels. Added source-calibrated multidimensional IRT130cells after primary analysis and nearest-source130cells after review; additions recorded without changing frozen SCFD settings, endpoint or primary contrasts.
- Repaired source-only Rasch common-shift optimization; discarded/recomputed affected preliminary main runs. Initial MIRT cap250 smoke fits superseded by complete cap1000 study. Logs retain failures and final statuses.
- Repaired ranking-only floating tie handling from saved predictions (10decimals for ordering, raw-error metrics unchanged). 1170offset invariants pass; final12unit tests and23010saved metric records verified.
- `python src/build_paper.py` replaces unavailable GNU make. Official NeurIPS2026 source compiles to8content pages (limit9),25total including appendices/references/16answered checklist questions; style hash unchanged.
- Final README, report, LaTeX-source archive and code/results archive supplied. Original plan above is retained, with exact implementation/amendment provenance in logs/review_resolutions.md and logs/irt_comparator_amendment.md.
- Scope gates completed; superiority is not claimed. Limited main-track contribution remains a venue-risk judgment, not a promised success signal or a fabricated resolution.
