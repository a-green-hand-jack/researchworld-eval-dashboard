"""Generate every empirical table, figure, and number in the manuscript from raw runs."""
import json,csv,itertools
from pathlib import Path
import numpy as np
from scipy.stats import beta,binomtest
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=29800
SEEDS=list(range(10,15));WIDTHS=[16,32,64,128,256];DECAYS=[0,.3,1,3]
OUT=Path('paper/generated');OUT.mkdir(exist_ok=True,parents=True)
FIG=Path('paper/figures');FIG.mkdir(exist_ok=True,parents=True)
plt.rcParams.update({'font.size':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
def event(hist,key,threshold):
 for i in range(len(hist)-2):
  if hist[i]['step']<=H and all(hist[j][key]>=threshold for j in [i,i+1,i+2]):return hist[i]['step']
 return None
def record(path):
 d=json.loads(Path(path).read_text());h=d['history'];c=d['config'];tr=event(h,'train_acc',.99);tg=event(h,'test_acc',.95)
 r=dict(path=str(path),**{k:c.get(k,v) for k,v in dict(width=64,seed=0,p=31,decay=1,fraction=.3,activation='relu',task='add',init_mode='default').items()},freeze_at=c.get('freeze_features_at',-1),final_train_acc=h[-1]['train_acc'],parameters=d['parameters'],train_time=tr,gen_time=tg,wait=H if tg is None else tg,delay=None if tg is None or tr is None else tg-tr,relative_delay=None if tg is None or tr is None else tg/tr,final_acc=h[-1]['test_acc'],structure=h[-1]['structure'],wall_seconds=d['elapsed'],cpu_seconds=d.get('cpu_seconds',0),delayed=False)
 if tr is not None and tg is not None:r['delayed']=tg>=2*tr and next(v['test_acc'] for v in h if v['step']==tr)<=.5
 return r,d

def ci_mean(x):
 x=np.array(x,dtype=float);n=len(x)
 if n==0:return [None,None,None]
 # Exact enumeration of the ordinary nonparametric bootstrap, feasible for n=5.
 inds=np.array(list(itertools.product(range(n),repeat=n))) if n<=5 else np.random.default_rng(20261102).integers(0,n,size=(100000,n))
 means=x[inds].mean(1)
 return [float(x.mean()),*np.quantile(means,[.025,.975]).tolist()]
def cp(k,n):return [0. if k==0 else beta.ppf(.025,k,n-k+1),1. if k==n else beta.ppf(.975,k+1,n-k)]
def fmt(x):return f'{x:,.0f}'
def mainpath(d,w,s):return Path(f'results/main_d{d}_w{w}_s{s}.json')
def loadgroup(name,w):
 return [record(mainpath(1,w,s) if name=='main' or (name=='norm' and w==64) else f'results/{name}_w{w}_s{s}.json') for s in SEEDS]
def summarize(group):
 rows=[x[0] for x in group];k=sum(r['gen_time'] is not None for r in rows)
 return dict(n=len(rows),success=k,success_ci=cp(k,len(rows)),interpolate=sum(r['train_time'] is not None for r in rows),delayed=sum(r['delayed'] for r in rows),waiting=ci_mean([r['wait'] for r in rows]),final_acc=ci_mean([r['final_acc'] for r in rows]),train_waiting=ci_mean([H if r['train_time'] is None else r['train_time'] for r in rows]),structure=ci_mean([r['structure'] for r in rows]),final_train_acc=ci_mean([r['final_train_acc'] for r in rows]))

def analyze():
 allrows=[];summary={};grid={}
 for d in DECAYS:
  for w in WIDTHS:
   group=[record(mainpath(d,w,s)) for s in SEEDS];allrows.extend(r for r,_ in group);grid[d,w]=group;summary[f'main_d{d}_w{w}']=summarize(group)
 for name in ['norm','square','p47','dense','multiply','random']:
  for w in [32,64,128,256]:
   g=loadgroup(name,w);summary[f'{name}_w{w}']=summarize(g)
   if not(name=='norm' and w==64):allrows.extend(r for r,_ in g)
 for name in ['freeze1000','freeze10000']:
  for w in [64,256]:
   group=loadgroup(name,w);summary[f'{name}_w{w}']=summarize(group);allrows.extend(r for r,_ in group)
 replication={}
 for w in [64,256]:
  group=[record(f'results/replication_w{w}_s{seed}.json') for seed in range(20,30)];replication[w]=group;summary[f'replication_w{w}']=summarize(group);allrows.extend(r for r,_ in group)
 with (OUT/'per_run.csv').open('w') as f:
  writer=csv.DictWriter(f,fieldnames=list(allrows[0]));writer.writeheader();writer.writerows(allrows)
 a=loadgroup('main',64);b=loadgroup('main',256)
 paired_wait=[rb['wait']-ra['wait'] for (ra,_),(rb,_) in zip(a,b)]
 paired_tr=[(H if rb['train_time'] is None else rb['train_time'])-(H if ra['train_time'] is None else ra['train_time']) for (ra,_),(rb,_) in zip(a,b)]
 summary['primary']={'waiting_difference_256_minus64':ci_mean(paired_wait),'per_seed_waiting_difference':paired_wait,'train_difference':ci_mean(paired_tr)}
 vals=[rb['wait']-ra['wait'] for (ra,_),(rb,_) in zip(replication[64],replication[256])]
 nonzero=[v for v in vals if v!=0]
 summary['replication']={'waiting_difference_256_minus64':ci_mean(vals),'per_seed_waiting_difference':vals,'sign_test_p':float(binomtest(sum(v<0 for v in nonzero),len(nonzero),.5).pvalue) if nonzero else 1.0,'analysis_rng':20261102,'bootstrap_resamples':100000}
 summary['primary']['sign_test_p']=float(binomtest(sum(v<0 for v in paired_wait if v!=0),sum(v!=0 for v in paired_wait),.5).pvalue) if any(v!=0 for v in paired_wait) else 1.0
 summary['delay_metrics']={str(w):{'absolute':ci_mean([r['delay'] for r,_ in grid[1,w]]),'ratio':ci_mean([r['relative_delay'] for r,_ in grid[1,w]])} for w in [128,256]}
 summary['durability']={}
 for decay in DECAYS:
  for width in WIDTHS:
   times=[]
   for r,d in grid[decay,width]:
    hist=d['history'];times.append(next((v['step'] for i,v in enumerate(hist) if v['step']<=H and all(q['test_acc']>=.95 for q in hist[i:])),None))
   summary['durability'][f'd{decay}_w{width}']=times
 summary['threshold_sensitivity']={str(t):{str(w):[event(d['history'],'test_acc',t) for _,d in loadgroup('main',w)] for w in [64,256]} for t in [.9,.95,.99]}
 summary['compute_proxy']={}
 for w in [64,128,256]:
  step=64*30000//w
  vals=[next(v['test_acc'] for v in d['history'] if v['step']==step) for _,d in loadgroup('main',w)]
  summary['compute_proxy'][str(w)]={'step':step,'accuracy':ci_mean(vals),'per_seed':vals}
 summary['cpu_seconds']=sum(r['cpu_seconds'] for r in allrows);summary['run_count']=len(allrows)
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
 # Main grid table: all cells, censored times included as restricted waiting times.
 lines=[r'\begin{tabular}{rr rrr r r}',r'\toprule',r'$\lambda$ & Width & Fit & Gen. & Delayed & Restricted wait [95\% CI] & Final acc. \\',r'\midrule']
 for d in DECAYS:
  for w in WIDTHS:
   s=summary[f'main_d{d}_w{w}'];m,lo,hi=s['waiting'];ac=s['final_acc'][0]
   lines.append(f'{d:g} & {w} & {s["interpolate"]}/5 & {s["success"]}/5 & {s["delayed"]}/5 & {fmt(m)} [{fmt(lo)}, {fmt(hi)}] & {ac:.3f} '+r'\\')
  if d!=DECAYS[-1]:lines.append(r'\midrule')
 lines += [r'\bottomrule',r'\end{tabular}'];(OUT/'main_table.tex').write_text('\n'.join(lines))
 lines=[r'\begin{tabular}{lrrr r}',r'\toprule',r'Setting & Width & Gen. & Restricted wait & Final acc. [95\% CI] \\',r'\midrule']
 labels={'main':'Reference ReLU','norm':'Matched initial norm','square':'Square activation','p47':'Addition mod 47','dense':'70\% training pairs','multiply':'Multiplication mod 31','random':'Random labels','freeze1000':'Directions fixed after 1k','freeze10000':'Directions fixed after 10k'}
 for name in labels:
  for w in [64,256]:
   s=summary[f'main_d1_w{w}' if name=='main' else f'{name}_w{w}'];m,lo,hi=s['final_acc']
   lines.append(f'{labels[name]} & {w} & {s["success"]}/5 & {fmt(s["waiting"][0])} & {m:.3f} [{lo:.3f}, {hi:.3f}] '+r'\\')
 lines += [r'\bottomrule',r'\end{tabular}'];(OUT/'secondary_table.tex').write_text('\n'.join(lines))
 # Figure 1: paired-seed learning trajectories, reference decay.
 fig,axes=plt.subplots(1,2,figsize=(6,2.25),layout='constrained');colors=plt.cm.viridis(np.linspace(.05,.9,len(WIDTHS)))
 for w,col in zip(WIDTHS,colors):
  g=grid[1,w];steps=np.array([r['step'] for r in g[0][1]['history']])
  for ax,key in zip(axes,['train_acc','test_acc']):
   ys=np.array([[r[key] for r in d['history']] for _,d in g]);ax.plot(steps,np.median(ys,0),color=col,label=f'{w}');ax.fill_between(steps,ys.min(0),ys.max(0),color=col,alpha=.12)
 for ax,title in zip(axes,['Training accuracy','Held-out accuracy']):ax.set(xscale='symlog',xlim=(0,30000),ylim=(-.02,1.02),xlabel='Optimizer steps',ylabel=title);ax.grid(alpha=.2)
 axes[1].legend(title='Width',ncols=1,fontsize=7,loc='upper left');fig.savefig(FIG/'curves.pdf');plt.close(fig)
 # Figure2: all grid values, waiting heatmap and success counts.
 fig,ax=plt.subplots(figsize=(5.5,2.2),layout='constrained');values=np.array([[summary[f'main_d{d}_w{w}']['waiting'][0] for w in WIDTHS] for d in DECAYS]);im=ax.imshow(values/1000,aspect='auto',vmin=0,vmax=H/1000,cmap='magma_r')
 for i,d in enumerate(DECAYS):
  for j,w in enumerate(WIDTHS):
   s=summary[f'main_d{d}_w{w}'];ax.text(j,i,f'{s["success"]}/5\n{values[i,j]/1000:.1f}k',ha='center',va='center',color='white' if values[i,j]>18000 else 'black',fontsize=8)
 ax.set(xticks=range(5),xticklabels=WIDTHS,yticks=range(4),yticklabels=[str(d) for d in DECAYS],xlabel='Hidden width',ylabel='Weight decay');fig.colorbar(im,ax=ax,label='Restricted waiting steps (thousands)');fig.savefig(FIG/'grid.pdf');plt.close(fig)
 # Figure3 diagnostic trajectories, no handpicked seed.
 fig,axes=plt.subplots(1,2,figsize=(6,2.15),layout='constrained')
 for w,col in [(64,'#0072B2'),(256,'#D55E00')]:
  g=loadgroup('main',w);steps=[r['step'] for r in g[0][1]['history']]
  for ax,key in zip(axes,['structure','norm']):
   ys=np.array([[r[key] for r in d['history']] for _,d in g]);ax.plot(steps,np.median(ys,0),color=col,label=f'width {w}');ax.fill_between(steps,ys.min(0),ys.max(0),color=col,alpha=.15)
 for ax,key in zip(axes,['Additive-symmetry energy S','Parameter norm']):ax.set(xlabel='Optimizer steps',ylabel=key);ax.grid(alpha=.2)
 axes[0].legend(fontsize=7);fig.savefig(FIG/'diagnostics.pdf');plt.close(fig)
 # Exploratory causal intervention, all seeds, complete trajectories.
 fig,ax=plt.subplots(figsize=(5.5,2.25),layout='constrained')
 for name,label,col in [('main','Unconstrained','#0072B2'),('freeze1000','Directions fixed after 1k','#D55E00'),('freeze10000','Directions fixed after 10k','#009E73')]:
  group=loadgroup(name,256);steps=[r['step'] for r in group[0][1]['history']];ys=np.array([[r['test_acc'] for r in d['history']] for _,d in group]);ax.plot(steps,np.median(ys,0),label=label,color=col);ax.fill_between(steps,ys.min(0),ys.max(0),color=col,alpha=.12)
 ax.set(xlabel='Optimizer steps',ylabel='Held-out accuracy',ylim=(-.02,1.02));ax.legend(fontsize=7);ax.grid(alpha=.2);fig.savefig(FIG/'feature_freezing.pdf');plt.close(fig)
 # Macros avoid manual transcription of primary quantities.
 m,lo,hi=summary['primary']['waiting_difference_256_minus64'];mac=[f'\\newcommand{{\\PrimaryDiff}}{{{fmt(m)}}}',f'\\newcommand{{\\PrimaryLow}}{{{fmt(lo)}}}',f'\\newcommand{{\\PrimaryHigh}}{{{fmt(hi)}}}',f'\\newcommand{{\\RunCount}}{{{len(allrows)}}}',f'\\newcommand{{\\CPUHours}}{{{summary["cpu_seconds"]/3600:.2f}}}']
 for w in [64,256]:
  s=summary[f'main_d1_w{w}'];name={64:'SixtyFour',256:'TwoFiftySix'}[w]
  mac.extend([f'\\newcommand{{\\Wait{name}}}{{{fmt(s["waiting"][0])}}}',f'\\newcommand{{\\Success{name}}}{{{s["success"]}}}',f'\\newcommand{{\\Fit{name}}}{{{fmt(s["train_waiting"][0])}}}'])
 (OUT/'numbers.tex').write_text('\n'.join(mac)+'\n')
 print(json.dumps(summary['primary'],indent=2));print('Runs',len(allrows),'CPU hours',summary['cpu_seconds']/3600)
if __name__=='__main__':analyze()
